#include<iostream>
using namespace std;

int main()
{
	long long p, b, h;//use long long
	cin>>p;
	if(p<3)
	{//added ,case when triplet not exist
		cout<<-1;
		return 0;
	}
	if(p % 2 == 0)
	{
		b = (p*p/4) - 1;
		h = (p*p/4) + 1;
	}

	else
	{
		h = ((p+1)*(p+1)/4) + ((p-1)*(p-1)/4);
		b = (p + 1)*(p - 1) / 2;

	}
	cout<<b<<" ";
	cout<<h;
	
	return 0;
}