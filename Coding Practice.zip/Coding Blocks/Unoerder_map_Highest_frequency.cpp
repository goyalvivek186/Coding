#include<iostream>
#include<unordered_map>
#include<climits>
using namespace std;

int main()
{
	unordered_map<int, int> m;
	int n;
	cin >> n;
	int no, l = INT_MIN;
	for(int i = 0; i < n; i++)
	{
		int x;
		cin >> x;
		if(m.count(x))
		{
			m[x]++;
            if(m[x] > l)
            {
                l = m[x];
                no = x;
            }
		}
		else
		{
			m[x] = 1;
		}
	}

	/*for(auto x : m)
	{
		if(x.second > l)
		{
			no = x.first;
			l = x.second;
		}
	}*/
	cout<<no;

	return 0;
}