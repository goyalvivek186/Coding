#include<iostream>
#include<unordered_map>
using namespace std;

int main()
{
	int n, k;
	cin >> n >> k;
	int pre = 0, l = 0;
	unordered_map<int, int> up;
	for(int i = 0; i < n; i++)
	{
		int a;
		cin >> a;
		pre += a;
		if(pre == k)
		{
			l = max(l, i+1);
		}
		else if(up.find(pre-k) != up.end())
		{
			l = max(l, l-up[pre-k]);
		}
		else
		{
			up[pre] = i;
		}
	}
	cout<<l;
	return 0;
}