#include<iostream>
#include<cstring>

using namespace std;

void dup(char s[], int n)
{
	if(s[n] == '\0')
	{
	return;
	}
	if(s[n] == s[n+1])
	{
		int j = n+1;
		while(s[j] != '\0')				//or j = strlen(s);
		{
			j++;
		}
		while(j > n)
		{
			s[j + 1] = s[j];
            j--;
		}
		s[n+1] = '*';
	}
	dup(s, n+1);
}


int main()
{
	char s[1000];
	cin >> s;
	dup(s, 0);
    cout<<s;
	return 0;
}