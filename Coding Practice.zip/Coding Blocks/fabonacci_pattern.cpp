#include<iostream>
using namespace std;


int main()
{
	int a = -1, b = 1, c, n, i, j;
	cin>>n;
	for(i = 0; i < n; i++)
	{
		for(j = 0; j <= i; j++)
		{
			c = a + b;
			a = b;
			b = c;
			cout<<c<<"\t";

		}
		cout<<"\n";
	}



	return 0;
}