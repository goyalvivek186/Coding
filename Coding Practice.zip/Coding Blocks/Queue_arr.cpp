#include<iostream>
using namespace std;

class queue
{
protected:
	int *arr;
	int f, r, ms, cs;

public:
	queue(int x)
	{
		ms = x;
		arr = new int[ms];
		cs = 0;
		f = r = 0;
	}

	void push(int d)
	{
		if(cs == ms)
		{
			return;
		}
		arr[r] = d;
		r++;
		cs++;
	}

	void pop()
	{
		if(cs == 0)
		{
			return ;
		}
		for(int i = 0; i < cs; i++)
		{
			arr[i] = arr[i+1];
		}
		r--;
		cs--;
	}

	bool empty()
	{
		return cs == 0;
	}

	int front()
	{
		return arr[0];
	}
};

int main()
{
	queue q(5);
	int n = 5;
	while(n--)
	{
		q.push(n);
	}
	while(!q.empty())
	{
		cout<<q.front()<<endl;
		q.pop();
	}

	return 0;
}