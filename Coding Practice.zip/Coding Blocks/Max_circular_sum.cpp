#include<iostream>
using namespace std;
int kadane(int a[], int n)
{
	int currentsum=0;
	int maxsum=0;
	for(int i=0;i<n;i++)
	{
		currentsum+=a[i];
		if(currentsum<0)
		{
			currentsum=0;
		}
		maxsum=max(currentsum,maxsum);
	}
	return maxsum;
}

int circular(int a[],int n)
{
	int c1=kadane(a,n);
    //cout<<c1<<endl;
	int c2=0;
	for(int i=0;i<n;i++)
	{
		c2+=a[i];
		a[i]=-a[i];
	}
   /* cout<<c2<<endl;
    cout <<kadane(a,n)<<endl;*/
    //kadane(a, n) = minimum sum subarray
    //sum of array - min sum subayyar = max sum subarray
	c2=c2+kadane(a,n);		//+ as the return is in -ve and - * - = +
	return (c2>c1)?c2:c1;
}


int main()
{
	int t;
	cin>>t;
	for(int i=0;i<t;i++){
	
	int a[10000];
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	cout<<circular(a,n);
}	
	return 0;
}