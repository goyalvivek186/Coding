#include<iostream>

using namespace std;

bool rat(char maze[1000][1000], int m, int n, int ans[][1000], int i, int j)
{
	if(i == m and j == n)
	{
        ans[i][j] = 1;
		for(int x = 0; x <= i; x++)
		{
		for(int y = 0; y <= j; y++)
		{
			cout<<ans[x][y]<<" ";
		}
		cout<<endl;
		}
        cout<<endl;
	return true;
	}

	if(i > m or j > n)
	{
		return false;
	}

	if(maze[i][j] == 'X')
	{
		return false;
	}

	ans[i][j] = 1;
	bool right = rat(maze, m, n, ans, i, j + 1);
	bool bottom = rat(maze, m, n, ans, i + 1, j);
	ans[i][j] = 0;
	if(right or bottom)
	{
		return true;
	}
	return false;
}

int main()
{	
	int m, n;
	cin >>m >> n;
	char maze[1000][1000];
    int ans[1000][1000] = {0};
	for(int i = 0; i < m; i++)
	{
		for(int j = 0; j  <n; j++)
		{
			cin >> maze[i][j];
		}
	}
	bool a = rat(maze, m-1, n-1, ans, 0, 0);
    if(!a)
    {
        cout<<"-1"<<endl;
    }



	return 0;
}