#include<iostream>
#include<algorithm>

bool comp(int a, int b)
{
	return a > b;
}

using namespace std;
int main()
{
	int a[] = {7,8,4,5,9,8,7,4,5,4,1,47,15,147};
	int s = sizeof(a) / sizeof(int);
	sort(a, a+s, comp);
	for(int i : a)
	{
		cout<<i<<" ";
	}
	return 0;
}