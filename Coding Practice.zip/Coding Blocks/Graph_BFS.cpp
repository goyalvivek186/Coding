#include<iostream>
#include<unordered_map>
#include<string> 
#include<list>
#include<queue>
using namespace std;

class graph
{
	unordered_map<string, list< pair<string, int>>> m;
public:

	void add_edge(string a, string b, int w, bool bidi = true)
	{
		m[a].push_back(make_pair(b, w));
		if(bidi)
		{
			m[b].push_back(make_pair(a, w));
		}
	}

	void bfs(string source)
	{
		unordered_map<string, bool> visit;
		queue<string> q;
		q.push(source);
		while(!q.empty())
		{
			string a = q.front();
			q.pop();
			visit[a] = true;
			cout<<a<<" ";
			for(auto nbr : m[a])
			{
				string b = nbr.first;
				if(visit.count(b) == 0)
				{
					visit[b] = true;
					q.push(b);
				}
			}
		}

	}
};


int main()
{
	graph g;
	g.add_edge("A", "B", 40);
	g.add_edge("A", "C", 50);
	g.add_edge("B", "C", 10);
	g.add_edge("C", "D", 70);
	g.add_edge("C", "B", 40, false);

	g.bfs("A");


	return 0;
}