#include<iostream>
#include<string>
#include<algorithm>
#include<climits>

using namespace std;


int main()
{
	int n, x = 0, a;
	cin >> n;
	for(int i = 0; i < n; i ++)
	{
		cin >> a;
		x = x^a;
	}
	cout<<x;
	

	
	return 0;
}