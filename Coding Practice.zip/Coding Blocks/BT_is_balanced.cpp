#include<iostream>
using namespace std;

class node
{
public:
	int data;
	node *right;
	node* left;

	node(int d)
	{
		data = d;
		left = NULL;
		right = NULL;
	}
};

node *build()
{
	int c;
	cin >> c;
	if(c == -1)
	{
		return NULL;
	}
	node *root = new node(c);
	root->left = build();
	root->right = build();
	return root;

}

class balance
{
public:
	int h;
	bool b = true;
};

balance is_balance(node *root)
{
	balance x;
	if(root == NULL)
	{
		x.h = 0;
		x.b = true;
		return x;
	}
	balance left = is_balance(root->left);
	balance right = is_balance(root->right);

	x.h = max(left.h, right.h) + 1;
	if(abs(left.h - right.h) > 1 or !left.b or !right.b)
	{
		x.b = false;
	}
	return x;
}

int main()
{
	node *root = build();
	balance x = is_balance(root);
	if(x.b)
	{
		cout<<"Balanced"<<endl;
	}
	else
	{
		cout<<"Not Balanced"<<endl;
	}

	return 0;
}