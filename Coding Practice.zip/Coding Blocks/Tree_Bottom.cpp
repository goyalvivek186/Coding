#include<iostream>
using namespace std;

class node
{
	public:
		int data;
		node * right;
		node * left;

		node(int d)
		{
			data = d;
			right = NULL;
			left = NULL;
		}
};

node* built()
{
	int x;
	cin >> x;
	if(x == -1)
	{
		return NULL;
	}

	node * root = new node(x);
	root->left = built();
	root->right = built();

	return root;
}

class b_view
{
public:
	int h;
};

b_view bottom(node *root)
{
	b_view x;
	if(root == NULL)
	{
		x.h = 0;
		return x;
	}

	bottom(root->)
}

int main()
{
	node *root = built();
	return 0;
}