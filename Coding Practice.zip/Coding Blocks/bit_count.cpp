#include<iostream>
#include<string>
#include<algorithm>
#include<climits>

using namespace std;

int count(int a)
{
	int c = 0;
	while(a > 0)
	{
		if((a & 1) == 1)
		{
			c++;
		}
		a = a >> 1;
	}
	return c;
}


int main()
{
	int t;
	cin >> t;

	while(t--)
	{
		int a;
		cin >> a;
		cout<<count(a)<<endl;
	}
	
	return 0;
}