#include<iostream>
using namespace std;

int main()
{
	int n, i, j, t;
	cin>>n;
	t = n + 1;

	for(i = 1; i <= n; i ++)
	{
		for(j = 1; j <= i; j++)
		{
			cout<<j<<"\t";
		}
		for(j=((n-i)*2)-1; j > 0; j--)
		{
          cout<<"\t";
  		} 
		for(j = i; j >= 1; j--)
		{
			if(j == )
			{
				continue;
			}
			cout<<j<<"\t";
		}
		cout<<"\n";

	}





	return 0;
}