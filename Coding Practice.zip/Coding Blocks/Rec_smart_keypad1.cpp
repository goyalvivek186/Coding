#include<iostream>
using namespace std;

char s[][10] = { " ", ".+@$", "abc", "def", "ghi", "jkl" , "mno", "pqrs" , "tuv", "wxyz" };

void keypad(char *ch, char *ans, int i, int j)
{
	if(ch[i] == '\0')
	{
		ans[j] = '\0';
		cout<<ans<<endl;
		return;
	}

	int x = ch[i] - '0';
	for(int k = 0; s[x][k] != '\0'; k++)
	{
		ans[i] = s[x][k];
		keypad(ch, ans, i+1, j+1);
	}


}

int main()
{
	char ch[100];
	cin >> ch;
	char ans[100];
	keypad(ch, ans, 0, 0);

	return 0;
}