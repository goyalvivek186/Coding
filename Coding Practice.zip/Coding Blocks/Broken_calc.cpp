#include<iostream>
using namespace std;

void multiply(int *a, int n, int &index)
{
	int carr = 0;
	for(int i = 0; i <= index; i++)
	{
		int e = a[i] * n + carr;
		a[i] = e % 10;
		carr = e / 10;
	}

	while(carr > 0)
	{
		index ++;
		a[index] = carr % 10;
		carr = carr / 10;
	}
}

int main()
{
	int n;
	cin >> n;
	int a[1000] = {0};
	a[0] = 1;
	int index = 0;
	for(int i = 1; i <= n; i++)
	{
		multiply(a, i, index);
	}

	for(int i = index; i >= 0; i--)
	{
		cout<<a[i];
	}
	return 0;
}