#include<iostream>
#include<list>

using namespace std;

list<int> insertion(list<int> l)
{
	list<int> ans;
	for(auto i = l.begin(); i != l.end(); i++)
	{
		int d = *i;
		if(ans.empty())
		{
			ans.push_back(d);
		}
		else
		{
			auto j = ans.begin();
			auto cnt = ans.begin();
			for(auto k : ans)
			{
				if(k > d)
				{
					break;
				}
				cnt++;
			}
			ans.insert(cnt, d);
		}
	}
	return ans;
}

int main()
{
	list<int> l, ans;
	int n;
	cin >> n;
	while(n--)
	{
		int a;
		cin >> a;
		l.push_back(a);
	}
	ans = insertion(l);
	for(auto it : ans)
	{
		cout<<it<<" ";
	}


	return 0;
}