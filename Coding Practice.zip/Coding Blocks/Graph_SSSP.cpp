				//Single Source Shortest Path

#include<iostream>
#include<unordered_map>
#include<list>
#include<queue>
#include<climits>
using namespace std;

template<typename T>
class graph
{
	unordered_map<T, list<T> > m;

public:

	void addedge(T a, T b)
	{
		m[a].push_back(b);
		m[b].push_back(a);
	}

	void SSSP(T source)
	{
		unordered_map<T, int> dis;
		for(auto it : m)
		{
			dis[it.first] = INT_MAX;
		}
		dis[source] = 0;

		queue<T> q;
		q.push(source);
		while(!q.empty())
		{
			T a = q.front();
			for(auto it : m[a])
			{
				if(dis[it] == INT_MAX)
				{
					dis[it] = dis[a] + 1;
					q.push(it);
				}
			}
		}

		for(auto it : m)
		{
			cout<<"Distance of "<< it.first <<"from source = ";
			cout<<dis[it.first]<<endl;
		}
	}

};

int main()
{

	graph<int> g;
	g.addedge(0, 1);
	g.addedge(1, 2);
	g.addedge(2, 3);
	g.addedge(3, 4);
	g.addedge(4, 5);

	g.SSSP(0);
	return 0;
}