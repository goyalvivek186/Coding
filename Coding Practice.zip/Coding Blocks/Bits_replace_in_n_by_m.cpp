#include<iostream>
#include<string>
#include<algorithm>
#include<climits>

using namespace std;

void MtoN(int a, int b, int i, int j)
{
	int ones = -1;
	int left = (-1 << (j+1));
	int right = (1 << i) - 1;
	int mask = left | right;
	a = (a & mask);
    cout << a<<endl;
    b = (b << i);
	cout << (a | b);
}

int main()
{
	int a, b, i, j;
	cin >> a;
	cin >> i >> j;
	cin >> b;
	MtoN(a, b, i, j);
	//int ones = -1;
	//int left = (ones << (i+1));
//	int right = (1 << i) - 1;
//	int mask = left | right;
	//cout<< (left & a);
	

	
	return 0;
}