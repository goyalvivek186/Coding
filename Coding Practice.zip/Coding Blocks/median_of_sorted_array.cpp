#include<iostream>
using namespace std;
void median(int a[2000], int s)
{
	cout<<a[(s/2) - 1];
}

void merge(int a[1000], int b[1000], int s)
{
	int c[2000];
	int p = 0, q = 0, i = 0;
	while(p < s and q < s)
	{
		if(a[p] < b[q])
		{
			c[i] = a[p];
			p++;
			i++;
		}
		else
		{
			c[i] = b[q];
			q++;
			i++;
		}
	}
		while(p < s)
		{
			c[i] = a[p];
			i++;
			p++;
		}

		while(q < s)
		{
			c[i] = b[q];
			i++;
			q++;
		}
	/*for(i = 0; i < 2*s - 1; i++)
	{
		cout<<c[i];
	}*/

	median(c, 2*s);
}





int main()
{
	int s, a[1000], b[1000];
	cin >> s;
	for(int i = 0; i < s; i++)
	{
		cin >> a[i];
	}
	for(int i = 0; i < s; i++)
	{
		cin >> b[i];
	}
	merge(a, b, s);
	

	
	return 0;
}