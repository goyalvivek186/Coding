#include<iostream>
#include<cstring>
#include<algorithm>
#include<string>
#include<math.h>

using namespace std;



int main()
{
	
	return 0;
}