#include<iostream>
using namespace std;

class node
{
public:
	int data;
	node *next;
	node *prev;

	node(int d)
	{
		data = d;
		next = NULL;
		prev = NULL;
	}

};


void insertathead(node *&head, int d)
{
	if(head == NULL)
	{
		head = new node(d);
		return;
	}	

	node *n = new node(d);
	n->next = head;
	n->prev = NULL;
	head->prev = n;
	head = n;
}

void print(node *head)
{
	while(head != NULL)
	{
		cout<<head->data<<" <=> ";
		head = head->next;
	}
	cout<<endl;
}

void del(node *&head, int d)
{
	if(head -> data == d)
	{
		head = head->next;
		head->prev = NULL;
		return;
	}
	node *t = head;
	while(t->next->data != d and t != NULL)
	{
		t = t->next;
	}
	node *n = t->next->next;
	t->next = n;
	n->prev = t;
	return;
}

int main()
{
	node *head = NULL;
	int n;
	cin >> n;
	while(n--)
	{
		int a;
		cin >> a;
		insertathead(head, a);
	}
	print(head);
	int d;
	cin >> d;
	del(head, d);
	print(head);
	return 0;
}