#include <iostream>
using namespace std;

int search(int *a, int n, int t)
{
    if(n < 0)
    return -1;

    if(a[0] == t)
    {
        return 0;
    }
    int index = search(a+1, n-1, t);
    if(index == -1)
    return -1;
    
    return index + 1;
}

int main() 
{
    int n;
    cin >> n;
    int a[n];
    for(int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    int t;
    cin >> t;
    cout<<search(a, n, t);
    return 0;
}
