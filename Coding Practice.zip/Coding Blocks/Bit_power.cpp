#include<iostream>
#include<string>
#include<algorithm>
#include<climits>
#include<math.h>

using namespace std;



int main()
{
	int n, x;
	cin >> x >> n;
	int ans = 1, i =  1;
	while(n >0)
	{
		if((n&1)>0)
		{
			ans *= x;
		}
		x *= x;
        n = n>> 1;
	}
	cout<<ans;
	
	return 0;
}