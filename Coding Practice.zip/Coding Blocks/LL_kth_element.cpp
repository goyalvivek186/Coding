#include<iostream>
#include<list>

using namespace std;

int main()
{
	list<int> l;
	int a;
	cin >> a;
	while(a != -1)
	{
		l.push_back(a);
		cin >> a;
	}
	auto it = l.begin();
	int x;
	cin >> x;
	while(x--)
	{
		it++;
	}
	auto i = l.begin();
	while(it != l.end())
	{
		it++;
		i++;
	}
	cout<<*i;

	return 0;
}