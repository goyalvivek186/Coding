#include<iostream>
using namespace std;


int main()
{
	int n, i, j;
	cin>>n;
	for(i = 0; i < n; i++)
	{
		for(j = 0; j <= i; j++)
		{
			if(i < 2)
			{
				cout<<"1";
			}
			else 
			{
				cout<<i;
				for(j = 1; j < i; j++)
				{
					cout<<"0";
				}
				cout<<i;
				break;
			}
		}
		cout<<"\n";
	}


	return 0;
}