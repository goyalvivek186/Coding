#include<iostream>

using namespace std;

void wave(int *a, int n)
{
	for(int i = 0; i < n; i += 2)
	{
		if(i==0 and a[i] < a[i+1])
		{
		swap(a[i], a[i+1]);
		}
		else if(i != 0)
		{
			if(a[i]<a[i-1])
			{
				swap(a[i], a[i-1]);
			}
		}
	}
}

int main()
{
	int n, a[100];
	cin >> n;
	for(int i = 0; i < n; i++)
	{
		cin >> a[i];
	}
	wave(a, n);

	for(int i = 0; i < n; i++)
	{
		cout<< a[i]<<" ";
	}

	return 0;
}