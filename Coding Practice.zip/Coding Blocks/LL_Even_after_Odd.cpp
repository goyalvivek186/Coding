#include<iostream>
#include<list>

using namespace std;

int main()
{
	list<int> l, even, odd;
	int n;
	cin >> n;
	while(n--)
	{
		int a;
		cin >> a;
		l.push_back(a);
	}
	for(auto j : l)
	{
		if((j % 2) != 0)
		{
			odd.push_back(j);
		}
		else
		{
			even.push_back(j);
		}
	}
    l.clear();

    for (auto it : even)
	{
		odd.push_back(it);
	}
    even.clear();
    for (auto it : odd)
	{
		cout<<it<<" ";
	}


	return 0;
}