#include<iostream>
#include<stack>

using namespace std;

int main()
{
	stack<int> a, b, c;

	int n, q;
	cin >> n >> q;
	while(n--)
	{
		int x;
		cin >> x;
		a.push(x);
	}

	

	return 0;
}