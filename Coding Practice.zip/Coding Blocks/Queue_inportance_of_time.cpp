#include<iostream>
#include<queue>

using namespace std;

int main()
{
	queue<int> calling, ideal;

	int n, a;
	cin >> n;
	for(int i = 0; i < n; i++)
	{
		cin >> a;
		calling.push(a);
	}
	for(int i = 0; i < n; i++)
	{
		cin >> a;
		ideal.push(a);
	}
	int c = 0;
	while(n--)
	{
		c++;
		while(calling.front() != ideal.front())
		{
			calling.push(calling.front());
			calling.pop();
			c++;
		}
		 
		calling.pop();
		ideal.pop();

	}
	cout<<c;

	return 0;
}