#include<iostream>
#define ll long long

using namespace std;

int gcd(int a, int b)
{
	if(b == 0)
	{
		return a;
	}
	else
		return b, a%b;
}

int main()
{
	ll a, b, e, x, y, ans;
	cin >> a >> b;
	x = a;
	y = b;

	ans = gcd(a, b);
	
	cout<< (x * y)/ans;

	
	return 0;
}