#include<iostream>
#include<climits>

using namespace std;

int main()
{
	int n;
	cin >> n;
	int a[n];
	int ms = 0;
	while(ms < n)
	{
		cin >> a[ms];
		ms++;
	}
	int f = 0, r = ms-1;
	
	for(int i = f; i < ms; i++)
	{
		int x = a[i];
		int m = INT_MAX;
		int j = (i+1) % ms;
		while(j != i)
		{
			if(a[j] > a[i] and a[j] < m)
			{
				m = a[j];
			}
			j = (j+1) % ms;
		}
        if(m == INT_MAX)
        {
            m = -1;
        }
		cout<<m<<" ";
	}


	return 0;
}