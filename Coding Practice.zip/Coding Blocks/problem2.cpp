#include<iostream>
#include<math.h>
#include<conio.h>
#include<stdio.h>
using namespace std;


int main() {
	clrscr();
	int n,a,x=1,y;
	cin>>n;
	while(x<=n)
	{
		cin>>a;
		int i=0,ans=0;
		while(a>0)
		{
			y=a%10;
			a=a/10;
			ans=ans +(pow(2,i) * y);
			i++;
		}
		cout<<ans<<"\n";
		getch();
		x++;
	}


	return 0;
}