#include<iostream>

using namespace std;

void per(char *s, int i)
{
	if(s[i] == '\0')
	{
	cout<<s<<endl;
	return;
	}
    int j;
    for(j = i; s[j] != '\0'; j++)
	{   
        swap(s[i], s[j]);
	    per(s, i+1);
	    swap(s[i], s[j]);
    }
    
    return;
}

int main()
{
	char s[100];
	cin >> s;
	per(s, 0);

	return 0;
}