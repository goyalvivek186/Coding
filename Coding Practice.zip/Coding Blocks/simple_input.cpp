#include<iostream>
using namespace std;


int main() {

	int x=0,a;
	while(x>=0)
	{
		cin>>a;
		x=x+a;
		if (x<0)
		{
			break;
		}
		cout<<a<<"\n";
	}
	return 0;
}