#include<iostream>
using namespace std;

bool park(char a[][100], int n, int m, int s, int k)
{
	
	for(int i = 0; i < n; i++)
	{
        //cout<<"s = "<<s<<endl;
		for(int j = 0; j < m; j++)
		{
			if(a[i][j] == '.')
			{
				s -= 2;
				if(s < k)
				{
					return false;
					break;
				}
			}
			else if(a[i][j] == '*')
			{
				s += 5;
			}
			else if(a[i][j] == '#')
			{
				j = m - 1;
			}
			if(j == m-1)
			{
				s++;
			}
			s--;
			if(s < k)
				{
					return false;
					break;
				}
		}
	}
	cout<<"Yes\n" << s;
	return true;

}

int main()
{
	char a[100][100];
	int n, m, k, s;

	cin>> n >>m >> k >> s;
	
	for(int i= 0; i < n; i ++)
	{
		for(int j = 0; j < m; j++)
		{
			cin >> a[i][j];
		}
	}
	if(park(a, n, m, s, k))
	{
		return 0;
	}
	else
	{
		cout<<"No";
	}

	


	return 0;
}