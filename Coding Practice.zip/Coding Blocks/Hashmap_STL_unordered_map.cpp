#include<iostream>
#include<string>
#include<unordered_map>
using namespace std;

int main()
{
	unordered_map<string, int> m;
	m["Apple"] = 120;
	m["Banana"] = 25;
	m["Mango"] = 200;

	auto it = m.find("Mango");
	cout<<it->second;
	for(auto it : m)
	{
		cout<<it.first <<" -> "<<it.second;
	}

	m.erase("Mango");
	return 0;
}