#include<iostream>
using namespace std;


int main() {

	int n;
	cin>>n;
	for(int i = 1; i <= n; i ++)
	{
		for(int j = 1; j <= i; j++)
		{
			cout<<"1";
			if (i > 2 && i % 2 == 0)
			{
				for(int k = 2; k < i; k++)
				{
					cout<<"0";
				}
				cout<<"1";
				break;
			}
		}
		cout<<"\n";
	}
	return 0;
}