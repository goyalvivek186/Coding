#include<iostream>
#include<queue>

using namespace std;

class stack
{
private:
	queue<int> q1, q2;

public:
	void push(int d)
	{
		q1.push(d);
	}

	void pop()
	{
        if(q1.size() == 0)
        {
            return;
        }
		while(q1.size()>1)
		{
			int x = q1.front();
			q2.push(x);
			q1.pop();
		}
		q1.pop();
		swap(q1, q2);
	}

	int top()
	{
        // if list is empty then top operation not possible

        if (q1.empty()) return 0;

		while(q1.size() > 1)
		{
			int x = q1.front();
			q2.push(x);
			q1.pop();
		}
		int x = q1.front();
		q2.push(x);
        // empty q1 first, it still has "x" in it
        q1.pop();
		swap(q1, q2);
        // cout << q2.size();
		return x;
	}

	bool empty()
	{
		return q1.size()==0;
	}

	int size()
	{
		return q1.size();
	}
};

int main()
{
	stack s;
	int n;
	cin >> n;
	while(n--)
	{
		int a;
		cin >> a;
		s.push(a);
	}
	cout<<s.size()<<endl;
	s.pop();
    cout<<s.size()<<endl;
    cout<<s.top()<<endl;
	while(!s.empty())   
	{
		cout<<s.top()<<endl;
		s.pop();
	}


	return 0;
}