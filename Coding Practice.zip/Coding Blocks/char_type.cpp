#include<iostream>
using namespace std;
char type(char ch)
{
	char ans;
	if(ch >='A' and ch <='Z')
	{
		ans = 'U';
		
	}
	else if( ch >='a' and ch <='z')
	{
		ans = 'L';
	}
	else{
		ans = 'I';
	}
	return ans;
}

int main() 
{
	char ch;
	cin >> ch;
	cout<<type(ch);
	return 0;
}