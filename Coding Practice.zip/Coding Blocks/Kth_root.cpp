#include<iostream>
#include <math.h>
using namespace std;

bool root(long long n, int k, long long m)
{
	if(pow(m,k) > n)
	{
		return false;
	}
	else
	{
		return true;
	}
}


int main()
{
	int k, s = 1, t, ans;
	long long n, e, m;
	cin >> t;
	while(t--)
	{
		cin >> n >> k;
		s = 0;
		e = n;
		while(s <= e)
		{
			m = (s+e)/2;
			if(root(n, k, m))
			{
				ans = m;
				s = m+1;
			}
			else
			{
				e = m-1;
			}
		}
		cout<<ans<<endl;
	}
	
	return 0;
}