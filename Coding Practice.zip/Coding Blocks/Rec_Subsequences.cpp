#include<iostream>

using namespace std;

void sub(char *s, char *ans, int i, int j, int &c)
{
	if(s[i] == '\0')
	{
		ans[j] = '\0';
		cout<<ans<<" ";
        c++;
		return;
	}
	sub(s, ans, i+1, j, c);
	ans[j] = s[i];
	sub(s, ans, i+1, j+1, c);

}

int main()
{
	char s[100], ans[100];
	cin >> s;
    int c = 0;
	sub(s, ans, 0, 0, c);
    cout<<c;

	return 0;
}