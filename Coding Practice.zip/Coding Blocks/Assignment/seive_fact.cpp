#include<iostream>
using namespace std;
void multiply(int *res,int a,int &idx)
{
	int carry=0;
	for(int i=0;i<=idx;i++)
	{
		int ye_wala_mul=a * res[i] + carry;
		res[i]=ye_wala_mul %10;
		carry=ye_wala_mul/10;
	}
	while(carry > 0)
	{
		idx++;
		res[idx]=carry%10;
		carry/=10;
	}
}
int main() {
	int res[999]={0};

	res[0]=1;
	int idx=0;
	int n; cin>>n;
	for(int i=1;i<=n;i++)
	{
		multiply(res,i,idx);
	}
	// ...print res
	for(int i=idx;i>=0;i--)
	{
		cout<<res[i];
	}

	return 0;
}
#include<bits/stdc++.h>
using namespace std;
bool is_prime(int n)
{
    if(n<=1) return false;
    if(n==2) return true;  // case left n=2
    if(n%2==0) return false;
    for(int i=3;i*i<=n;i+=2) // O(root n) 
    {
        if(n%i==0) return false;
    }
    return true;
    // if(n<=1) return false;
    // for(int i=2;i*i<=n;i++)
    // {
    //     if(n%i==0) return false;
    // }
    // return true;
}

vector<int> make_sieve(int max_A)
{
    vector<int> sieve(max_A+3,1);
    sieve[0]=0;
    sieve[1]=0;
    for(int i=4;i<=max_A;i+=2) sieve[i]=0;
    // for(int i=2;i<=max_A;i++)
    for(int i=3;i*i<=max_A;i+=2)
    {
        if(sieve[i]==1) // this number is for sure prime
        {
            // for(int j=2*i;j<=max_A;j+=i) 
            for(int j=i*i;j<=max_A;j+=i)
            {
                sieve[j]=0;
            }
        }
    }
    return sieve;
}
int main()
{
    int n; cin>>n;
    // cout<<is_prime(n)<<endl;
    int max_A=1e6+3;
    vector<int> sieve=make_sieve(max_A); //O(nloglogn)
	vector<int> prefix(max_A);
	for(int i=1;i<=max_A;i++)
	{
		prefix[i]=prefix[i-1] + sieve[i];
	}
    while(n--) // O(n)
    {
        int a,b; cin>>a>>b;
        int cnt=0;
        // for(int i=a;i<=b;i++) //O(b-a)
        // {
        //     cnt+=sieve[i]==1;  //O(1)

		// 	// cnt+=(is_prime(i)); O(rootb)
        // }
		// prefix[b]=0..    a-1,a ....b
		// prefix[a-1]=0,,,,a-1
		cnt=prefix[b]-(a-1>=0?prefix[a-1]:0);
        cout<<cnt<<endl;
    }
	// old:O(b root b * n) space:O(1)
	// improve: O(bloglogb + n * b) space: O(b)
	// improve:O(bloglogb + n)  space:O(b)
    return 0;
}