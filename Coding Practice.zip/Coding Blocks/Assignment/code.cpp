class Solution {
public:
// https://leetcode.com/problems/patching-array/
    int minPatches(vector<int>& nums, int X) {
        long long range=0;
        int i=0;
        int ans=0;
        while(range < X)
        {
            if(i<nums.size() && nums[i] <=range+1)
            {
                range+=nums[i];
                i++;
            }
            else
            {
                ans++;
                range+=range+1;
                // best element to extend our range is range +1
            }
        }
        return ans;
    }
};