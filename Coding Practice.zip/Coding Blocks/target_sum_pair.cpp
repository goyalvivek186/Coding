#include<iostream>
#include<algorithm>
using namespace std;



//   unobtimized




/*
void target_sum_pairs(int n, int a[], int target)
{
	int i, j, sum;
	for(i = 0; i < n; i++)
	{
		for(j = i + 1; j < n; j++)
		{
			sum = a[i] + a[j];
			if(sum == target)
			{
				if(a[i] < a[j])
				{
					cout<<a[i] <<" and "<<a[j]<<endl;
				}
				else
				{
					cout<<a[j] <<" and "<<a[i]<<endl;
				}
			}
		}
	}

}
*/




//       obtimized

void target_sum_pairs(int n, int a[], int target)
{
	sort(a, a + n);

	int l = 0, r = n-1;
	while(l < r)
	{
		if((a[l] + a[r]) == target)
		{
			cout<< a[l]<<" and "<< a[r]<<endl;
			l++;
		}
		else if ((a[l] + a[r]) > target)
		{
			r--;
		}
		else
		{
			l++;
		}
	}
}


int main() {

	int n, a[1000], target, i;

	cin >> n;

	for(i = 0; i < n; i ++)
	{
		cin >> a[i];
	}

	cin >> target;

	target_sum_pairs(n, a, target);

	
	return 0;
}

