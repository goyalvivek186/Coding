#include<iostream>
using namespace std;

bool canplace(int n, int b[][10], int x, int y)
{
	for(int i = 0; i < x; i++)
	{
		if(b[i][y] == 1)
		{
			return false;
		}
	}

	int i = x, j = y;
	while(i >= 0 and j >= 0)
	{
		if(b[i][j] == 1)
		{
			return false;
		}
		i--;
		j--;
	}

	i = x, j = y;
	while(i >= 0 and j > n)
	{
		if(b[i][j] == 1)
		{
			return false;
		}
		i--;
		j++;
	}
	return true;
}

int solveNqueen(int n, int b[][10], int i)
{
	int c = 0;
	if(i == n)
	{
		return 1;
	}

	for(int j = 0; j < n; j++)
	{
		if(canplace(n, b, i, j))
		{
			b[i][j] = 1;
			c += solveNqueen(n, b, i+1);
			b[i][j] = 0;
		}
		return c;
	}
	return c;

}

int main()
{
	int n;
	cin >> n;
	int b[10][10] = {0};
	int c = solveNqueen(n, b, 0);
	cout<<c;
	return 0;
}