#include<iostream>
using namespace std;

void insertion_sort(int s, int a[])
{
	int i, j, e;
	for(i = 1; i < s; i++)
	{
		e = a[i];
		j = i - 1;
		while(j >= 0 and a[j] > e)      //for descending change > to <
		{
			a[j+1] = a[j];
			j--;
		}
		a[j+1] = e;
	}
	cout<<"Sorted array =\n";
	for(i = 0; i < s; i++)
	{
		cout<<a[i]<<"\n";
	}
}


int main()
{
	int s, a[20] = {0};

	cout<<"Enter the size of the array\n";
	cin >> s;
	cout<<"Enter the elements\n\n";

	for(int i = 0; i < s; i++)
	{
		cin >> a[i];
	}
	insertion_sort(s, a);



	return 0;
}