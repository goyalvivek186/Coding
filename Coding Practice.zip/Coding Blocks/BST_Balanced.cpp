#include<iostream>
#include<queue>
using namespace std;

class node
{
public:
	int data;
	node *right, *left;

	node(int d)
	{
		data = d;
		right = NULL;
		left = NULL;
	}
};

/*node *insert(node *root, int d)
{
	if(root == NULL)
	{
		node *root = new node(d);
	}

	//root->right and left are important unless the returned valeue will be lost.

	if(root->data < d)
	{
		root->right = insert(root->right, d);
	}
	else
	{
		root->left = insert(root->left, d);
	}
	return root;

}*/

node *build_balanced(int *a, int s, int e)
{
	if(s > e)
	{
		return NULL;
	}
	int m = (s+e)/2;
	node *root = new node(a[m]);
	root->left = build_balanced(a, s, m-1);
	root->right = build_balanced(a, m+1, e);
	return root;
}

void preorder(node *root)
{
	if(root == NULL)
	{
		return;
	}
	cout<<root->data<<" ";
	preorder(root->left);
	preorder(root->right);
}
/*
void BFS(node *root)
{
	queue<node *> q;
	q.push(root);
	q.push(NULL);
	while(!q.empty())
	{
		node *f = q.front();
		q.pop();
		if(f == NULL)
		{
			cout<<endl;
			if(!q.empty())
			{
				q.push(NULL);
			}
		}
		else
		{
			cout<<f->data<<"  ";
			if(f->left)
			{
				q.push(f->left);
			}
			if(f->right)
			{
				q.push(f->right);
			}
		}
	}
}
*/
int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n;
		cin >> n;
		int a[n];
		for(int i = 0; i < n; i++)
		{
			cin >> a[i];
		}

		node *root = build_balanced(a, 0, n-1);

		preorder(root);
        cout<<endl;
	}

	return 0;
}