#include<iostream>
#include<queue>
using namespace std;

class node
{
public:
	int data;
	node *left;
	node *right;

	node(int d)
	{
		data = d;
		left = NULL;
		right = NULL;
	}
};

node *build()
{
	int d, n;
	cin >> d >> n;
	node *root = new node(d);
	if(n == 0)
	{
		root->left = NULL;
		root->right = NULL;
	}
	else if(n == 1)
	{
		root->left = build();
		root->right = NULL;
	}
	else
	{
		root->left = build();
		root->right = build();
	}

	return root;
}

/*
void BFS(node *root)
{
	queue<node* > q;
	q.push(root);
	q.push(NULL);
	node *f;
	while(!q.empty())
	{
		f = q.front();
		q.pop();
		if(f == NULL)
		{
			cout<<endl;

			if(!q.empty())
			{
				q.push(NULL);
			}
		}

		else
		{
			cout<<f->data<<" ";
			if(f->left)
			{
				q.push(f->left);
			}
			if(f->right)
			{
				q.push(f->right);
			}
		}
	}
}
*/

int sum_at_k(node *root, int l, int k)
{
    if(root == NULL)
    {
        return 0;
    }
	if(l > k)
	{
		return 0;
	}
	if(l == k)
	{
		return root->data;
	}
	
	int left = sum_at_k(root->left, l+1, k);
	int right = sum_at_k(root->right, l+1, k);

	return left+right;
}

int main()
{

	node* root = build();

	int k;
	cin >> k;

	cout<<sum_at_k(root, 0, k);

	//BFS(root);
	return 0;
}