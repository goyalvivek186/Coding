#include<iostream>
using namespace std;

class node
{
	public:
	int data;
	node* next;

	node(int d)
	{
	data = d;
	next = NULL;
	}
	
};

void input(node *& head, int d)
{
	if(head == NULL)
	{
		head = new node(d);
		return;
	}

	node *temp = new node(d);
	temp->next = head;
	head = temp;
	

}
/*
void print(node *head)
{
	while(head != NULL)
	{
		cout<<head->data<<" ";
		head = head->next;
	}
	return;
}*/

void print(node *head)
{
	if(head == NULL)
	{
		return;
	}
	cout<<head->data<<" ";
	print(head->next);
	
}


int main()
{
	node *head = NULL;
	int n;
	cin >> n;
	while(n--)
	{
		int a;
		cin >> a;
		input(head, a);
	}

	print(head);
	cout<<endl;
	



	return 0;
}