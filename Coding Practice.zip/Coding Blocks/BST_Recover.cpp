#include<iostream>
using namespace std;

class node
{
public:
	int data;
	node *right;
	node *left;

	node(int d)
	{
		data = d;
		right = left = NULL;
	}
};

node *build()
{
	int d;
	cin >> d;
	if(d != -1)
	{
		node *root = new node(d);
		root->left = build();
		root->right = build();
	}

	return NULL;
}

int main()
{


	return 0;
}