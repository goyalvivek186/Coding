#include<iostream>
using namespace std;
int main()
{
	cout<<"Enter the number\n";
	int s=0,n,r,x;
	cin>>n;
	while(n!=0)
	{
		x = n%10;
		n = n/10;
		s = s+x;
	}

	cout<<"sum of digits = "<<s;
	return 0;
}