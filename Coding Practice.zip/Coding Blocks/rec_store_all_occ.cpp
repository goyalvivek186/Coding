#include<iostream>
#include<string>
#include<algorithm>
#include<climits>
#include<math.h>

using namespace std;

int occ(int *a, int n, int t, int i, int *ans, int j)
{

	if(n == 0)
	{
		return j;
	}
	if(a[0] == t)
	{
        ans[j] = i;
		j++;
	}
	return occ(a+ 1, n - 1, t, i+1, ans, j);
}

int main() 
{
    int n;
    cin >> n;
    int a[n];
    for(int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    int t;
    cin >> t;
    int i = 0, j = 0;
    int ans[n], c;
    c = occ(a, n, t, i, ans, j);
    cout<<c<<endl;
    for(int i = 0; i < c; i++)
    {
        cout<<ans[i]<<endl;
    }
    return 0;
}