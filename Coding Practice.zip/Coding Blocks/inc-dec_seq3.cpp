#include<iostream>
using namespace std;

int main()
{
	int a[10], s, i, x;
	cin>>s;
	for(i = 0; i < s; i++)
	{
		cin>> a[i];
	}

	for(i = 0; i < s; i++)
	{
		if( a[i] > a[i+1])
		{
			x = i;
			break;
		}
		/*else if( a[i] == a [i+1])
		{
			cout<<"False\n";
			exit(-1);
		}*/
	}
	for(i = x; i <s; i++)
	{
		if( a[i] < a[i+1] || a[i] == a[i+1])
		{
			break;
		}
	}
		if( i == s )
		{
			cout<<"True\n";
		}
		else
		{
			cout<<"False\n";
		}



	return 0;
}