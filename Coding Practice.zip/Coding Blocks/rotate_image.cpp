#include<iostream>
#include<algorithm>
using namespace std;
//anticlockwise
void rotate(int a[][10], int n)
{
	int i, j, k;
	for(i = 0; i < n; i++)
	{
		j = 0;
		k = n-1;
		while(j <= k)
		{
			swap(a[i][j], a[i][k]);
			j++;
			k--;
		}
	}

	i = 0;
	j = n;
	for(i = 0; i < n; i++)
	{
		for(j = 0; j <= i; j++)
		{
			swap(a[i][j], a[j][i]);
		}
	}


	for(i = 0; i < n; i++)
	{
		for(j = 0; j < n; j++)
		{
			cout<< a[i][j]<<" ";
		}
		cout<<endl;
	}

}



int main()
{
	int a[10][10];
	int n, i, j;
	cin >>n;
	for(i = 0; i < n; i++)
	{
		for(j = 0; j < n; j++)
		{
			cin >> a[i][j];
		}
	}
	rotate(a, n);

	
	return 0;
}