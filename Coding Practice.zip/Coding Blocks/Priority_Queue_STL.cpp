#include<iostream>
#include<queue>
#include<cstring>
using namespace std;

class fun			//Fucntor
					//Function Object
{
public:
	void operator()(string s)
	{
		cout<<"In function with "<<s<<endl;
	}
};


int main()
{
	priority_queue<int> pq_max;
	priority_queue<int, vector<int>, greater<int>> pq_min;
	int n, no;

	fun f;
	f("C++");

	cin >> n;
	for(int i = 0; i < n; i++)
	{
		cin >> no;
		pq_max.push(no);
	}

	while(!pq_max.empty())
	{
		cout<<pq_max.top();
		pq_max.pop();
	}
	return 0;
}