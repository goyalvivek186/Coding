#include<iostream>
#include<stack>

using namespace std;

template <typename t>
class queue
{
private:
	stack<t> s1, s2;

public:
	void push(t d)
	{
		s1.push(d);
	}

	void pop()
	{
		while(s1.size() > 1)
		{
			s2.push(s1.top());
			s1.pop();
		}
		s1.pop();
		while(!s2.empty())
		{
			s1.push(s2.top());
			s2.pop();
		}
	}

	int front()
	{
		while(s1.size() > 1)
		{
			s2.push(s1.top());
			s1.pop();
		}
		int x = s1.top();
		s2.push(s1.top());
		s1.pop();

		while(!s2.empty())
		{
			s1.push(s2.top());
			s2.pop();
		}

		return x;
	}

	bool empty()
	{
		return s1.size() == 0;
	}

	int size()
	{
		return s1.size();
	}
};

int main()
{
	queue<int> q;
	int n;
	cin >> n;
	while(n--)
	{
		int a;
		cin >> a;
		q.push(a);
	}

	cout<<q.size()<<endl;
	cout<<q.front()<<endl;
	q.pop();
	cout<<q.front()<<endl;
	q.pop();

	while(!q.empty())
	{
		cout<<q.front()<<endl;
		q.pop();
	}



	return 0;
}