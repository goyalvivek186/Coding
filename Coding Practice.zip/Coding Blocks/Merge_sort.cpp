#include<iostream>

using namespace std;

void mergearr(int *a, int s, int e)
{
    int m = (s+e)/2;
	int i = s;
	int j = m+1;
	int k = s;
	int temp[200002] = {0};
	while(i <= m and j <= e)
	{
	if(a[i] < a[j])
		{
			temp[k] = a[i];
			i++;
			k++;
		}
	else
	{
	temp[k] = a[j];
	k++;
	j++;
	}
	}

	while(i < m+1)
	{
	temp[k] = a[i];
	k++;
	i++;
	}
	while(j <= e)
	{
	temp[k] = a[j];
	k++;
	j++;
	}
	for(i = s; i  <= e; i++)
	{
	a[i] = temp[i];
	}

}

void merge(int *a, int s, int e, int m)
{
	if(s>=e)
	{
	return;
	}
	merge(a, s, m, (s+m)/2);
	merge(a, m+1, e, (m+e+1)/2);
	mergearr(a, s, e);
}

int main()
{
	int n;
	cin >> n;
	int a[200002];
	for(int i = 0; i < n; i++)
	{
	cin>>a[i];
	}
	merge(a, 0, n-1 , (n-1)/2);
    for(int i = 0; i < n; i++)
    {
        cout<<a[i]<<" ";
    }


	return 0;
}