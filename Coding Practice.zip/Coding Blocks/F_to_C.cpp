#include<iostream>
using namespace std;



int main() {
	int min, max, step, c;
	cin>>min>>max>>step;
	while(min<=max)
	{
		c= (5/9.0)*(min - 32);
		cout<<min<<"\t"<<c<<"\n";
		min = min + step;
	}

	return 0;
}