#include<iostream>
#include<climits>
using namespace std;

class node
{
public:
	int data;
	node *right;
	node *left;

	node(int d)
	{
		data = d;
		right = NULL;
		left = NULL;
	}
};

node *insertinBST(node *root, int d)
{
	if(root == NULL)
	{
		return new node(d);
	}

	if(d > root->data)
	{
		root->right = insertinBST(root->right, d);
	}

	else
	{
		root->left = insertinBST(root->left, d);
	}
	return root;
}

node *build()
{
	int d;
	node *root = NULL;
	cin >> d;
	while(d != -1)
	{
		root = insertinBST(root, d);
		cin >> d;
	}
	return root;
}

void inorder(node *root)
{
	if(root == NULL)
	{
		return ;
	}
	inorder(root->left);
	cout<<root->data<<" ";
	inorder(root->right);
}

class check
{
public:
	bool is;
	int maxi, mini;

};

check is_BST(node* root)
{
	if(root == NULL)
	{
		check ans;
		ans.maxi = INT_MIN;
		ans.mini = INT_MAX;
		ans.is = true;
		return ans;
	}
	check left = is_BST(root->left);
	check right = is_BST(root->right);
	check ans;
	ans.is = left.is and right.is and root->data > left.maxi and root->data <= right.maxi;
	ans.maxi = max(root->data, max(left.maxi, right.maxi));
	ans.mini = min(root->data, min(left.mini, right.mini));
	return ans;
}

bool is_BST_adv(node* root, int mini = INT_MAX, int maxi = INT_MIN)
{
	if(root == NULL)	return true;
	if(root->data < maxi and root->data > mini and is_BST_adv(root->left, mini, root->data) and is_BST_adv(root->right, root->data, maxi))
	{
		return true;
	}
	return false;

}

int get(node* root)
{
	if(root->right == NULL)
	{
		return root->data;
	}
	return get(root->right);
}


node*  del(node* root, int data)
{
	if(root == NULL)	return NULL;
	if(root->data == data)
	{
		if(root->left == NULL and root->right == NULL)	return NULL;
	}
	if(root->left == NULL and root->right != NULL)
	{
		return root->right;
	}
	if(root->right == NULL and root->left != NULL)
	{
		return root->left;
	}
	else
	{
		int no = get(root->left);
		root = del(root, no);
		root->data = no;
		return root;
	}
	if(root->data > data)
	{
		root->left = del(root->left, data);
	}
	else
	{
		root->right = del(root->right, data);
	}
}

int main()
{
	node *root = build();
	return 0;
}