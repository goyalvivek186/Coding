#include<iostream>
#include<algorithm>

using namespace std;


int main()
{
	int c1, c2, c3, c4, t, n, m;
	cin >> t;
	while(t--)
	{
		cin >>c1 >> c2 >> c3 >> c4;
		cin >>n >> m;
		int r[n], c[m];
		for(int i = 0; i < n; i++)
		{
			cin >> r[i];
		}
		for(int i = 0; i < m; i++)
		{
			cin >> c[i];
		}

		int p1 = 0, p2 = 0, ans;
		for(int i = 0; i < n; i++)
		{
			p1 += (min((r[i] * c1), c2));
		}
		p1 = min(p1, c3);
		for(int i = 0; i < m; i++)
		{
			p2 += (min((c[i] * c1), c2));
		}
		p2 = min(p2, c3);
		cout<<min((p1 + p2), c4)<<endl;

	}
	
	return 0;
}