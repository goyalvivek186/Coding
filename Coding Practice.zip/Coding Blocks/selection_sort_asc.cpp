#include<iostream>
#include<climits>
using namespace std;

void selection_sort(int s, int a[])
{
	int i, j, p, temp;
	for(i = 0; i < s-1; i++)
	{
		int sm = INT_MAX;
		for(j = i; j < s; j++)
		{
			if(a[j] < sm)
			{
				sm = a[j];
				p = j;
			}
		}
		swap(a[i], a[p]);
		/*temp = a[p];
		a[p] = a[i];
		a[i] = temp;*/
	}
	cout<<"Sorted array =\n";
	for(i = 0; i < s; i++)
	{
		cout<<a[i]<<"\n";
	}
}


int main()
{
	int s, a[20] = {0};

	cout<<"Enter the size of the array\n";
	cin >> s;
	cout<<"Enter the elements\n";

	for(int i = 0; i < s; i++)
	{
		cin >> a[i];
	}
	selection_sort(s, a);
	

	return 0;
}