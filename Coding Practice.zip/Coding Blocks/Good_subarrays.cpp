#include<iostream>
#include<vector>
#include<unordered_map>

using namespace std;

int good_subarray(vector<int> &v, int n)
{
	unordered_map<int, int> m;
	m[0] = 1;
	int sum = 0;
	for(int i = 0; i < n; i++)
	{
		sum += v[i];
		sum %= n;
		if(m.find(sum) != m.end())
		{
			m[sum]++;
		}
		else	m[sum] = 1;
	}
	int ans = 0;
	for(auto i : m)
	{
		int x = i.second;
		if(x > 1)
		{
			ans += (x*(x-1))/2;
		} 
	}
	return ans;
}

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n;
		cin >> n;
		vector<int> v(n, 0);
		for(int i = 0; i < n; i++)	cin >> v[i];
		cout<<good_subarray(v, n)<<endl;
		v.clear();
	}


	return 0;
}