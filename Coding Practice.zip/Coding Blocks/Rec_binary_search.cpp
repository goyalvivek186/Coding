#include<iostream>
#include<string>
#include<algorithm>
#include<climits>
#include<math.h>

using namespace std;

int binary(int a[], int n, int t, int s, int e)
{
	int m = (s+e)/2;
	if(s>e)
	{
		return -1;
	}
	else if(a[m] == t)
	{
		return m;
	}
	else if(a[m] > t)
	{
		return binary(a, n, t, s, m-1);
	}
	else
	{
		return binary(a, n, t, m+1, e);
	}
    //return -1;
}


int main()
{
	int n;
	cin >> n;
	int a[n];
	for(int i = 0; i < n; i++)
	{
		cin >> a[i];
	}
	int t;
	cin >> t;
	int s = 0, e = n;

	cout<<binary(a, n, t, s, e);

	
	return 0;
}