#include<iostream>

using namespace std;

void dns(int *a, int n)
{
	int s = 0, e = n-1, i = 0;
	while(i <= e)
	{
		if(a[i] == 1)
		{
			i++;
		}
		else if(a[i] < 1)
		{
			swap(a[i] , a[s]);
			s++;
		}
		else
		{
			swap(a[i], a[e]);
			e--;
		}
	}
}

int main()
{
	int n;
	cin >> n;
	int a[100];
	for(int i = 0; i < n; i++)
	{
		cin >>a[i];
	}
	dns(a, n);
	for(int i = 0; i < n; i++)
	{
		cout<< a[i]<<" ";
	}

	return 0;
}