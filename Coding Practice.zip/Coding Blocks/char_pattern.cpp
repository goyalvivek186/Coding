#include<iostream>
using namespace std;
void printpattern(int n)
{
	int i, j;
	char ch;

	for(i = n; i > 0; i--)
	{
		char ch='A';
		for(j = 1; j <= i; j++, ch++)
		{
			cout<< ch;
		}
		cout<<"\n";
	}

}


int main()
{
	int n;
	cout<<"Enter the value of n\n";
	cin>>n;
	printpattern(n);

	



	return 0;
}