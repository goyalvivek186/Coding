#include<iostream>
#include<climits>
#include<string.h>
using namespace std;


int main()
{
	
	char ch[1000];
	int i, j, c = INT_MIN, m = INT_MIN, p;
	cin >> ch;
	for(i = 0; i < strlen(ch); i++)
	{
		c = 0;
		for(j = 0; j < strlen(ch); j++)
		{
			if(ch[i] == ch[j])
			{
				c++;
			}
		}
		if(c > m)
		{
			m = c;
			p = i;
		}
	}
	cout<<ch[p];
	
	return 0;
}