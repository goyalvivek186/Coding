#include<iostream>

using namespace std;

class node
{
public:
	int data;
	node* next;

	node(int d)
	{
		data = d;
		next = NULL;
	}
};


node *merge_list(node *h1, node *h2)
{
	if(h1 == NULL)
	{
		return h2;
	}
	if(h2 == NULL)
	{
		return h1;
	}
	
	node *head;

	if(h1->data < h2->data)
	{
		head = h1;
		head->next = merge_list(h1->next, h2);
	}
	else
	{
		head = h2;
		head->next = merge_list(h1, h2->next);
	}
	return head;

	

}

int kpos(node *head, int k)
{
	node *sstep = head;
	node *lstep = head;
	while(k--)
	{
		lstep = lstep->next;
	}
	while(lstep != NULL)
	{
		lstep = lstep->next;
		sstep = sstep->next;
	}
	return sstep->data;
}


//INSPIRED BY RINNERS TECHNIQUE
node* reverse(node *head)
{
	node *p = NULL;
	node *c = head;
	node *n = c->next;
	while(c!=NULL)
	{
		n = c->next;	
		c->next = p;
		p = c;
		c = n;
	}
	return p;
}

//MID-POINT RUNNER TECHNIQUE
node* middle(node *head)
{
	if(head == NULL or head->next == NULL)
	{
		return head;
	}
	node *sstep = head;
	node *lstep = head->next;
	while(lstep != NULL and lstep->next != NULL)
	{
		sstep = sstep->next;
		lstep = lstep->next->next;
	}
	return sstep;
}


void print(node * head)
{
	while(head != NULL)
	{
		cout<<head->data<<"-> ";
		head = head->next;
	}
	cout<<"NULL"<<endl;
}

//OPERATOR OVERLOADING
ostream& operator <<(ostream &cout, node* head)
{
	print(head);
	return cout;
}


int length(node * head)
{
	int i = 0;
	while(head != NULL)
	{
		head = head->next;
		i++;
	}
	return i;
}



void insertathead(node *& head, int d)
{
	if(head == NULL)
	{
		head = new node(d);
		return;
	}
	node * temp = new node(d);
	temp->next = head;
	head = temp;
}



void insertinmiddle(node *& head, int d, int p)
{
	if(head == NULL)
	{
		insertathead(head, d);
		return;
	}
	if(p > length(head))
	{
		return;
	}
	node * temp = new node(d);
	node * t = head;
	int jump = 1;
	while(jump < p)
	{
		t = t->next;
		jump++;
	}
	temp->next = t->next;
	t->next = temp;

}



void insertattail(node *&head, int d)
{
	if(head == NULL)
	{
		insertathead(head, d);
		return;
	}
	node * tail = head;
	while(tail->next != NULL)
	{
		tail = tail->next;
	}
	node* n = new node(d);
	tail->next = n;

}

node *merge(node *h1)
{
	if(h1 == NULL or h1->next == NULL)
	{
		return h1;
	}
	node* m = middle(h1);
	node *temp = m->next;
	m->next = NULL;

	node *l = merge(h1);
	node *r = merge(temp);
	node *head = merge_list(l, r);
}

void del(node *&head, int d)
{
	if(head->data == d)
	{
		head = head->next;
		return;
	}
	node *t = head;

	while(t->next->data != d)
	{
		t = t->next;
	}
	t -> next = t->next->next;
	return;

}

int main()
{
	node *head1 = NULL;
	//node *head2 = NULL;
	int n, m;
	cin >> n;

	while(n--)
	{
		int a;
		cin >> a;
		insertattail(head1, a);
	}

	/*cin >> m;

	while(m--)
	{
		int b;
		cin >> b;
		insertattail(head2, b);
	}
*/
	cout<<head1;

	cin >> m;
	del(head1, m);
	cout<<head1;
	//cout<<middle(head1);

	//node *head = merge(head1);
	//cout<<head;

	//insertathead(head, 5);
	//insertathead(head, 4);
	/*insertathead(head, 3);
	insertathead(head, 2);
	insertathead(head, 1);*/
	//print(head);
	//cout<<endl;
/*	insertinmiddle(head, 4, 3);
	//print(head);
	//cout<<endl<<length(head);
	insertattail(head, 6);
	//cout<<endl;
	//cout<<head;
	head = reverse(head);
	//cout<<head;
	int m = middle(head);
	//cout<<m<<endl;
	insertathead(head, 7);
	//cout<<head;
	/*m = middle(head);
	cout<<m<<endl;*/
	//insertathead(head, 8);
	//cout<<head;

	/*m = middle(head);
	cout<<m<<endl;

	int k;
	cin >> k;
	int p = kpos(head, k);
	cout<<p;*/



	return 0;
}