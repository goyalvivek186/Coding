#include<iostream>
#include<queue>
using namespace std;

class node
{
public:
	int data;
	node *right;
	node *left;

	node(int d)
	{
		data = d;
		left = NULL;
		right = NULL;
	}
};

node *build()
{
	int d;
	cin >> d;
	node *root;
	if(d != -1)
	{
		root = new node(d);
	}
	queue<node *> q;
	q.push(root);
	node *f;
	while(!q.empty())
	{
		f = q.front();
		q.pop();
		int d1, d2;
		cin >> d1 >> d2;
		if(d1 != -1)
		{
			f->left = new node(d1);
			q.push(f->left);
		}

		if(d2 != -1)
		{
			f->right = new node(d2);
			q.push(f->right);
		}
	}
	return root;
}

void right(node *root, int c_in, int &m_in)
{
	if(root == NULL)
	{
		return;
	}
	if(c_in > m_in)
	{
		cout<<root->data<<" ";
		m_in = c_in;
	}
	c_in ++;
	right(root->right, c_in, m_in);
	right(root->left, c_in, m_in);
}

void left(node *root, int c_in, int &m_in)
{
	if(root == NULL)
	{
		return;
	}
	if(c_in > m_in)
	{
		cout<<root->data<<" ";
		m_in = c_in;
	}
	c_in ++;
	left(root->left, c_in, m_in);
	left(root->right, c_in, m_in);
}

int main()
{
	node *root = build();
	int max = -1;
	left(root, 0, max);

	return 0;
}