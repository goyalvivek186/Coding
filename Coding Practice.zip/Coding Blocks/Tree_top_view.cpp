#include<iostream>
#include<vector>
#include<queue>
#include<map>
using namespace std;

class node
{
public:
	int data;
	node *right;
	node *left;
	node(int d)
	{
		data = d;
		right = NULL;
		left = NULL;
	}
};

node *build_tree()
{
	queue<node *> q;
	int d;
	cin >> d;
	node* root;
	if(d != -1)
	{
		root = new node(d);
		q.push(root);
	}

	while(!q.empty())
	{
		node *f = q.front();
		q.pop();
		int d1, d2;
		cin >> d1 >> d2;
		if(d1 == -1)
		{
			f->left = NULL;
		}
		else
		{
			f->left = new node(d1);
			q.push(f->left);
		}

		if(d2 == -1)
		{
			f->right = NULL;
		}
		else
		{
			f->right = new node(d2);
			q.push(f->right);
		}
	}
	return root;
}

void top(node *root, int d, map<int, vector<int> > &m)
{
	if(root == NULL)
	{
		return;
	}

	m[d].push_back(root->data);
	top(root->left, d-1, m);
	top(root->right, d+1, m);

}

int main()
{
	node *root = build_tree();
	map<int, vector<int> > m;
	top(root, 0, m);

	for(auto i : m)
	{
		cout<<i.second[0]<<" ";
	}

	return 0;
}