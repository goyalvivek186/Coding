#include<iostream>
using namespace std;

int main() {
	char ch;
	int a,b,ans;
	do
	{
		cin>>ch;
		if (ch == 'x'|| ch == 'X')
		{
			break;
		}
		else if (ch!='+' && ch!='-'&& ch!='*' && ch!='/' && ch!='%')
		{
			cout<<"Invalid operation. Try again.\n";
			continue;
		}
		cin>>a>>b;
		if (ch=='+')
		{
			ans= a+b;
		}
		else if(ch == '-')
		{
			ans = a-b;
		}
		else if (ch == '*')
		{
			ans = a*b;
		}
		else if (ch=='/')
		{
			ans = a/b;
		}
		else if (ch == '%')
		{
			ans = a%b;
		}
		else 
		{
			cout<<"Invalid operation. Try again.\n";
			continue;
		}
		cout<<ans<<"\n";

	}while(ch!='x'||ch!='X');
	return 0;
}