#include<iostream>
#include<string>
#include<algorithm>
#include<climits>

using namespace std;

bool compare(pair<int, int> p1, pair<int, int> p2)
{
	if(p1.second == p2.second)
	{
		return p1.first < p2.first;
	}
	return p1.second < p2.second;
}

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n;
		cin >> n;
		pair<int, int> p[n];
		for(int i = 0; i < n; i++)
		{
			int a, b;
			cin >>a >> b;
			p[i].first = a;
			p[i].second = b;
		}
		sort(p, p+n, compare);
		int c = p[0].second;
		int cnt = 1;
		for(int i = 1; i < n; i++)
		{
			if(p[i].first >= c)
			{
				cnt++;
				c = p[i].second;
			}
		}
		cout<<cnt<<endl;
	}
	
	

	
	return 0;
}