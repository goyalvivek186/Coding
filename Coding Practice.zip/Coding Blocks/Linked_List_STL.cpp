#include <iostream>
#include <list>

using namespace std;
int main()
{
	list<int> l;
	int n;
	cin >> n;
	while(n--)
	{
		int a;
		cin >> a;
		l.push_back(a);
	}
	for(auto it = l.begin(); it != l.end(); it++)
	{
		cout<<* it<<" " ;
	}
	for (auto it : l){
		cout<<it<<" ";
	}


	return 0;
}