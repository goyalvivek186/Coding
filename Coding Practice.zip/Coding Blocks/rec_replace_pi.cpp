#include<iostream>
#include<cstring>

using namespace std;

void pi(char ch[], int n)
{
	if(ch[n] == '\0')
	{
		return;
	}
	if(ch[n] == 'p' and ch[n + 1] == 'i')
	{
		int j = strlen(ch);
		while(j > n+1)
		{
			ch[j + 2] = ch[j];
            j--;
		}
		ch[n] = '3';
		ch[n + 1] = '.';
		ch[n + 2] = '1';
		ch[n + 3] = '4'; 
        pi(ch, n + 3);
	}
	pi(ch, n + 1);
}


int main()
{
	int t;
	cin >> t;

	while(t--)
	{
		char ch[1001];
		cin >> ch;
		pi(ch, 0);
        cout<<ch << endl;
	}

	return 0;
}