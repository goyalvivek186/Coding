#include<iostream>

using namespace std;

int rob(int *a, int n, int i)
{
	if(i > n)
	{
		return 0;
	}
	int x = a[i] + rob(a, n, i+2);
	int y = 0, z = i;
	y = rob(a, n, z+2);
	return max(x, y);
}

int main()
{
	int t;
	cin >> t;

	while(t--)
	{
	int n;
	cin >> n;
	int a[n];
	for(int i = 0; i < n; i++)
	{
		cin >> a[i];
	}
	int amt = rob(a, n-1, 0);
	}
}