#include<iostream>
#include <vector>
using namespace std;

class stack
{
private:
	vector<int> v;
	vector<int> mins;
	vector<int> maxs;
public:
	void push(int d)
	{
		v.push_back(d);
		if(mins.empty())
		{
			mins.push_back(d);
		}
		else
		{
			mins.push_back(min(mins[mins.size() - 1], d));
		}

		if(maxs.empty())
		{
			maxs.push_back(d);
		}
		else
		{
			maxs.push_back(max(maxs[maxs.size() - 1], d));
		}
	}

	void pop()
	{
		v.pop_back();
		mins.pop_back();
		maxs.pop_back();
	}

	int top()
	{
		return v[v.size() - 1];
	}

	int maxv()
	{
		return maxs[maxs.size() - 1]; 
	}

	int minv()
	{
		return mins[mins.size() - 1];
	}

    bool empty()
    {
        return v.empty();
    }
};


int main()
{
	stack s;

	int n;
	cin >> n;
	while(n--)
	{
		int a;
		cin >> a;
		s.push(a);
	}
	cout<<"max = "<<s.maxv()<<endl;
	cout<<"min = "<<s.minv()<<endl;
    cout<<"Top = "<<s.top()<<endl;
    s.pop();
    cout<<endl;
    cout<<"max = "<<s.maxv()<<endl;
	cout<<"min = "<<s.minv()<<endl;
    cout<<"Top = "<<s.top()<<endl<<endl;

    if(s.empty())
    {
        cout<<"Yes"<<endl;
    }
    else{
        cout<<"No"<<endl;
    }
    cout<<endl;
    while(!s.empty())
    {
        cout<<s.top()<<endl;
        s.pop();
    }
    cout<<endl;
    if(s.empty())   
    {
        cout<<"Yes"<<endl;
    }
    else{
        cout<<"No"<<endl;
    }   
	return 0;
}