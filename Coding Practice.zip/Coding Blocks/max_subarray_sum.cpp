#include<iostream>
#include<string>
#include<algorithm>
#include<climits>

using namespace std;



int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n, m = INT_MIN;;
		cin >> n;
		int a[n] ,b[n] = {0};
		cin >> a[0];
		b[0] = a[0];
		for(int i = 1; i < n; i++)
		{
			cin >> a[i];
			b[i] = a[i] + b[i-1];
		}
		for(int i = 0; i < n; i++)
		{
			int cur = 0;
			for(int j = i; j < n; j++)
			{
				cur = b[j] - b[i-1];
                m = max(m, cur);
			}
			
            m = max(m, b[i]);
		}
		cout<<m<<endl;

	}
	
	return 0;
}