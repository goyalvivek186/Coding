#include<iostream>

using namespace std;

class node
{
public:
	int data;
	node *next = NULL;
	node(int d)
	{
		data = d;
		next = NULL;
	}
};

void insertattail(node *&head, int d)
{
	if(head == NULL)
	{
		head = new node(d);
		return;
	}
	node *n = new node(d);
	node * t = head;
	while(t->next != NULL)
	{
		t = t->next;
	}
	t->next = n;
	n ->next = NULL;
}

node *mergelist(node *h1, node *h2)
{
	if(h1 == NULL)
	{
		return h2;
	}
	if(h2 == NULL)
	{
		return h1;
	}

	node *head = NULL;
	if(h1->data < h2->data)
	{
		head = h1;
		head->next = mergelist(h1->next, h2);
	}
	else
	{
		head = h2;
		head->next = mergelist(h1, h2->next);
	}
	return head;
}

void print(node *head)
{
	while(head != NULL)
	{
		cout<<head->data<<" ";
		head = head->next;
	}
	cout<<endl;
}

int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		node *head1 = NULL;
		node *head2 = NULL;
		int n, a;
		cin >> n;
		while(n--)
		{
			cin >> a;
			insertattail(head1, a);
		}
		int m;
		cin >>m;
		while(m--)
		{
			cin >> a;
			insertattail(head2, a);
		}
		node *head = mergelist(head1, head2);
		print(head);
	}



	return 0;
}