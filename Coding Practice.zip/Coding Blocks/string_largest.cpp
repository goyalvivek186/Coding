
#include<iostream>
#include<cstring>
using namespace std;


int main()
{
	int i, n, s= 0, sl = 0;
	char ch1[50], ch2[50];
	cout<<"Enter the testcases";
	cin >> n;
	cin.get();
	for(i = 0; i < n; i++)
	{
		if(i == 0)
		{
			//cout<<"Enter the ist string\n";
			cin.getline(ch1, 50);
			sl = strlen(ch1);
		}
		else
		{
			//cout<<"Enter the next string\n";
			cin.getline(ch2, 50);
			s = strlen(ch2);
		}
		if(s > sl)
		{
			strcpy(ch1, ch2);
			sl = s;
		}


	}
	cout<<"the largest string =\n";
	cout<<ch1;
	cout<<endl<<sl;
	


	
	return 0;
}