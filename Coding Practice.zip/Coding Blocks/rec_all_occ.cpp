#include<iostream>
#include<string>
#include<algorithm>
#include<climits>
#include<math.h>

using namespace std;

void occ(int *a, int n, int t, int i)
{

	if(n == 0)
	{
		return;
	}
	if(a[0] == t)
	{
		cout<<i<<endl;
	}
	occ(a+ 1, n - 1, t, i+1);
}

int main() 
{
    int n;
    cin >> n;
    int a[n];
    for(int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    int t;
    cin >> t;
    int i = 0;
    occ(a, n, t, i);
    return 0;
}