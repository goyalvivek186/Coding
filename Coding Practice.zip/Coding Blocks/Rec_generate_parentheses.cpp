#include<iostream>

using namespace std;

void bracket(int n, char *s, int i, int j, int k)
{
	if(i == n and j == n)
	{
		s[k] = '\0';
		cout<<s<<endl;
	}

	if(i < n and i >= j)
	{
		s[k] = '(';
		bracket(n, s, i+1, j, k+1);
	}
	if(j < n and i > j)
	{
		s[k] = ')';
		bracket(n, s, i, j+1, k+1);
	}
}

int main()
{
	int n;
	cin >> n;
	char s[4*n + 1];
	bracket(n, s, 0, 0, 0);

	return 0;
}