#include<iostream>
#include<algorithm>
using namespace std;

int count(int a)
{
	int i = 0;
	while(a > 9)
	{
		a -= 10;
		i++;
	}
	return i;
}


int main()
{
	int a[1000], b[1000], c[1000] = {0};
	int m, n, o, s;
	int i, j;
	cin >> m;
	for(i = 0; i < m; i++)
	{
		cin>>a[i];
	}
	cin >> n;
	for(i = 0; i < n; i++)
	{
		cin>>b[i];
	}	
	i = m;
	j = n;

	/*
	if(i > j)
	{
		s = i;
		while(j >= 0)
		{
			a[i] += b[j];
			c[i] = a[i];
			j--;
			i--;
		}
		while(i >= 0)
		{
			c[i] = a[i];
			i--;
		}
	}
	else
	{
		s = j;
		while(i >= 0)
		{
			b[j] += a[i];
			c[j] = b[j];
			j--;
			i--;
		}
		while(j >= 0)
		{
			c[j] = b[j];
			j--;
		}
	}

	for(i = s - 1; i >= 0; i--)
	{
		int x = 0;
		if(c[i] >= 10)
		{

			x = c[i] % 10;
			c[i - 1] += count(c[i]);
			c[i] = x;
		}
		
	}
	for(i = 0; i < s; i++)
		cout<<c[i]<<", ";
	cout<<"END";
*/


	if(i > j)
	{
		s = i;
		while(j >= 0)
		{
			a[i] += b[j];
			c[i] = a[i];
			j--;
			i--;
		}
		while(i >= 0)
		{
			c[i] = a[i];
			i--;
		}
	}
	else
	{
		s = j;
		while(i >= 0)
		{
			b[j] += a[i];
			c[j] = b[j];
			j--;
			i--;
		}
		while(j >= 0)
		{
			c[j] = b[j];
			j--;
		}
	}

	reverse(c, c+s);
	for(i = 0; i < s; i++)
	{
		if(c[i] > 0)
		{
			c[i + 1] += count(c[i]);
			c[i] = c[i] % 10;
		}
	}
	if(c[s] != 0)
	{
		s++;
	}
	reverse(c, c+s);



	for(i = 0; i < s; i++)
		cout<<c[i]<<", ";
	cout<<"END";



	
	return 0;
}