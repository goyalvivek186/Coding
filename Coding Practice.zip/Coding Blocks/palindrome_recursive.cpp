#include<iostream>
using namespace std;

bool palindrome(int a[], int i, int j)
{
	if(a[i] == a[j])
	{
		return palindrome(a, i+1, j-1);
	}
	else if(i > j)
	{
		return true;
	}
	else
	{
		return false;
	}
}



int main()
{
	int n, a[1000];
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> a[i];
	}

	int i = 0, j = n - 1;
	if(palindrome(a, i, j))
		{
			cout<<"true";
		}
		else
		{
			cout<<"false";
		}

	
	return 0;
}