#include<iostream>
#include<set>

using namespace std;
typedef multiset<int>::iterator it;
int main()
{
	int a[] = {1, 2, 2, 10, 15, 9, 9, 11};
	int n = sizeof(a) / sizeof(int);
	set<int> s;
	/*
	Unique
	Ordered
	Sorted
	*/
	cout<<"Array = ";
	for(auto x : a)
	{
		cout<<x<<" ";
	}
	for(int i : a)
	{
		s.insert(i);
	}
	cout<< endl << "Set = ";
	for(auto it = s.begin(); it != s.end(); it++)
	{
		cout<<*(it)<<" ";
	}

				// erase() Delete the no from the set

	s.erase(2);				//Use no itself to delete the no from set
	s.erase(s.find(10));	//Use iterator (position of no) to delete

	cout<<endl << "Multiset = ";
	multiset<int> m(a, a + n);
	/*
	ordered
	NOT Unique
	Sorted
	*/
	for(auto x : m)
	{
		cout<<x<<" ";
	}

	m.erase(10);
	m.erase(m.find(11));

	cout<<endl << "Multiset after deletion = ";
	for(auto x : m)
	{
		cout<<x<<" ";
	}
	cout<<"\nCount of 9 = "<<m.count(9);

	//Range of a no
	//range.first = Begining iterator (Position) of a given no
	//range,second = last position + 1
	pair<it, it> range = m.equal_range(9);
	cout<<endl << "Position of 9's = ";
	for(auto it = range.first; it != range.second; it++)
	{
		cout<<*(it)<<" ";
	}

	m.insert(20);
	return 0;
}