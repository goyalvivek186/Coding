#include<iostream>
using namespace std;


int main() 
{
	int t, x, k, n, j = 3;
	cin>>t;
	for(int i = 0; i < t; i++)
	{
		cin>>n;
		int c = 1;
		while (c < n)
		{
		for(i = 2; i < j; i++)
		{
			if(j % i ==0)
			{
				break;
			}
		}
		if(i == j)
		{
			c++;
		}
		if(c == n)
		{
			cout<<j;
			break;
		}

			j++;

		}
		} 
		


	return 0;
}