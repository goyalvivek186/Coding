#include<iostream>
#include<algorithm>
#include<vector>
#include<string>

using namespace std;

bool compare(string x, string y)
{
	string xy = x+y;
	string yx = y+x;
	return xy > yx;
}

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n;
		vector<string> a;
		cin >> n;
		for(int i = 0; i < n; i++)
		{
			string s;
			cin >> s;
			a.push_back(s);
		}
		sort(a.begin(), a.end(), compare);

		for(auto it : a)
		{
			cout<<it;
		}
	}
	return 0;
}