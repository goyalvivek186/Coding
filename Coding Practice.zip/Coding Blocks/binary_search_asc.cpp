#include<iostream>
using namespace std;
int binary(int s, int a[], int n)
{
	int l = 0, r = s, m ;
	while(l <= r)
	{
		m = (l+r) / 2;
		if (n == a[m])
		{
			return (m+1);
		}
		else if(a [m] < n)
		{
			l = m + 1;
		}
		else if(a [m] > n)
		{
			r = m - 1;
		}

	}
	return -1;

}

int main()
{
	int s, a[20] = {0}, n, p;

	cout<<"Enter the size of the array\n";
	cin >> s;
	cout<<"Enter the elements\n";
	for(int i = 0; i < s; i++)
	{
		cin >> a[i];
	}
	cout<<"Enter the element to be searched\n";
	cin >> n;
	p = binary(s, a, n);
	//if(p < 1 || p > s || a[p-1] != n)
	if(p == -1)
	{
		cout<<"Element not found";
		return -1;
	}
	else
	{
		cout<<"The position of element = "<<p;
		return 1;
	}
	

	
}