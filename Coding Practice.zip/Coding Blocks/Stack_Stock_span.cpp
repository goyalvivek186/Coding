#include<iostream>
#include<stack>

using namespace std;

void stock(int a[], int n, int *ans)
{
	stack<int> s;
	s.push(0);
	ans[0] = 1;
	for(int i = 1; i < n; i++)
	{
		int curr = a[i];
		while(!s.empty() and a[s.top()] < curr)
		{
			s.pop();
		}
		if(!s.empty())
		{
            //cout<<s.top()<<endl;
			ans[i] = i - s.top();
		}
		else
		{
			ans[i] = i+ 1;
		}
		s.push(i);
	}

}

int main()
{
	int n;
	cin >> n;
	int a[1000005], ans[1000005] = {0};
	for(int i = 0; i < n; i++)
	{
		cin >> a[i];
	}
	stock(a, n, ans);
	for(int i = 0; i < n; i++)
	{
		cout<<ans[i]<<" ";
	}
    cout<<"END";



	return 0;
}