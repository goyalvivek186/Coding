#include<iostream>
#include<string>
#include<algorithm>
#include<climits>
#include<math.h>
using namespace std;

int bits(int a)
{
	int c = 0;
	while(a > 0)
	{
		c++;
		a = (a<<1);
	}
	return c;
}



int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int a;
		cin >> a;
		cout<< bits(a);
	}





	return 0;
}





