#include<iostream>
#include<unordered_map>
#include<string>
#include<list>
using namespace std;

class graph
{
	int v;
	unordered_map<string, list< pair<string, int>>> m;
public:
	
	void add_edge(string x, string y, int vaule, bool bidir = true)
	{
		m[x].push_back(make_pair(y, vaule));
		if(bidir)
		{
			m[y].push_back(make_pair(x, vaule));
		}
	}

	void print()
	{
		for(auto p : m)
		{
			string a = p.first;
			list<pair<string, int>> b = p.second;
			cout<<a<<" -> ";
			for(auto it : b)
			{
				cout<<it.first<<"("<<it.second<<")"<<" ,";
			}
			cout<<endl;
		}
	}
};

int main()
{
	graph g;
	g.add_edge("A", "B", 40);
	g.add_edge("A", "C", 50);
	g.add_edge("B", "C", 10);
	g.add_edge("C", "D", 70);
	g.add_edge("C", "B", 40, false);

	return 0;
}