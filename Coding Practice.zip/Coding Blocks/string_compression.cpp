#include<iostream>
#include<string.h>
using namespace std;


int main()
{
	char ch[1000];
	cin >> ch;
	int i, j;
	for(i = 0; i < strlen(ch); i++)
	{
		int  c = 1;
		while(ch[i+1] == ch[i])
		{
			c++;
			i++;
		}
		cout<<ch[i]<<c;
	}
	
	return 0;
}