#include<iostream>
#include<string>
#include<algorithm>
#include<climits>

using namespace std;


int main()
{
	int a, i, j;
	cin >> a;
	cin >> i >> j;
	int ones = -1;
	int left = (ones << (j + 1));
	int right = (1 << i) - 1;
	int mask = left | right;
	cout<< (mask & a);
	

	
	return 0;
}