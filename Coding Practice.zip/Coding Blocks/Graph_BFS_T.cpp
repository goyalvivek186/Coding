#include<iostream>
#include<list>
#include<unordered_map>
#include<queue>

using namespace std;

template<typename T>
class graph
{
	unordered_map<T, list<T>> m;
public:
	void addedge(T a, T b)
	{
		m[a].push_back(b);
		m[b].push_back(a);
	}

	void BFS(T source)
	{
		unordered_map<T, bool> visited;
		queue<T> q;
		q.push(source);
        visited[source] = true;
		while(!q.empty())
		{
			T a = q.front();
			q.pop();
            cout<<a<<" ";
			for(auto it : m[a])
			{
				if(visited.count(it) == 0)
				{
					//cout<<it<<" ";
					visited[it] = true;
					q.push(it);
				}
			}

		}
	}
};

int main()
{
	graph<int> g;
	g.addedge(0, 1);
	g.addedge(1, 2);
	g.addedge(2, 3);
	g.addedge(3, 4);
	g.addedge(4, 5);

	g.BFS(0);

	return 0;
}