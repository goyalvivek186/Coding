#include<iostream>
#include<string>
#include<algorithm>
#include<climits>
#include<math.h>

using namespace std;


int main()
{
	int n;
	cin >> n;
	int a[n], b[64] = {0};
	for(int i = 0; i < n; i++)
	{
		cin >> a[i];
		int j = 0;
		while(a[i] > 0)
		{
			b[j] += (a[i] & 1);
			a[i] = a[i] >> 1;
		}
		b[j] %= 3;
	}
	int x = 0;
	for(int i = 64- 1; i >= 0 ; i--)
	{
		x += (pow(2, i) * b[i]);
	}
	cout<<x;
	

	
	return 0;
}