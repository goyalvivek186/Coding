#include<iostream>
#include<string.h>
using namespace std;
			/*		unoptimized
void duplicates(char ch[])
{
	int s = strlen(ch);
	int i = 0, j;
	while(i < s)
	{
		if(ch[i] == ch[i+1])
		{
			for(j = i; j < s; j++)
			{
				ch[j] = ch[j+1];
			}
			if(j == s)
			{
				ch[j] = '\0';
				s = j;
				continue;
			}
		}
			i++;
	}
	cout<<"Right ans =\n"<<ch;

}
*/
				//OBTIMIZED

void duplicates(char ch[20])
{
	int i = 0, j = 1;
	while(ch[i] != '\0')
	{
		if(ch[i] != ch[j])
		{
			i++;
			ch[i] = ch[j];
		}

		else if(ch[i] == ch[j])
		{
			j++;
		}
	}
	cout<<endl<<ch;
}

int main()
{
	char ch[20];
	cout<<"Enter the string\n";
	gets(ch);
	duplicates(ch);



	return 0;
}