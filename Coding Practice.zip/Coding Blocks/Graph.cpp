#include<iostream>
#include<list>
using namespace std;

class graph
{
	int v;					//Vertices
	list<int> *l;			//Dynamic hence *		for static->list<int> l
													//Since we dont know the size/v its dynamic
public:

	graph(int v)
	{
		this->v = v;
		l = new list<int> [v+1];
	}

					//Adjacency List
	void add_edge(int a, int b, bool undirected = true)
	{
		l[a].push_back(b);
		if(undirected)
		{
			l[b].push_back(a);
		}
	}

	void print()
	{
		for(int i = 0; i < v; i++)
		{
			cout<<"Vertex "<<i<<"-> ";
			for(int nbr : l[i])
			{
				cout<<nbr<<" ,";
			}
			cout<<endl;
		}
	}

};

int main()
{
	graph g(5);
	g.add_edge(1, 2);
	g.add_edge(2, 3);
	g.add_edge(4, 5);
	g.add_edge(5, 3);

	g.print();

	return 0;
}