#include <iostream>
#include<vector>
using namespace std;
		//true = minheap = Descending
		//false = maxhaep = Ascending
void print(vector<int> v)
{
    for(int x : v)
    {
        cout<<x<<" ";
    }
}

bool condition(bool minheap, int p, int i, vector<int> v)
{
    if(minheap)
    {
        return v[p] > v[i];
    }
    else
    {
        return v[p] < v[i];
    }
}

void heapify(vector<int> &v, int index, int size, bool type = true)
{
    int m = index;
    int left = m*2;
    int right = left +1;
    int last = size;
    if(left <= last and condition(type, m, left, v))
    {
        m = left;
    }

    if(right <= last and condition(type, m, right, v))
    {
        m = right;
    }

    if(m != index)
    {
        swap(v[m], v[index]);
        heapify(v, m, size, type);
    }
}

void build_haep(vector<int> &v, bool type = true)
{
    for(int i = (v.size()-1)/2; i >= 1; i--)
    {
        heapify(v, i, v.size()-1, type);
    }
}

void heap_sort(vector<int> &v, bool type = true)
{
    build_haep(v, type);
    for(int i = v.size(); i > 1; i--)
    {
        swap(v[1], v[i-1]);
        heapify(v, 1, i-2, type);
    }
}

int main()
{
    vector<int> v;
    int n;
    cin >> n;
    v.reserve(n);
    for(int i = 0; i < n; i++)
    {
        int no;
        cin >> no;
        v.push_back(no);
    }
    heap_sort(v, false);
    print(v);
    return 0;
}
