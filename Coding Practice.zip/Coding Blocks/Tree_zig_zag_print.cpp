#include <iostream>
#include <queue>
using namespace std;

class node
{
public:
    int data;
    node *left;
    node *right;

    node(int d)
    {
        data = d;
        left = NULL;
        right = NULL;
    }
};

node *build(string s)
{
    if (s == "true")
    {
        int d;
        cin >> d;
        node *root = new node(d);
        string l;
        cin >> l;
        if (l == "true")
        {
            root->left = build(l);
        }
        string r;
        cin >> r;
        if (r == "true")
        {
            root->right = build(r);
        }
        return root;
    }
    return NULL;
}

void print(node *root, int &i)
{
    queue<node *> q;
    q.push(root);
    while(!q.empty())
    {   
        node *f = q.front();
        cout<<f->data<<" ";
        q.pop();
        i++;
        if(i % 2 != 0)
        {
            if(f->right)
                q.push(f->right);
            if(f->left)
                q.push(f->left);
        }
        else
        {
            if(f->left)
                q.push(f->left);
            if(f->right)
                q.push(f->right);
        }
    }
}

int main()
{
    node *root = build("true");
    int i = 1;
    print(root, i);
    

    return 0;
}
