#include<iostream>
#include<string>
#include<algorithm>
#include<climits>

using namespace std;

int search(int a[], int n, int x)
{
	int s = 0, e = n-1, m;

	while(s <= e)
	{
		m = (s + e)/2;
		if(a[m] == x)
		{
			return m;
		}
		else if(a[m] > a[s])
		{
			if(x< a[m] and x > a[e])
			{
				e = m - 1;
			}
			else
			{
				s = m + 1;
			}
			
		}
		else
		{
			if(x > a[e] and x < a[m])
			{
				e = m - 1;
			}
			else
			{
				s = m + 1;
			}
		}

	}
	return -1;
}

int main()
{
	int n, x;
	cin >> n;
	int a[n];
	int i;
	for(i = 0; i < n; i++)
	{
		cin >> a[i];
	}
	cin >> x;
	cout<<search(a, n, x);
	

	
	return 0;
}