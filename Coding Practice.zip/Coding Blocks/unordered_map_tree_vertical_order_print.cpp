#include<iostream>
#include<queue>
#include<map>
#include<vector>
using namespace std;

class node
{
public:
	int data;
	node *right;
	node *left;

	node(int d)
	{
		data = d;
		left = NULL;
		right = NULL;
	}
};

node *build()
{
	queue<node *> q;
	int d;
	cin >> d;
	node *root = new node(d);
	q.push(root);
	while(!q.empty())
	{
		node *f = q.front();
		q.pop();
		int d1, d2;
		cin >> d1 >> d2;
		if(d1 != -1)
		{
			f->left = new node(d1);
			q.push(f->left);
		}
		if(d2 != -1)
		{
			f->right = new node(d2);
			q.push(f->right);
		}
	}
	return root;
}

void vertical_order(node *root, map<int, vector<int>> &m, int d)
{
	if(root == NULL)
	{
		return ;
	}
	m[d].push_back(root->data);
	vertical_order(root->left, m, d-1);
	vertical_order(root->right, m, d+1);
}

int main()
{
	int l;
	cin >> l;
	node *root = build();
	map<int, vector<int>> m;
	vertical_order(root, m, 0);
	for(auto x : m)
	{
		for(auto y : x.second)
		{
			cout<<y<<" ";
		}
	}

	return 0;
}