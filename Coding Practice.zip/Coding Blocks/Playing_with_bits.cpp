#include<iostream>
#include<string>
#include<algorithm>
#include<climits>

using namespace std;

void bits(int a, int b)
{
	int c = 0, i, j;
	for(i = a; i <= b; i++)
	{
		int x = i;
		while(x > 0)
		{
			if((x & 1) > 0)
			{
				c++;
			}
            x = x >> 1;
		}
	}
	cout<<c<<endl;
}

int main()
{
	int t;
	cin >> t;

	while(t--)
	{
		int a, b;
		cin >> a >> b;
		bits(a, b);
	}
	
	

	
	return 0;
}