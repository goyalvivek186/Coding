#include <bits/stdc++.h>
using namespace std;

class Node
{
public:
    int data;
    Node *next;
    Node(int d)
    {
        data = d;
        next = NULL;
    }
};


bool floydCycleRemoval(Node *head)
{
    Node *shead = head;
    Node *lhead = head;
    int c = 0;
    while(lhead != NULL and lhead->next != NULL)
    {
        shead = shead->next;
        lhead = lhead ->next ->next;
        if(shead == lhead)
        {
        c++;
        break;
        }
    }
    if(c == 0)
    {
    return false;
    }
    else
    {
        shead = head->next;
        while(lhead->next != shead)
        {
            shead = shead->next;
            lhead = lhead->next;
        }
        lhead->next = NULL;
        return true;
    }
}

