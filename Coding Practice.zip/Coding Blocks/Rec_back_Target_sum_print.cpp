#include<iostream>
#include<algorithm>

using namespace std;

void print(int *a, int n)
{
	for(int i = 0; i < n; i++)	cout<<a[i]<<" ";
	cout<<endl;
}

void targer_sum(int *a, int n, int *ans, int t, int i, int j, int s)
{
	if(s == t)
	{
		print(ans, j);
        return;
	}
	if(i == n or s > t)	return;

    ans[j] = a[i];
	targer_sum(a, n, ans, t, i+1, j+1, s+a[i]);
    ans[j] = 0;		//Backtracking
    if(a[i] != a[i+1])
	    targer_sum(a, n, ans, t, i+1, j, s);
    else
        targer_sum(a, n, ans, t, i+2, j, s);
	
}

int main()
{
	int n;
	cin >> n;
	int a[10000] = {0};
	for(int i = 0; i < n; i++)	cin >> a[i];
	int t;
	cin >> t;
	sort(a, a+n);
    //print(a, n);
    //cout<<endl;
	int ans[10000] = {0};
	targer_sum(a, n, ans, t, 0, 0, 0);
}