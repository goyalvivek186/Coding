#include<iostream>
#include<string>
#include<algorithm>
#include<climits>
#include<math.h>

using namespace std;

void rain(int a[], int n)
{
	int ans = 0;
	int s = 0, i, max = INT_MIN;
	while(s < n)
	{
		if(a[s] == 0)
		{
			s++;
			continue;
		}
		else
		{
			i = s+1;
			while(max !> s or i < n)
			{
				if(a[i] > a[s])
				{
					max = i;
					break;
				}
				i++;
			}
		}
	}

}

int main()
{
	int n;
	cin >> n;
	int a[n];
	for(int i = 0; i < n; i++)
	{
		cin >> a[i];
	}
	void rain(a, n);

	
	return 0;
}