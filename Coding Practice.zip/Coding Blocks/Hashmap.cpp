#include<iostream>
#include<string>
#include"hashtable.h"		//Includes all the required header files
using namespace std;

int main()
{
	hashtable<int> h;
	h.insert("Burger", 50);
	h.insert("Pizza", 120);
	h.insert("Rice", 90);
	h.insert("Coke", 20);
	h.insert("Due", 20);
	h.insert("Limka", 20);
	h.insert("Tea", 20);

	h.print();

	/*int *ans = h.search("tea");
	if(ans == NULL)
	{
		cout<<"No value found";
	}
	else
	{
		cout<<*ans;
	}*/
	h.del("Burger");
	cout<<endl;
	h.print();
	return 0;
}