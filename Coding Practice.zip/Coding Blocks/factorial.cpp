#include<iostream>
using namespace std;

int fact(int n)
{
	long long int ans = 1;
	int i;
	for(i = 1; i < n; i++)
	{
		ans *= i;
	}
	return ans;
}

int main()
{
	int n;
	cin >> n;
	cout<<fact(n);
	


	
	return 0;
}