#include <iostream>
#include <unordered_map>
using namespace std;

int count(int n)
{
    unordered_map<int, int> m;
    while(n)
    {
        int x = n % 10;
        n = n / 10;
        if(m.count(x) == 0)
        {
            m[x] = 1;
        }
        else
        {
            m[x]++;
        }
    }

    int c = 0;
    for(auto a : m)
    {
        c++;
    }
    return c;
}

int main()
{
    int n;
    cin >> n;
    cout<<count(n);
    return 0;
}
