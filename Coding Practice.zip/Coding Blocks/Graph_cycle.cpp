#include<iostream>
#include<unordered_map>
#include<list>

using namespace std;

template<typename T>
class graph
{
	unordered_map<T, list<T> > m;
public:
	void add_edge(T a, T b)
	{
		m[a].push_back(b);
	}

	bool cycle_helper(unordered_map<T, bool> &visited, unordered_map<T, bool> &stack, T source)
	{
		stack[source] = true;
		visited[source] = true;
		for(auto p : m[source])
		{
			if(stack[p])
			{
				return true;
			}
			else if(!visited[p])
			{
				bool check = cycle_helper(visited, stack, p);
				if(check)
				{
					return true;				//Back propogation
				}
			}
		}
		stack[source] = false;
		return false;
	}

	bool is_cycle()
	{
		unordered_map<T, bool> visited;
		unordered_map<T, bool> stack;
		for(auto p : m)
		{
			visited[p.first] = false;
			stack[p.first] = false;
		}

		for(auto p : m)
		{
			if(!visited[p.first])
			{
				if(cycle_helper(visited, stack, p.first))
				{
					return true;
				}
			}
		}
		return false;
	}
};

int main()
{
	graph<int> g;

	g.add_edge(1, 2);
	g.add_edge(2, 3);
	g.add_edge(3, 4);
	g.add_edge(4, 1);

	if(g.is_cycle())
	{
		cout<<"Cycle";
	}
	else
	{
		cout<<"No cycle";
	}
	return 0;
}