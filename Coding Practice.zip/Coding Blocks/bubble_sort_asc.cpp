#include<iostream>
using namespace std;

void bubble_sort(int s, int a[])
{
	int i, j;
	for(i = 0; i < s; i++)
	{
		for(j = 0; j < s-i-1; j++)
		{
			if(a[j] > a[j+1])
			{
				swap(a[j], a[j+1]);
			}
		}
	}
	cout<<"Sorted array =\n";
	for(i = 0; i < s; i++)
	{
		cout<<a[i]<<"\n";
	}
}


int main()
{
	int s, a[20] = {0};

	cout<<"Enter the size of the array\n";
	cin >> s;
	cout<<"Enter the elements\n\n";

	for(int i = 0; i < s; i++)
	{
		cin >> a[i];
	}
	bubble_sort(s, a);



	return 0;
}