#include<iostream>
#include<math.h>
using namespace std;



int main()
{
	float a, b, c;
	cin >> a >> b >> c;
	float d1, d2, d;
	d = pow(b, 2) - 4* a* c;
	d1 = (-b + sqrt(pow(b, 2) - 4*a*c))/2*a;
	d2 = (-b - sqrt(pow(b, 2) - 4*a*c))/2*a;

	if(d > 0)
	{
		d1 = int(d1);
		d2 = int(d2);
		cout<<"Real and Distinct\n";
		if(d1 < d2)
			cout<<d1 <<" "<<d2 ;
		else
			cout<<d2 <<" "<<d1 ;
	}
	else if(d == 0)
	{
		d1 = int(d1);
		d2 = int(d2);
		cout<<"Real and Equal\n";
		cout<<d1 <<" "<<d2 ;
	}
	else
	{
		cout<<"Imaginary\n";
	}


	
	return 0;
}