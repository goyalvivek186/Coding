#include<iostream>
using namespace std;


int main()
{
	int n, i, j, m, k;
	cin >> n;
	m = (n + 1) / 2;
	for(i = 1; i < m; i++)
	{
		for(j = 1; j <= n; j++)
		{
			if(j == 1 || j ==m)
			{
				cout<<"*";
			}
			else if(i == 1 and j > m)
			{
				cout<<"*";
			}
			else
			{
				
					cout<<" ";
			}
			
		}
		cout<<endl;
	}

	if(i == m)
	{
		for(i = 0; i < n; i++)
		{
			cout<<"*";
		}
	}
	cout<<endl;

	for(i = m+1; i <= n; i++)
	{
		for(j = 1; j <= n; j++)
		{
			if(i ==n and j <= m)
			{
				cout<<"*";
			}
			else if(j == m || j == n)
			{
				cout<<"*";
			}
			else
			{
				cout<<" ";
			}


		}
		cout<<endl;
	}





	return 0;
}