#include<iostream>
#include<string.h>
using namespace std;


int main()
{
	int a = 0, b = 0, k, ans;
	cin >> k;
	string ch;
	cin >> ch;

	for(int i = 0; i < ch.length(); i++)
	{
		if(ch[i] == 'a')
		{
			a++;
		}
		else
		{
			b++;
		}
	}
	if(a <= k or b <= k)
	{
		ans = ch.length();
	}
	else
	{
		if(a < b)
		{
			if(a < k)
			{
				ans = ch.length();
			}
			else
			{
				ans = k + b;
			}
		}
		else
		{
			if(b < k)
			{
				ans = ch.length();
			}
			else
			{
				ans = k + a;
			}
		}
	}
	cout<<ans;
	return 0;
}