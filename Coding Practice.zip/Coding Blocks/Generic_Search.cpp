#include <iostream>
using namespace std;

template<typename T>
int find(T *a, int n, T x)
{
    for(int i = 0; i < n; i++)
    {
        if(x == a[i])
        {
            return i;
        }
    }
    return -1;
}
int main()
{
    int a[] = {1,2,3,4,5,6};
    int n = sizeof(a)/sizeof(int);
    cout << find(a, n, 5);
    return 0;
}
