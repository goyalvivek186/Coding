#include<iostream>
#include<list>
#include<unordered_map>
#include<queue>

using namespace std;

template<typename T>
class graph
{
	unordered_map<T, list<T>> m;
public:
	void addedge(T a, T b)
	{
		m[a].push_back(b);
		m[b].push_back(a);
	}

	void dfs(unordered_map<T, bool> &visited, T source)
	{
		cout<<source<<" ";
		visited[source] = true;
		for(auto p : m[source])
		{
			if(!visited[p])
			{
				dfs(visited, p);
			}
		}
	}

	void components()
	{
		unordered_map<T, bool> visited;
		for(auto p : m)
		{
			visited[p.first] = false;
		}

		int cmp = 1;
		for(auto p : m)
		{
			if(!visited[p.first])
			{
                cout<<"Componenet no "<<cmp<<"-> ";
				dfs(visited, p.first);
				cmp++;
                cout<<endl;
			}
		}
	}
};

int main()
{
	graph<int> g;
	g.addedge(0, 4);
	g.addedge(0, 1);
	g.addedge(0, 3);
	g.addedge(1, 2);
	g.addedge(3, 2);
	
    g.addedge(5, 6);
    g.addedge(6, 7);

    g.components();

	return 0;
}