#include<iostream>
#include<string>
#include<algorithm>

using namespace std;

bool compare(string s1, string s2)
{
	int x, y;
	x = s1.length();
	y = s2.length();
    int m = min(x, y);
    bool ans = true;
    for(int i = 0; i < m; i++)
	{    if(s1[i] != s2[i])
	    {
		    ans = false;
            break;
	    }
    }
    if(ans)
    {
        return s1.length() > s2.length();
    }
    else 
    {
        return s1 < s2;
    }
}



int main()
{
	int n;
	cin >> n;
	string s[n];
	cin.get();
	for(int i = 0; i < n; i++)
	{
		getline(cin, s[i]);
	}	
	sort(s, s+n, compare);
    for(int i = 0; i < n; i++)
	{
		cout<<s[i]<<endl;
	}
	
	return 0;
}