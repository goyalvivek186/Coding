#include<iostream>
#include<unordered_map>
#include<vector>

using namespace std;

int main()
{
	int n, k, x;
	vector<int> v;
	unordered_map<int, int> m;
	cin >> n >> k;
	for(int i = 0; i < n; i++)
	{
		cin >> x;
		v.push_back(x);
		m[x] = i;
	}
	int ind = -1;
	for(int i = n; i > 0 and k > 0; i++)
	{
		ind++;
		if(m[i] == ind)
		{
			continue;
		}
		else
		{
			int index = m[i];
			swap(v[m[i]], v[ind]);
			swap(m[v[ind]], m[v[index]]);
			k--;
		}
	}
	for(int i : v)
	{
		cout<<i<<" ";
	}



	return 0;
}