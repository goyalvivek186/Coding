#include<iostream>

using namespace std;

char ch[][10] = { {" "}, {"abc"}, {"def"}, {"ghi"}, {"jkl"}, {"mno"}, {"pqrs"}, {"tuv"}, {"wx"}, {"yz"}};

void keypad(char *s, char *ans, int i, int j, int &c)
{
	if(s[i] == '\0')
	{
		ans[j] = '\0';
		cout<<ans<<" ";
        c++;
		return;
	}
	int dig = s[i] - '0';
	for(int x= 0; ch[dig][x]!='\0'; x++)
	{
		ans[j] = ch[dig][x];
		keypad(s, ans, i+1, j+1, c);
	}
}

int main()
{
	char s[1000], ans[10000];
	cin >> s;
    int c = 0;
	keypad(s, ans, 0, 0, c);
    cout<<endl<<c;

	return 0;
}