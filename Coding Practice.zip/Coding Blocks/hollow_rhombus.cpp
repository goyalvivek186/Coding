#include<iostream>
using namespace std;


int main()
{
	int i, j, n, k;
	cin>>n;

	for(i = 1; i <= n; i++)
	{
		for(j = n; j > i; j--)
		{
			cout<<" ";
		}

		if(i==1 || i==n)
		{
			for(j = 0;j < n; j++)
			{
				cout<<"*";
			}
		}
		else
		{
			cout<<"*";
			for(j = 2; j < n; j++)
			{
				cout<<" ";
			}
			cout<<"*";
		}
		cout<<endl;
	}



	return 0;
}