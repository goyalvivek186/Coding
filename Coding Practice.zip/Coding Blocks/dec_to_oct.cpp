#include<iostream>
#include<math.h>

using namespace std; 


int main() {
	int dec, ans = 0, a, i = 0;
	cin>>dec;
	while(dec != 0)
	{
		a = dec % 8;
		dec = dec / 8;
		ans = (a * pow(10,i)) + ans;
		i++;
	}
	cout<<ans;



	return 0;
}