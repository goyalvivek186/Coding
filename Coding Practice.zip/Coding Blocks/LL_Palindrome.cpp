#include <iostream>
#include<list>
using namespace std;
int main() 
{
    list <int> l;
    int n;
    cin >> n;
    while(n--)
    {
        int a;
        cin >> a;
        l.push_back(a);
    }
    auto i = l.begin();
    auto j = l.end();
    j--;
    int c = 0;
    while(i != j)
    {
        if(*i != *j)
        {
            c++;
            break;
        }
        i++;
        j--;
    }
    if(c == 0)
    {
        cout<<"true";
    }
    else
    {
        cout<<"false";
    }
    return 0;
    }
