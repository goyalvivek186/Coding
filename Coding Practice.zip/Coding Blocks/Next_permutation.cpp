#include<iostream>
#include<string>
#include<algorithm>
#include<climits>

using namespace std;

void next(int a[], int n)
{
	int no = 0;
	for(int i = 0; i < n; i++)
	{
		no = (no * 10) + a[i];
	}
	next_permutation(a, a+n);
	int no2 = 0;
	for(int i = 0; i < n; i++)
	{
		no2 = (no2 * 10) + a[i];
	}
	if(no < no2)
	{
		for(int i = 0; i < n; i++)
		{
			cout<<a[i] <<" ";
		}
	}
	else
	{
		sort(a, a+n);
		for(int i = 0; i < n; i++)
		{
			cout<<a[i] <<" ";
		}
	}
}


int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n;
		cin >> n;
		int a[n];
		for(int i = 0; i < n; i++)
		{
			cin >> a[i];
		}
		next(a, n);
        cout<<endl;
	}
	
	return 0;
}