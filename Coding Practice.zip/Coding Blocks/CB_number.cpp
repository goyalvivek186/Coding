#include<iostream>
#include<string>
#include<algorithm>
#include<climits>

using namespace std;

bool isprime(int n)
{
    int c = 0;
    for(int i = 2; i < n; i++)
    {
        if((n % i) == 0)
        {
            return false;
        }
    }
    return true;
}

bool isCB(string st, int n, int s, int e)
{
	int no = 0;
	for(int i = s; i <= e; i++)
	{
		no = (no * 10) + (st[i] - '0');
	}
    if(no == 0 or no == 1)
    {
        return false;
    }
   // cout<<no<<endl;
	//for(int i = 2; i < 30 and i < no; i++)
	//{
		if(isprime(no) == 0)
		{
			return false;
		}
	//}
	return true;
}

int main()
{
	int n;
	cin >> n;
	string st;
	cin >> st;
	int c = 0, s = 0;

	for(int i = 0; i < n; i++)
	{
		if(isCB(st, n, s, i))
		{
			c++;
            s = i + 1;
		}
		
	}
	cout<< c;
	
	

	
	return 0;
}