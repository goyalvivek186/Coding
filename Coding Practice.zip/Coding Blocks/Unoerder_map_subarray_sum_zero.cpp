#include<iostream>
#include<unordered_set>

using namespace std;

int main()
{
	int n;
	cin >> n;
	int pre = 0;
	unordered_set<int> us;
	bool ans = false;
	while(n--)
	{
		int a;
		cin >> a;
		pre += a;
		if(pre == 0 or us.find(pre) != us.end())
		{
			ans = true;
			break;
		}
		us.insert(pre);
	}

	if(ans)
	{
		cout<<"Yes";
	}
	else
	{
		cout<<"No";
	}
}