#include <iostream>
using namespace std;

class Node
{
public:
    int data;
    Node *next;

    Node(int d)
    {
        data = d;
        next = NULL;
    }
};


int size(Node *l)
{
    int c = 0;
    while(l != NULL)
    {
    c++;
    l = l->next;
    }
    return c;
}


Node *intersectionOfTwoLinkedLists(Node *l1, Node *l2)
{
    Node *t1 = l1;
    Node *t2 = l2;
    int s1 = 0, s2 = 0, rem;
    s1 = size(l1);
    s2 = size(l2);

    if(s1 > s2)
    {
        rem = s1 - s2;
        while(rem--)
        {
        t1 = t1->next;
        }
    }
    else
    {
        rem = s2 - s1;
        while(rem--)
        {
        t2 = t2->next;
        }
    }
    while(t1 != NULL and t2 != NULL)
    {
    if(t1 == t2)
    {
    return t1;
    }
    t1 = t1->next;
    t2 = t2->next;
    }
    return NULL;
}


