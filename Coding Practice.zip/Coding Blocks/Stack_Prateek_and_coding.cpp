#include<iostream>
#include<stack>

using namespace std;

int main()
{
	stack<int> s;
	int n;
	cin >> n;
	while(n--)
	{
		int a;
		cin >> a;
		if(a == 1)
		{
			if(s.empty())
			{
				cout<<"No Code\n";
				continue;
			}
			cout<<s.top()<<endl;
			s.pop();
			continue;
		}
		if(a == 2)
		{
			cin >> a;
			s.push(a);
		}

	}
	return 0;
}