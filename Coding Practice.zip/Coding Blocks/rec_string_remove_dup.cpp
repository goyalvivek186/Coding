#include<iostream>
#include<cstring>
#include<algorithm>
#include<string>
#include<math.h>

using namespace std;

void remove(string &s, int n)
{
	if(n <= 1)
	{
		return;
	}
	if(s[n - 1] == s[n - 2])
	{
		s.erase(n - 1, 1);
		//remove(s, n);
	}
	remove(s, n - 1);

}

int main()
{
	string s;
	getline(cin, s);
    int x = s.length();
	remove(s, x);
    cout<<s;
	
	return 0;
}