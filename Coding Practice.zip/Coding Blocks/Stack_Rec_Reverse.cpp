#include<iostream>
#include<stack>

using namespace std;

void placex(stack<int> &s, int x)
{
	if(s.empty())
	{
		s.push(x);
		return;
	}
	int y = s.top();
	s.pop();
	placex(s, x);
	s.push(y);
}


void reverse(stack<int> &s)
{
	if(s.empty())
	{
		return;
	}
	int x = s.top();
	s.pop();
	reverse(s);
	placex(s, x);
}


int main()
{
	stack<int> s;
	int n;
	cin >> n;
	while(n--)
	{
		int a;
		cin >> a;
		s.push(a);
	}

	reverse(s);

	while(!s.empty())
	{
		cout<<s.top()<<endl;
		s.pop();
	}

	return 0;
}