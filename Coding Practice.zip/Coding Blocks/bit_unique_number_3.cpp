#include <iostream>
using namespace std;
int main() {
    int n,no;
    cin>>n;
    int count_arr[64]={0};
    for(int i=0;i<n;i++){
        cin>>no;
        int j = 0;
        while(no>0){
            int last_bit = (no&1);
            count_arr[j] += last_bit;
            j++;
            no = no>>1;
        }
    }

    int ans = 0;
    int p=1;
    for(int i=0;i<64;i++){
        count_arr[i] = count_arr[i] % 3;
        ans += (count_arr[i]*p);
        p = p<<1;
    }

    cout<<ans<<endl;
}