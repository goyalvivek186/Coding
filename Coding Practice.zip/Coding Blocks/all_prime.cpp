#include<iostream>
using namespace std;

int pr(int n)
{
	int i, j;
	for(i = 2; i <= n; i++)
	{
		int c = 0;
		if(i == 2 &&  n ==1)
		{
			cout<<"2\n";
			return 0;
		}
		else if(i == 2 && n !=0)
		{
			cout<<"2\n";
			continue;
		}
		for(j = 2; j < i - 1; j++)
		{
			if(i % j == 0)
			{
				c++;
				break;
			}
		}
		if(c == 0)
		{
			cout<<i<<"\n";
		}
	}
}


int main()
{
	int n;
	cin>> n;
	pr(n);
	return 0;
}