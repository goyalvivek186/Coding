#include<iostream>
#include<string>
#include<algorithm>
#include<climits>

using namespace std;



int main()
{
	int a, b, x, ans = INT_MIN;
	cin >> a >> b;
	for(int i = a; i <= b; i++)
	{
		for(int j = a; j <= b; j++)
		{
			x = (i^j);
			ans = max(ans, x);
		}
	}
	cout<<ans;
	
	return 0;
}