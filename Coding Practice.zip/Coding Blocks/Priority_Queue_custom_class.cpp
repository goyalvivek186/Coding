#include<iostream>
#include<cstring>
#include<queue>
using namespace std;

class person
{
public:
	int age;
	string name;

	person(int n, string s)
	{
		age = n;
		name = s;
	}
};

class compare
{
public:
	bool operator()(person p1, person p2)
	{
		return p1.age < p2.age;
	}
};

int main()
{
	priority_queue<person, vector<person>, compare> pq;		//STL accepts class as a costom compare not a function

	int n;
	cin >> n;
	for(int i = 0; i < n; i++)
	{
		int a;
		string s;
		cin >> a;
		cin >> s;
		person p(a, s);
		pq.push(p);

	}

	while(!pq.empty())
	{
		person p = pq.top();
		pq.pop();
		cout<<p.age<<" "<<p.name<<endl;
	}

	return 0;
}
