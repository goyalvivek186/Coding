#include<iostream>

using namespace std;

class node
{
public:
	int data;
	node *right;
	node *left;

	node(int d)
	{
		data = d;
		right = NULL;
		left = NULL;
	}
};

node *insertinBST(node *root, int d)
{
	if(root == NULL)
	{
		return new node(d);
	}

	if(d > root->data)
	{
		root->right = insertinBST(root->right, d);
	}

	else
	{
		root->left = insertinBST(root->left, d);
	}
	return root;
}

node *build(int *a, int n)
{
	int  i = 0;
	node *root = NULL;
	while(n--)
	{
		root = insertinBST(root, a[i]);
		i++;
	}
	return root;
}

void preorder(node *root)
{
	if(root == NULL)
	{
		return ;
	}
	cout<<root->data<<" ";
	preorder(root->left);
	preorder(root->right);
}

void search(node *root, int k1, int k2)
{
	if(root == NULL)
	{
		return ;
	}
	
	search(root->left, k1, k2);
	if(root->data >= k1 and root->data <= k2)
	{
		cout<<root->data<<" ";
	}
	search(root->right, k1, k2);

}

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n;
		cin >> n;
		int a[n];
		for(int i = 0; i < n; i++)
		{
			cin >> a[i];
		}
		int k1, k2;
		cin >> k1 >> k2;
		node *root = build(a, n);
		cout<<"# Preorder : ";
		preorder(root);
		cout<<endl;
		cout<<"# Nodes within range are : ";
		search(root, k1, k2);
		cout<<endl;

	}
}