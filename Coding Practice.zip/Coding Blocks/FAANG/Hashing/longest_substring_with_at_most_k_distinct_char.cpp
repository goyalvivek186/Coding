#include<iostream>
#include<unordered_map>
#include<string>

using namespace std;

int sun_string(string s, int k)
{
	unordered_map<char, int> m;
	int ans = 0;
	int curr = 0;
	int j = 0;
	for(int i = 0; i < s.length(); i++)
	{
		if(k > 0)
		{
			if(m.count(s[i]) == 0 or m[s[i]] == 0)
			{
				k--;
				curr = i - j + 1;
				ans = max(ans, curr);
				m[s[i]] = 1;
			}
			else
			{
				curr = i - j + 1;
				ans = max(ans, curr);
				m[s[i]]++;
			}
		}
		else
		{
			m[s[j]]--;
			if(m[s[j]] == 0)	k++;
			j++;
			i--;
		}
	}
    return ans;
}


int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		string s;
		cin >> s;
		int k;
		cin >> k;
		cout<<sun_string(s, k)<<endl;
	}


	return 0;
}