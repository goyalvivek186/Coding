#include<iostream>
#include<vector>
#include<unordered_map>
using namespace std;

void take_input(vector<int> &v)
{
	char ch;
	cin >> ch;
	while(ch != ']')
	{
		int a;
		cin >> a;
		v.push_back(a);
		cin >> ch;
	}
}

bool multiple(vector<int> v, int k)
{
	unordered_map<int, int> m;
	int sum = 0;
	m[0] = -1;
	for(int i = 0; i < v.size(); i++)
	{
		sum += v[i];
		int a = sum % k;
		if(m.count(a) == 0)
		{
			m[a] = i;
		}
		else
		{
			if(i - m[a] > 1)	return true;
		}
	}
	return false;

}

int main()
{
	vector<int> v;
	take_input(v);
	int k;
	cin >> k;

	if(multiple(v, k))
	{
		cout<<"true";
	}
	else
	{
		cout<<"false";
	}

	return 0;
}