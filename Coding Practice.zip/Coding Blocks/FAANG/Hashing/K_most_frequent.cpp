#include<iostream>
#include<map>
#include<set>
using namespace std;

int main()
{
	int n, k;
	cin >> n >> k;
	int *a = new int[n]{0};
	map<int, int> m;
	for(int i = 0; i < n; i++)
	{
		int x;
		cin >> x;
		if(m.count(x) == 0)
		{
			m[x] = 1;
		}
		else
		{
			m[x]++;
		}
	}
	set<pair<int, int>, greater<pair<int, int>>> s;
    for(auto i : m)
    {
        s.insert(make_pair(i.second, i.first));
    }
    for(auto it = s.begin(); it != s.end(), k > 0; it++)
    {
        cout<<(*it).second<<" ";
        k--;
    }


	return 0;
}