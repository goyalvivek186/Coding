#include<iostream>
#include<unordered_map>

using namespace std;

int main()
{
	int n, t;
	cin >> n >> t;
	long long int sum = 0;
	unordered_map<int, int> m;
	m[0] = 1;
	long long int cnt = 0;
	for(int i = 0; i < n; i++)
	{
		int x;
		cin >> x;
		sum += x;
		//b - a = t;
		//a = b - t;
		int b = sum;
		int a = b - t;
		if(m.count(a) != 0)
		{
			cnt += m[a];
		}
		if(m.count(b) == 0)	m[b] = 1;
		else				m[b]++;
	}
	cout<<cnt;

	return 0;
}