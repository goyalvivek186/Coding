#include<iostream>
#include<vector>
#include<unordered_map>
using namespace std;

void take_input(vector<int> &v)
{
	char ch;
	int n;
	cin >> ch;
	while(ch != ']')
	{
		cin >> n;
		v.push_back(n);
		cin >> ch;
	}
}

int main()
{
	vector<int> a;
	take_input(a);

	unordered_map<int, vector<int>> m;
	for(int i = 0; i < a.size(); i++)
	{
		m[a[i]].push_back(i);
	}
	int ans = 0;
	int n = a.size();
	for(int i = 0; i < n-1; i++)
	{
		for(int j = i+1; j < n; j++)
		{
			int cnt = 2;
			int num = a[j];
			int pos = j;
			int dif = a[j]-a[i];
            int next = num + dif;
			while(m.count(next) != 0)
			{
                bool found = false;
				for(auto it : m[next])
				{
    				if(it > pos)
					{
						num = next;
						pos = it;
						cnt++;
                        next = num + dif;
                        found = true;
						break;
					}
				}
                if(!found)  break;
			}
            ans = max(ans, cnt);
		}
	}
	cout<<ans;

	return 0;
}