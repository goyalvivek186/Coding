#include<iostream>
#include<vector>
#include<unordered_map>
#include<climits>
using namespace std;

void take_input(vector<int> &v)
{
	char ch;
	cin >> ch;
	while(ch != ']')
	{
		int a;
		cin >> a;
		v.push_back(a);
		cin >> ch;
	}
}

int main()
{
	unordered_map<int, int> m;
	vector<int> v;
	take_input(v);
	int k;
	cin >> k;

	int n = v.size();
	int *cum = new int[n+1]{0};
	m[0] = 0;
	for(int i = 0; i < n; i++)
	{
		cum[i+1] = cum[i] + v[i];
		m[cum[i+1]] = i+1;
	}
	int ans = INT_MIN;
	for(int i = 0; i <= n; i++)
	{
		int a = cum[i];
		int b = a + k;
		if(m.count(b) != 0)
		{
			ans = max(ans, m[b] - i);
		}
	}
	cout<<ans;
}