#include<iostream>
#include<unordered_map>
#include<vector>
#include<list>
using namespace std;

int main()
{
	int n, k;
	cin >> n >> k;
	int a;
	unordered_map<int, int> m;
	int max_e = 0;
	for(int i = 0; i < n; i++)
	{
		cin >> a;
		if(m.count(a) == 0)
		{
			m[a] = 1;
		}
		else
		{
			m[a]++;
			max_e = max(max_e, m[a]);
		}
	}

	list<int> v[max_e + 1];
	for(auto i : m)
	{
		v[i.second].push_back(i.first);
	}
	for(auto i = max_e; i >= 0; i--)
	{
		for(auto j : v[i])
		{
			if(k == 0)	return 0;
			cout<<j<<" ";
			k--;
		}
	}
	



	return 0;
}