#include<iostream>
using namespace std;

int bitonic(int *a, int n)
{
	int l[10000] = {0};
	int r[10000] = {0};

	l[0] = r[n-1] = 1;
	for(int i = 1; i < n; i++)
	{
		l[i] = -1;
		for(int j = 0; j < i; j++)
		{
			if(a[j] < a[i])
			{
				l[i] = max(l[i], l[j] + 1);
			}
		}
        if(l[i] == -1)  l[i] = 1;
	}

	for(int i = n-2; i >= 0; i--)
	{
		r[i] = -1;
		for(int j = i+1; j < n; j++)
		{
			if(a[j] < a[i])
			{
				r[i] = max(r[i], r[j] + 1);
			}
		}
        if(r[i] == -1)  r[i] = 1;
	}

	int ans = -1;
	for(int i = 0; i < n; i++)
	{
		ans = max(ans, l[i] + r[i] - 1);
	}
	return ans;
}

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n;
		cin >> n;
		int a[10000] = {0};
		for(int i = 0; i < n; i++)
		{
			cin >> a[i];
		}
		cout<<bitonic(a, n)<<endl;
	}




	return 0;
}