#include<iostream>
#include<string>
#include<stack>
using namespace std;

int valid(string s, int a, int b, int n, int i)
{
	if(i == n)	return 0;

	int ans = 0;
	if(s[i] == '(')	
	{
		a++;
		return valid(s, a, b, n, i+1);
	}
	else
	{
		if(a > 0)
		{
			a--;
			return 2 + valid(s, a, b, n, i+1);
		}
	}
    return ans;
}


int valid_stack(string a, int n)
{
	stack<char> s;
	int ans = 0;
	for(int i = 0; i < n; i++)
	{
		if(a[i] == '(')	s.push(a[i]);

		else
		{
			if(s.empty())
			{
				return ans;
			}
			if(s.top() == '(');
			s.pop();
			ans += 2;
		}
	}
	return ans;
}

int main()
{
	string s;
	cin >> s;
	int n = s.size();
	//cout<<valid(s, 0, 0, n, 0)<<endl;
    cout<<valid_stack(s, n);


	return 0;
}