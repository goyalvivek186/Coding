#include<iostream>
using namespace std;

int steps(int n, int *dp)
{
    if(n < 0)   return 0;
	if(n == 0)	return 1;
	if(dp[n] != 0)	return dp[n];

	return dp[n] = steps(n-1, dp) + steps(n-2, dp);

}

int main()
{
	int n;
	cin >> n;
	int dp[1000] = {0};
	dp[0] = 1;
	cout<<steps(n, dp);


	return 0;
}