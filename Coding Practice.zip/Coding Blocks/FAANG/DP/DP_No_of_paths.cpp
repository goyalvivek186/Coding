#include<iostream>
#include<cstring>
using namespace std;

int paths(int n, int m, int dp[][100])
{
	if(n == 1 and m == 1)	return 1;

    if(dp[n][m] != -1)  return dp[n][m];

	int op1 = 0, op2 = 0;
	//left
	if(n != 1)	op1 = paths(n-1, m, dp);
	if(m != 1)	op2 = paths(n, m-1, dp);

	return dp[n][m] = op1 + op2;
}

int paths_BU(int n, int m)
{
    int dp[100][100];
    memset(dp, -1, sizeof(dp));
    for(int i = 0; i < n; i++)  dp[i][0] = 1;
    for(int j = 0; j < m; j++)  dp[0][j] = 1;

    dp[0][0] = 0;

    for(int i = 1; i < n; i++)
    {
        for(int j = 1; j < m; j++)
        {
            dp[i][j] = dp[i][j-1] + dp[i-1][j];
        }
    }

    return dp[n-1][m-1];

}

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n, m;
		cin >> n >> m;
        int dp[100][100] = {0};
        memset(dp, -1, sizeof(dp));
		//cout<<paths(n, m, dp)<<endl;
        cout<<paths_BU(n, m)<<endl;
	}


	return 0;
}