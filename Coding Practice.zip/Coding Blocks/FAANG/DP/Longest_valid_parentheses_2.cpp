#include<iostream>
#include<string>
#include<stack>

using namespace std;

int valid(string a)
{
	int n = a.size();
	stack<int> s;
	int curr = 0, ans = 0;
	for(int i = 0; i < n; i++)
	{
		if(a[i] == '(')
		{
			s.push(curr);
			curr = 0;
		}
		else
		{
			if(s.empty())
			{
				curr = 0;
			}
			else
			{
				curr += s.top() + 2;
				s.pop();
				ans = max(ans, curr);
			}
		}
	}
	return ans;
}


int main()
{
	string a;
	cin >> a;
	cout<<valid(a);



	return 0;
}