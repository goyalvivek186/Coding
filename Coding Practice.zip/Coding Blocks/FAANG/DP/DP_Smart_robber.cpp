#include<iostream>
#include<cstring>
using namespace std;

int smart(int *a, int n, int *dp)
{
	if(n <= 0)	return 0;
	if(dp[n-1] != -1)	return dp[n-1];

	int op1 = a[n-1] + smart(a, n-2, dp);
	int op2 = 0 + smart(a, n-1, dp);
	return dp[n-1] = max(op1, op2);
}

int smart_BU(int *a, int n)
{
    int dp[1000] = {0};
    dp[0] = a[0];
    dp[1] = max(a[1], a[0]);
    for(int i = 2; i < n; i++)
    {
        dp[i] = max(dp[i-2] + a[i], dp[i-1]);
    }
    //for(int i = 0; i < n; i++)  cout<<dp[i]<<" ";
    //cout<<endl;
    return dp[n-1];
}

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n;
		cin >> n;
		int a[10000] = {0};
		for(int i = 0; i < n; i++)	cin >> a[i];

		int dp[10000];
		memset(dp, -1, sizeof(dp));
		//cout<<smart(a, n, dp)<<endl;
        //for(int i = 0; i < n; i++)  cout<<dp[i]<<" ";
        cout<<smart_BU(a, n)<<endl;
	}


	return 0;
}