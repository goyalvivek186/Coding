#include<iostream>
#include<stack>
#include<string>
using namespace std;

int valid_stack(string a, int n)
{
	stack<char> s;
	int ans = 0, max_ans = 0;
	for(int i = 0; i < n; i++)
	{
		if(a[i] == '(')	s.push(a[i]);

		else
		{
			if(s.empty())
			{
				max_ans = max(ans, max_ans);
				ans = 0;
			}
			else if(s.top() == '(')
			{
                s.pop();
			    ans += 2;
            }
		}
	}
	return max(ans, max_ans);
}

int main()
{
	string s;
	cin >> s;
	int n = s.size();
    cout<<valid_stack(s, n);


	return 0;
}