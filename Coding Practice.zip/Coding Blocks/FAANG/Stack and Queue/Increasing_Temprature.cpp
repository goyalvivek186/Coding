#include<iostream>
#include<stack>
using namespace std;

int main()
{
	int n;
	cin >> n;
	int a[100001] = {0};
	for(int i = 0; i < n; i++)	cin >> a[i];

	int *ans = new int[n]{0};
	ans[n-1] = 0;
	for(int i = n-2; i >= 0; i--)
	{
		while(!s.empty() and a[s.top()] < a[i])	s.pop();

		if(s.empty())	ans[i] = 0;
		else			ans[i] = s.top() - i;

		s.push(i);		
	}
	for(int i = 0; i < n; i++)	cout<<ans[i]<<" ";


	return 0;
}