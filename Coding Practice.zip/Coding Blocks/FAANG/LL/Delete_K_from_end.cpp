#include<iostream>
using namespace std;

class node
{
public:
	int d;
	node *next;

	node(int d)
	{
		this->d = d;
		next = NULL;
	}
};


void remove_k_from_end(int k, node* &head)
{
	node* shead = head;
	node* lhead = head;
	while(k--)
	{
		lhead = lhead->next;
	}

	while(lhead->next != NULL)
	{
		shead = shead->next;
		lhead = lhead->next;
	}

	shead->next = shead->next->next;

}


int main()
{
	int n;
	cin >> n;
	int k;
	cin >> k;
	int d;
	cin >> d;
	node *head = new node(d);
	node *tail = head;
	for(int i = 1; i < n; i++)
	{
		cin >> d;
		node *n = new node(d);
		tail->next = n;
		tail = tail->next;
	}

	remove_k_from_end(k, head);
	while(head != NULL)
	{
		cout<<head->d;
		head = head->next;
	}


	return 0;
}