#include<iostream>
using namespace std;

class node
{

public:
	int d;;
	node *next;

	node(int a)
	{
		d = a;
		next = NULL;
	}

};

int main()
{
	int n;
	cin >> n;
    int d;
    cin >> d;
    node *head = new node(d);
	node *tail = head;
	for(int i = 0; i < n-1; i++)
	{
		int d;
		cin >> d;
		node *n = new node(d);
		tail->next = n;
		tail = n;
	}
    
    node *t = head;
    cout<<"Original List: ";
    while(t != NULL)
	{
		cout<<t->d<<" ";
		t = t->next;
	
    }
    cout<<endl;
	node *oh = head;
	node *eh = head->next;
	node *temp = eh;
	node *ot = oh;
	node *et = eh;
	while(temp != NULL and temp->next != NULL)
	{
        temp = temp->next;
		ot->next = temp;
		ot = ot->next;
		
        temp = temp->next;
		et->next = temp;
		et = et->next;
		
	}
    //Why is thos condition not needed???????????????????????????????
	/*if(temp != NULL)
	{
		ot->next = temp;
		ot = ot->next;
	}*/
	ot->next = eh;
	head = oh;

    cout<<"Modified List: ";
	while(head != NULL)
	{
		cout<<head->d<<" ";
		head = head->next;
	}


	return 0;
}