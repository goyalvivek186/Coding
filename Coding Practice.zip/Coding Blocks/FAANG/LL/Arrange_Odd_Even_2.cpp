#include <iostream>
using namespace std;

class node
{
public:
    int d;
    node *next;

    node(int d)
    {
        this->d = d;
        next = NULL;
    }
};

int main() 
{
    int n;
    cin >> n;

    int d;
    cin >> d;
    node *head = new node(d);
    node *tail = head;
    
    for(int i = 1; i < n; i++)
    {
        cin >> d;
        node *n = new node(d);
        tail->next = n;
        tail = tail->next;
    }
    tail = head;
    while(tail != NULL)
    {
        cout<<tail->d<<" ";
        tail = tail->next;
    }

    cout<<endl;

    node *oh = head;
    node *eh = head->next;
    node *temp = eh->next;
    node *ot = oh;
    node *et = eh;
    int cnt = 3;
    while(temp != NULL)
    {
        if(cnt % 2 != 0)
        {
            ot->next = temp;
            ot = ot->next;
            temp = temp->next;
        }
        else
        {
            et->next = temp;
            et = et->next;
            temp = temp->next;
        }
        cnt++;
    }

    ot->next = eh;
    et->next = NULL;
    head = oh;
    temp = head;
    while(temp != NULL)
    {
        cout<<temp->d<<" ";
        temp = temp->next;
    }

}
