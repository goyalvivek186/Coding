#include<iostream>
using namespace std;

class node
{
public:
	int d;
	node *next;

	node(int d)
	{
		this->d = d;
		next = NULL;
	}

};

node *swap_adj(node *head)
{
	if(head == NULL or head->next == NULL)
	{
		return head;
	}

	node *temp = head->next;
	head->next = temp->next;
	temp->next = head;
	head->next = swap_adj(head->next);
	head = temp;

	return head;
}

void print(node* head)
{
	while(head != NULL)
	{
		cout<<head->d<<" -> ";
		head = head->next;
	}
}


int main()
{
	int n;
	cin >> n;
	int d;
	cin >> d;
	node* head = new node(d);
	node* tail = head;
	for(int i = 1; i < n; i++)
	{
		cin >> d;
		node *n = new node(d);
		tail->next = n;
		tail = tail->next;
	}

	print(head);
	cout<<endl;

	head = swap_adj(head);

	print(head);


	return 0;
}