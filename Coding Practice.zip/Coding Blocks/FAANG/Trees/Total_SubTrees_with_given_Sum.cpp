#include<iostream>
#include<queue>
#include<vector>
#include<string>
#include<cstring>
using namespace std;

char ch[1000];
vector<int> v;

class node
{
public:
	int data;
	node *left, *right;
	node(int d)
	{
		data = d;
		right = left = NULL;
	}
};

node* build()
{
	if(v.size() == 0)	return NULL;
	queue<node*> q;
	int i = 0;
	int e = v[i++];
	node* root = new node(e);
	q.push(root);
	while(!q.empty() and i < v.size())
	{
		node* f = q.front();
		q.pop();
		e = v[i++];
		f->left = new node(e);
		q.push(f->left);
		if(i == v.size())	break;
		e = v[i++];
		f->right = new node(e);
		q.push(f->right);
		if(i == v.size())	break;
	}
	return root;
}

void get()
{
	char* ans = strtok(ch, " ");

    while(ans != NULL)
    {
        v.push_back(stoi(ans));
        ans = strtok(NULL, " ");
    }
    // for(int x : v)  cout<<x<<" ";
}

int sum(node *root)
{
	if(root == NULL)	return 0;
	return root->data + sum(root->left) + sum(root->right);
}

int get_sums(node* root, int s)
{
	if(root == NULL)	return 0;
	
	int ans = 0;
	if(sum(root) == s)
	{
		ans = 1;
	}
	int left = get_sums(root->left, s);
	int right = get_sums(root->right, s);
	return ans + left + right;

}

int main()
{
	int t, x;
	cin >> t;
	while(t--)
	{
		cin.ignore();
		cin.getline(ch, 1000);
		get();
		node* root = build();
		cin >> x;
		cout<<get_sums(root, x)<<endl;
	}

	return 0;
}