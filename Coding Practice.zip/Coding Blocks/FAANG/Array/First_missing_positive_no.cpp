#include<iostream>
using namespace std;

int main()
{
	int n;
	cin >> n;
	int *a = new int[n]{0};
	for(int i = 0; i < n; i++)	
	{
		cin >> a[i];
	}
    
    for(int i = 0; i < n; i++)
    {
    	if(a[i] < 0)	a[i] = 2*n;
    }

    for(int i = 0; i < n; i++)
    {
    	if(abs(a[i]) < n)
    	{
    		int ind = abs(a[i]) - 1;
    		a[ind] *= -1;
    	}
    }

    for(int i = 0; i < n; i++)
    {
    	if(a[i] > 0)	
    	{
    		cout<<i+1;
    		return 0;
    	}
    }


	return 0;
}