#include<iostream>
using namespace std;

void print(int a[][10], int n)
{
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < n; j++)
		{
			cout << a[i][j]<<" ";
		}
		cout<<endl;
	}
}

bool check(int a[][10], int n, int x, int y, int e)
{
	int i, j;
	i = x;
	j = 0;
	while(j < n)
	{
		if(a[i][j] == e)	return false;
		j++;
	}

	i = 0;
	j = y;
	while(i < n)
	{
		if(a[i][j] == e)	return false;
		i++;
	}

	x = (x/3) * 3;
	y = (y/3) * 3;
	for(i = x; i < x+3; i++)
	{
		for(j = y; j < y+3; j++)
		{
			if(a[i][j] == e)	return false;
		}
	}

	return true;
}

bool solve(int a[][10], int n, int x, int y)
{

	if(x >= n)
	{
		print(a, n);
		return true;
	}
	if(y >= n)
	{
		return solve(a, n, x+1, 0);
	}

	if(a[x][y] != 0)
	{
		return solve(a, n, x, y+1);
	}

	for(int i = 1; i <= n; i++)
	{
		bool can_place = check(a, n, x, y, i);
		if(can_place)
		{
			a[x][y] = i;
			bool success = solve(a, n, x, y+1);
			if(success)	return true;
			else		a[x][y] = 0;
		}
	}
	return false;
}

int main()
{
	int n;
	cin >> n;
	int a[10][10] = {0};
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < n; j++)
		{
			cin >> a[i][j];
		}
	}

	solve(a, n, 0, 0);

	return 0;
}