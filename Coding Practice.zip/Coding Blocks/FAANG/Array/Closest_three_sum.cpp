#include<iostream>
#include<algorithm>
using namespace std;

int closest(int *a, int n, int t)
{
	int ans = 10000;
	for(int i = 0; i < n-2; i++)
	{
		int j = i+1, k = n-1;
		while(j < k)
		{
			int sum = a[i] + a[j] + a[k];
			if(abs(t - abs(ans)) > abs(t - sum))	ans = sum;
			if(sum > t)	k--;
			else		j++;
		}
	}
	return ans;
}


int main()
{
	int n, t;
	cin >> n >> t;
	int *a = new int[n]{0};
	for(int i = 0; i < n; i++)	cin >> a[i];
    sort(a, a+n);
	cout<<closest(a, n, t);


	return 0;
}