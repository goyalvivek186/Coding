#include<iostream>
#include<algorithm>

using namespace std;

int main()
{
	int n, t;
	cin >> n >> t;
	int *a = new int[n]{0};
	for(int i = 0; i < n; i++)	cin >> a[i];

	if(!binary_search(a, a+n, t))
	{
		cout<<"-1 -1";
		return 0;
	}
	int lb = lower_bound(a, a+n, t) - a;
	int ub = upper_bound(a, a+n, t) - a;
	cout<<lb<<" "<<ub;



	return 0;
}