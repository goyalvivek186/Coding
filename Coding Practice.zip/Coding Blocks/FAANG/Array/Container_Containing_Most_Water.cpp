#include<iostream>

using namespace std;

int most_water(int *a, int n)
{
	int s = 0, e = n-1;
	int ans = 0;
	while(s < e)
	{
		ans = max(ans, (min(a[s], a[e]) * (e-s)) );
		if(a[s] < a[e])
		{
			s++;
		}
		else
		{
			e--;
		}
	}

	return ans;
}


int main()
{
	int n;
	cin >> n;
	int *a = new int[n] {0};
	for(int i = 0; i < n; i++)
	{
		cin >> a[i];
	}

	cout<<most_water(a, n);


	return 0;
}