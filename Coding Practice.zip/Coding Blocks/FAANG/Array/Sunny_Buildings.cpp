#include<iostream>
#include<climits>
using namespace std;

int main()
{
	int n;
	cin >> n;
	int cnt = 0;
	int max = INT_MIN;
	int a;
	for(int i = 0; i < n; i++)	
	{
		cin >> a;
		if(a >= max)
		{
			cnt++;
			max = a;
		}
	}
	cout<<cnt;
	


	return 0;
}