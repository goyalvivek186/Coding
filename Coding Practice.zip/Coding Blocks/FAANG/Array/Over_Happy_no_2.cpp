#include<iostream>
#include<unordered_set>
using namespace std;

int next(int n)
{
	int ans = 0;
	while(n > 0)
	{
		int x = n%10;
		ans += x*x;
		n /= 10;
	}
	return ans;
}

int main()
{
	int n;
	cin >> n;

	unordered_set<int> s;
	while(s.find(n) == s.end())
	{
		s.insert(n);
		int x = next(n);
		if(x == 1)
		{
			cout<<"true";
			return 0;
		}
		n = x;
	}
	cout<<"false";

	return 0;
}