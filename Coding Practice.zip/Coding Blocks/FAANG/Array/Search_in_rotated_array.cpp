#include<iostream>

using namespace std;

int rotated(int *a, int n, int t)
{
	int s = 0, e = n-1;
	while(s <= e)
	{
		int m = (s+e)/2;
		if(a[m] == t)	return m;

		if(a[m] > a[e])
		{
			if(t > a[m] or t <= a[e])
			{
				s = m + 1;
			}
			else
			{
				e = m - 1;
			}
		}
		else
		{
			if(t < a[m] or t >= a[s])
			{
				e = m-1;
			}
			else
			{
				s = m+1;
			}

		}

	}
	return -1;
}

int main()
{
	int n;
	cin >> n;
	int *a = new int[n]{0};
	for(int i = 0; i < n; i++)	cin >> a[i];
	int t;
	cin >> t;
	cout<<rotated(a, n, t);




	return 0;
}