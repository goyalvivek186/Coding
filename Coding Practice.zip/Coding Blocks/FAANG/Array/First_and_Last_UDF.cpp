#include<iostream>

using namespace std;

int lower_bound(int *a, int n, int t)
{
	int s = 0, e = n-1;
	int ans = -1;
	while(s <= e)
	{
		int m = (s+e)/2;
		if(a[m] == t and a[m-1] != t)	return m;
		else
		{
			if(a[m] >= t)	e = m-1;
			else			s = m+1;
		}
	}
	return -1;
}

int upper_bound(int *a, int n, int t)
{
	int s = 0, e = n-1;
	int ans = -1;
	while(s <= e)
	{
		int m = (s+e)/2;
		if(a[m] == t and a[m+1] != t)	return m;
		else
		{
			if(a[m] > t)	e = m-1;
			else			s = m+1;
		}
	}
	return -1;
}


int main()
{
	int n, t;
	cin >> n >> t;
	int *a = new int[n]{0};
	for(int i = 0; i < n; i++)	cin >> a[i];

	int lb = lower_bound(a, n, t);
	int ub = upper_bound(a, n, t);
	cout<<lb<<" "<<ub;



	return 0;
}