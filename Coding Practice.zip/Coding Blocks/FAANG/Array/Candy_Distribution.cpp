#include<iostream>
using namespace std;

int sum(int *a, int n)
{
    int ans = 0;
    for(int i = 0; i < n; i++)  ans += a[i];
    return ans; 
}

int distribute(int *a, int n)
{
	int p = a[0];
	int cnt;
	int *candy = new int[n]{0};
    candy[0] = 1;
	for(int i = 1; i < n; i++)
	{
		if(a[i] > a[i-1])
        {
            candy[i] = candy[i-1] + 1;
        }
		else
        {
            candy[i] = 1;
        }
	}
    for(int i = n-1; i > 0; i--)
    {
        if(a[i] == a[i-1])  continue;
        if(a[i] > a[i-1] and candy[i] <= candy[i-1]) candy[i] = candy[i-1] + 1;
        else if(a[i] < a[i-1] and candy[i] >= candy[i-1]) candy[i-1] = candy[i] + 1;

    }
    cnt = sum(candy, n);
	return cnt;
}

int main()
{
	int n;
	cin >> n;
	int *a = new int[n]{0};
	for(int i= 0; i < n; i++)	cin >> a[i];

	cout<<distribute(a, n);


	delete []a;
	return 0;
}