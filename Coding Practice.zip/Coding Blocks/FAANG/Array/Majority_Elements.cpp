#include<iostream>
using namespace std;

//Boyre Moore Majority Vote ALgo

int majority(int n, int *a)
{
	int c = 0, e = 0;
	for(int i = 0; i < n; i++)
	{
		if(c == 0)
		{
			e = a[i];
			c++;
		}
		else
		{
			if(a[i] != e)
			{
				c--;
			}
			else
			{
				c++;
			}
		}
	}

	int ans = 0;
	for(int i = 0; i < n; i++)
	{
		if(a[i] == e)	ans++;
	}

	if(ans > (n/2))	return e;
	else			return -1;
}

int main()
{
	int n;
	cin >> n;
	int a[10000] = {0};
	for(int i = 0; i < n; i++)	cin >> a[i];

	cout<<majority(n, a);

	return 0;
}