#include<iostream>

using namespace std;

int main()
{
	int n;
	cin >> n;
	int *a = new int[n]{0};
	if(n % 2 == 0)	//Even
	{
		int i = (n-1)/2;
		int j = n/2;
		int no = 1;
		while(i >=0 and j < n)
		{
			a[j] = a[i] = no;
			no++;
			a[i] *= -1;
			j++;
			i--;
		}
	}
	else
	{
		int j = (n/2) + 1;
		int i = (n/2) - 1;
		int no = 1;
		while(i >= 0 and j < n)
		{
			a[i] = a[j] = no;
			no++;
			a[i] *= -1;
			j++;
			i--;
		}
	}
	for(int i = 0; i< n; i++)
	{
		cout<<a[i]<<" ";
	}
	return 0;
}