#include<iostream>

using namespace std;

bool check(int n, int *fuel, int *cost, int ind)
{
	int net;
	for(int i = ind; i < n; i++)
	{
		net += fuel[i];
		net -= cost[i];
		if(net < 0)	return false;
	}
	return true;
}


int circular(int n, int *cost, int *fuel)
{
	int nf = 0, nc = 0;
	for(int i = 0; i < n; i++)
	{
		nf += fuel[i];
		nc += cost[i];
	}
	if(nc > nf)	return -1;

	for(int i = 0; i < n; i++)
	{
		if(fuel[i] > cost[i])
		{
			bool success = check(n, fuel, cost, i);
			if(success)	return i;
		}
	}
	return -1;
}

int main()
{
	int n;
	cin >> n;
	int *cost = new int[n]{0};
	int *fuel = new int[n]{0};
	for(int i = 0; i < n; i++)	cin >> fuel[i];
	for(int i = 0; i < n; i++)	cin >> cost[i];

	cout<<circular(n ,cost, fuel);

	return 0;
}