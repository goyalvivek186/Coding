#include<iostream>
#include<unordered_set>

using namespace std;

bool check(int n)
{
	int ans = 0;
	while(n > 0)
	{
		ans += n % 10;
		n = n/10;
	}
	return(ans == 1);
}

int next(int n)
{
	int ans = 0;
	while(n > 0)
	{
		int no = n % 10;
		n = n / 10;
		ans = ans + (no*no);
	}
	return ans;
}

int main()
{
	int n;
	cin >> n;
	unordered_set<int> s;
	while(s.find(n) == s.end())
	{
		if(check(n))
		{
			cout<<"true";
			return 0;
		}
		else
		{
			s.insert(n);
			n = next(n);
		}

	}

	cout<<"false";

	return 0;
}