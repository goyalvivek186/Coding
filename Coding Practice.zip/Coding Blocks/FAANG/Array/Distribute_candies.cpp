#include <iostream>
#include <unordered_set>

using namespace std;

int main()
{
	int n, a;
	cin >> n;
	int cnt = 0;
	unordered_set<int> s;
	for(int i = 0; i < n; i++)
	{
		cin >> a;
		if(s.find(a) == s.end())
		{
			cnt++;
			s.insert(a);
		}
	}
	if(cnt > n/2)	cnt = n/2;
	cout<<cnt;


	return 0;
}