#include<iostream>
using namespace std;

//Elements occuring more than N/3 times = Atmost 2 elements

pair<int, int> Majority(int *a, int n)
{
	pair<int, int> ele;
	pair<int, int> cnt;

	ele.first = a[1];
	cnt.first = 1;
	cnt.second = 0;
	ele.second = -1;
	for(int i = 1; i < n; i++)
	{
		if(ele.first == a[i])
		{
			cnt.first ++;
		}
		else if(ele.second == a[i])
		{
			cnt.second ++;
		}
		else if(cnt.first == 0)
		{
			ele.first = a[i];
			cnt.first ++;
		}
		else if(cnt.second == 0)
		{
			ele.second = a[i];
			cnt.second ++;
		}
		else
		{
			cnt.first--;
			cnt.second--;
		}
	}

	int e1 = ele.first, e2 = ele.second;
	int ans1 = 0, ans2 = 0;
	for(int i = 0; i < n; i++)
	{
		if(a[i] == e1)	ans1++;
		if(a[i] == e2)	ans2++;
	}
	if(ans1 < (n/3))	ele.first = -1;
	if(ans2 < (n/3))	ele.second = -1;

	if(ele.first > ele.second)
	{
		swap(ele.first, ele.second);
	}

	return ele;
}

int main()
{
	int n;
	cin >> n;
	int *a = new int[n]{0};
	for(int i = 0; i < n; i++)
	{
		cin >> a[i];
	}
	pair<int, int> ans = Majority(a, n);
	if(ans.first != -1)	cout<<ans.first<<endl;
	if(ans.second != -1)	cout<<ans.second<<endl;
}