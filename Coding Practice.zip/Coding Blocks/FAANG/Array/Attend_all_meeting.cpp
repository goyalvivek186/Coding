#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

bool compare(pair<int, int> p1, pair<int, int> p2)
{
	if(p1. first == p2.first)	return p1.second < p2.second;

	return p1.first < p2.first; 
}

bool can_attend(vector<pair<int, int>> v)
{
	for(int i = 1; i < v.size(); i++)
	{
		if(v[i].first < v[i-1].second)	return false;
	}
	return true;
}

int main()
{
	int n;
	cin >> n;
	vector<pair<int, int>> v;
	for(int i = 0; i < n; i++)
	{
		int a, b;
		cin >> a >> b;
		v.push_back(make_pair(a, b));
	}
	sort(v.begin(), v.end(), compare);

	if(can_attend(v))
	{
		cout<<"true";
	}
	else
	{
		cout<<"false";
	}

}