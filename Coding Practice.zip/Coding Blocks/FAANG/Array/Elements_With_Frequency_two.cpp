#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

int main()
{
	int n;
	cin >> n;
	int *a = new int[n]{0};
	for(int i = 0; i < n; i++)
	{
		cin >> a[i];
	}
    vector<int> v;

	for(int i = 0; i < n; i++)
	{
		int ind = abs(a[i]);
		if(a[ind] < 0)	v.push_back(ind);
		else			a[ind] *= -1;
	}
    sort(v.begin(), v.end());

    cout<<"[";
    n = v.size();
    for(int i = 0; i < n-1; i++)
    {
        cout<<v[i]<<", ";
    }
    cout<<v[n-1]<<"]";

	return 0;
}