#include<iostream>
#include<unordered_map>
using namespace std;

int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        int n;
        cin >> n;
        int sum = 0;
        unordered_map<int, int> m;
        m[0] = 1;
        for(int i = 0; i < n; i++)
        {
            int a;
            cin >> a;
            sum += a;
            if(m.count(sum) == 0)	m[sum] = 1;
            else					m[sum]++;
        }
        int ans = 0;
        for(auto i : m)
        {
            if(i.second > 1)
            {
                int num = i.second;
                ans = ans + ((num * (num - 1))/2);
            }
        }
        cout<<ans<<endl;
    }

	return 0;
}