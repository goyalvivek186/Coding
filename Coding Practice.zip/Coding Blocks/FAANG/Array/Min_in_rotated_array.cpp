#include<iostream>

using namespace std;

int find(int *a, int n)
{
	int s = 0, e = n-1;
	while(s <= e)
	{
		int m = (s+e)/2;
		if(a[m] < a[m-1] and a[m] < a[m+1])	return m;
		else
		{
			if(a[m] > a[e])	s = m+1;
			else			e = m-1;
		}
	}
	return -1;
}

int main()
{
	int n;
	cin >> n;
	int *a = new int[n]{0};
	for(int i = 0; i < n; i++)	cin >> a[i];

	cout<<find(a, n);


	delete []a;
	return 0;
}