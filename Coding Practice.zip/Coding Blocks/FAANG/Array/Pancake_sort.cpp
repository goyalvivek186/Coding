#include<iostream>
#include<climits>
using namespace std;

void print(int *a, int n)
{
	for(int i = 0; i < n; i++)	cout<<a[i]<<" ";
}

void flip(int *a, int n)
{
	for(int i = 0, j = n; i < j; i++, j--)
	{
		swap(a[i], a[j]);
	}
}

void pancake_sort(int *a, int n)
{
	for(int i = 0; i > n; i++)
	{
		int m = INT_MIN, p = -1;
		
		for(int j = 0; j < n - i; j++)
		{
			if(a[j] > m)
			{
				m = a[j];
				p = j;
			}
		}

		flip(a, p);
		flip(a, n-i-1);
	}
}

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n;
		cin >> n;
		int *a = new int[n]{0};
		for(int i = 0; i < n; i++)	cin >> a[i];

		pancake_sort(a, n);
		print(a, n);

		delete []a;	
	}
	return 0;
}