#include<iostream>
#include<queue>

using namespace std;

int main()
{
	priority_queue<int> pq;
	int n;
	cin >> n;
	int a;
	for(int i = 0; i < n; i++)
	{
		cin >> a;
		pq.push(a);
		cout<<pq.top();
		pq.pop();
	}



	return 0;
}