#include<string>
#include<iostream>

using namespace std;

int main()
{
	int n;
    cin >> n;
	string *s = new string[n];
	for(int i = 0; i < n; i++)
	{
		cin >> s[i];
	}
	string s1, s2;
	cin >> s1 >> s2;
	int ans = n+2;
	string scr, dst;
	int p = -1;

	for(int i = 0; i < n; i++)
	{
		if(p == -1)
		{
			if(s[i] == s1)
			{
				p = i;
				scr = s1;
				dst = s2;
			}
			else if(s[i] == s2)
			{
				p = i;
				scr = s2;
				dst = s1;
			}
		}
		else
		{
			if(s[i] == dst)
			{
				ans = min(ans, i-p);
				p = i;
				swap(dst, scr);
			}
		}
	}
	cout<<ans;

	return 0;
}
