#include<iostream>
#include<unordered_map>
#include<string>
using namespace std;

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		string s;
		cin >> s;
		int curr = 0;
		int ans = 0;
		int j = 0;
		unordered_map<char, int> m;
		for(int i = 0; i < s.size(); i++)
		{
			if(m.count(s[i]) == 0 or m[s[i]] == -1)
			{
				curr = (i-j) + 1;
				m[s[i]] = i;
				ans = max(ans, curr);
			}
			else
			{
				j = m[s[i]] + 1;
				m[s[i]] = -1;
				i--;

			}
            //cout<<"i = "<<i<<"\tj = "<<j<<endl;
		}
		cout<<ans<<endl;
	}


	return 0;
}