#include<iostream>
#include<string>
#include<vector>
#include<unordered_set>

using namespace std;

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		vector<char> v;
		string s;
		cin >> s;
		unordered_set<char> cnt;
		int ans = 0;
		int lng = 0;
		for(int i = 0; i < s.size(); i++)
		{
			if(cnt.find(s[i]) == cnt.end())
			{
				lng++;
				cnt.insert(s[i]);
				v.push_back(s[i]);
				ans = max(ans, lng);
			}
			else
			{
				while(cnt.find(s[i]) != cnt.end())
				{
					s.erase(v[0]);
					v.erase(v.begin());
					lng--;
				}
                i--;
			}
		}
		cout<<ans;
	}

	return 0;
}
