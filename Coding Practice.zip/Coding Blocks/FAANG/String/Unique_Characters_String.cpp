#include<iostream>
#include<vector>
#include<string>
#include<climits>
#include<unordered_set>
using namespace std;

int unique(vector<string> v, int i, string s)
{
	if(i == v.size())
	{
		unordered_set<char> visited;
		for(int it = 0; it < s.size(); it++)
		{
			if(visited.find(s[it]) != visited.end())	return 0;
			else
			{
				visited.insert(s[it]);
			}
		}
		return s.size();
	}
	int op1, op2;
	op1 = op2 = INT_MIN;
	if(s.size() + v[i].size() <= 26)
	{
		//Include
		op1 = unique(v, i+1, s+v[i]);
	}
        //Exclude
	op2 = unique(v, i+1, s);
	return max(op1, op2);

}


int main()
{
	int n;
    cin >> n;
	vector<string> v;
	for(int i = 0; i < n; i++)
	{
		string s;
		cin >> s;
		v.push_back(s);
	}
    
	string ans = "";
	cout<<unique(v, 0, ans);


	return 0;
}