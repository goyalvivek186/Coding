#include<iostream>
#include<queue>
#include<vector>

using namespace std;

int main()
{
	priority_queue<int, vector<int>, greater<int>> pq;
	int n;
	cin >> n;
	vector <pair<int, int>> v;
	for(int i = 0; i < n; i++)
	{
		int a, b;
		cin >> a >> b;
		v.push_back({a, b});
	}
	int cnt = 1;
	pq.push(v[0].second);
	for(int i = 1; i < n; i++)
	{
		if(v[i].first >= pq.top())
		{
			pq.pop();
			pq.push(v[i].second);
		}
		else
		{
			cnt++;
			pq.push(v[i].second);
		}
	}
	cout<<cnt'

	return 0;
}