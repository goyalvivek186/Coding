#include<iostream>
#include<string>
#include<unordered_map>
#include<vector>
#include<climits>
using namespace std;

int main()
{
	int n;
	cin >> n;
	unordered_map<string, vector<int>> m;
	for(int i = 0; i < n; i++)
	{
		string s;
		cin >> s;
		m[s].push_back(i);
	}
	string s1, s2;
	cin >> s1 >> s2;
	int ans1, ans2;
	ans1 = ans2 = INT_MAX;
	int ini = m[s1][0];
	for(auto i : m[s2])
	{
		ans1 = min(ans1, abs(ini - i));
	}
	ini = m[s2][0];
	for(auto i : m[s1])
	{
		ans2 = min(ans2, abs(ini - i));
	}
	cout<<min(ans2, ans1);

	return 0;
}