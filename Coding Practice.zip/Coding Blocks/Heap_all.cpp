#include<iostream>
#include<vector>
using namespace std;

class heap
{
	vector<int> v;
	bool minheap;		//If the heap is minheap so its true else false

	bool condition(int i, int p)		//For min and max heap
	{
		if(minheap)
		{
			return v[i] < v[p];
		}
		else
		{
			return v[i] > v[p];
		}
	}

	void heapify(int ind)		//Convert the array/ BT into heap again agter any operation
	{
		int min_index = ind;
		int last = v.size() - 1;
		int left = ind * 2;
		int right = left + 1;
				//	Get the min element of left and right element
		if(left <= last and condition(left,min_index))
		{
			min_index = left;
		}

		if(right <= last and condition(right, min_index))
		{
			min_index = right;
		}

		if(min_index != ind)		//Base case as well
		{
			swap(v[min_index], v[ind]);
			heapify(min_index);
		}
	}


public:
	heap(int default_size = 10, bool type = true)
	{
		v.reserve(default_size);
		minheap = type;
		v.push_back(-1);		//Reserve 0th index
	}

	void push(int d)
	{
		v.push_back(d);
		int index = v.size() - 1;		//-1 because Heap starts from 1st index of array/vector
		int par = index / 2;

		while(index > 1 and condition(index, par))
		{
			swap(v[index], v[par]);
			index = par;
			par = par/2;
		}

	}

	int top()
	{
		return v[1];
	}

	void pop()		//Remove the max/min element in tye max/min heap
	{
		int last = v.size() - 1;
		swap(v[1], v[last]);
		v.pop_back();
		heapify(1);
	}

	bool empty()
	{
		return v.size() == 1;
	}

};

bool condition(vector<int> &v, int p, int i, bool minheap)
{
    if(minheap)
    {
        return v[p] > v[i];
    }
    else
    {
        return v[p] < v[i];
    }
}


void heap_from_vector(vector<int> &v, bool type = true)         //O(n log n)
{                                                           //First (v[1]) is atright position in forst iterationa s it has no parent
        for(int i = 2; i != v.size(); i++)
        {
            int index = i;
            int p = i/2;
            while(p >= 1 and condition(v, p, index, type))
            {
                swap(v[p], v[index]);
                index = p;
                p = p/2;
            }
        }
}

void heapify(vector<int> &v, bool type, int ind, int size)
{
    int m = ind;
    int left = m * 2;
    int right = left + 1;
    int last = size;

    if(left <= last and condition(v, m, left, type))
    {
        m = left;
    }
    if(right <= last and condition(v, m, right, type))
    {
        m = right;
    }

    if(m != ind)
    {
        swap(v[m], v[ind]);
        heapify(v, type, m, size);
    }
}

void heap_from_vector_optimized(vector<int> &v, bool type = true)
{
    for(int i = (v.size()-1)/2; i > 0; i--)
    {
        heapify(v, type, i, v.size()-1);
    }
}

void heap_sort(vector<int> &v, bool type = true)        //true = ascending
{
    for(int i = v.size(); i > 1; i--)
    {
        swap(v[1], v[i-1]);
        heapify(v, type, 1, i-1);
    }
}

int main()
{
	/*heap h;
	int n;
	cin >> n;
	for(int i = 0; i < n; i++)
	{
		int no;
		cin >> no;
		h.push(no);
	}
	while(!h.empty())
	{
		cout<<h.top()<<" ";
		h.pop();
	}*/

    int n;
    cin >> n;
    vector<int> x;
    x.reserve(n+1);
    for(int i = 0; i < n; i++)
    {
        int no;
        cin >> no;
        x.push_back(no);
    }

    heap_from_vector_optimized(x, false);
    heap_sort(x, false);
    for(int it : x)
    {
        cout<<it<<" ";
    }


	return 0;
}