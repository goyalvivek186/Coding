#include<iostream>
#include<string>
#include<algorithm>
#include<climits>

using namespace std;

void sort_linear(int a[], int n)
{
	int m = 0, e = n - 1;
	int s = 0;
	while(m <= e)
	{
		if(a[m] == 0)
		{
			swap(a[m], a[s]);
			m++;
			s++;
		}
		else if(a[m] == 1)
		{
			
			m++;
		}
        else{
            swap(a[m], a[e]);
            e--;
        }
	}
	for(int i = 0; i < n; i++)
	{
		cout<<a[i] <<endl;
	}
}

int main()
{
	int n;
	cin >> n;
	int a[n];
	for(int i = 0; i < n; i++)
	{
		cin >> a[i];
	}
	sort_linear(a, n);
	

	
	return 0;
}