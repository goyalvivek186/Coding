#include<iostream>
using namespace std;


int main()
{
	int i, j, n, k, t = 2;
	cin>> n;
	int x = (2*n) + 1, l = n;
	for(i = n; i > 0; i--)
	{
		for(k = n; k >= i; k--)
			{
				cout<<k<<" ";
			}
			for(k = x; k > t; k--)
			{
				cout<<"  ";
			}
			for(k = l; k <= n; k++)
			{
				cout<<k<<" ";
			}
			l--;
			t = t+2;
			cout<<"\n";	
	}

	/*if (i == 0)
	{
		for(i = n; i >= 0; i--)
		{
			cout<<i<<" ";										
		}
		for(i = 1; i <=n; i++)
		{
			cout<<i<<" ";
		}
	}
	cout<<"\n";*/

	t = -1;
	l = 0;
	int m = 0;
	for(i = 0; i <= n; i++)
	{

		for(k = n; k > m; k--)
		{
			cout<<k<<" ";
		}
		for(k = 0; k <= t; k ++)
		{
			cout<<"  ";
		}
		for(k = l; k <= n; k++)
		{
			cout<<k<<" ";
		}
		l++;
		t = t + 2;
		cout<<"\n";
		m++;
	}



	return 0;
}