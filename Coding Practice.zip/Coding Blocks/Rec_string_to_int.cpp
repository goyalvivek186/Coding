#include<iostream>
#include<string>
#include<math.h>

using namespace std;

int convert(string s, int n, int i, int p)
{
	if(p == n-1)
	{
	return s[p] - '0';
	}
    int x = convert(s, n, i/10, p+1);
	return ((s[p] - '0') * i) + x;

	
}

int main()
{
	string s;
	getline(cin, s);
	int n = s.length();
    int i = pow(10, n-1);
	int a = convert(s, n, i, 0);
    cout<<a;	


	return 0;
}