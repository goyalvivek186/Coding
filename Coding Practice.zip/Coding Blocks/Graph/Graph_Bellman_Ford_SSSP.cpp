#include<iostream>
#include<vector>
#include<climits>

using namespace std;

vector<int> bellman_ford(int n, vector<vector<int>> edges, int s)
{
	vector<int> dis(n+1, INT_MAX);
	dis[s] = 0;
	for(int i = 0; i < (n-1); i++)
	{
		for(auto edge : edges)
		{
			int w = edge[0];
			int a = edge[1];
			int b = edge[2];

			if(dis[a] != INT_MAX and (dis[a] + w < dis[b]))
			{
				dis[b] = dis[a] + w;
			}
		}
	}
	//	-ve cycle check
	for(auto edge : edges)
		{
			int w = edge[0];
			int a = edge[1];
			int b = edge[2];

			if(dis[a] != INT_MAX and (dis[a] + w < dis[b]))
			{
				cout<<"-ve cycle present";
				exit(0);
			}
		}
}

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n, m;
		cin >> n >> m;
		vector<vector<int>> edges;
		while(m--)
		{
			int a, b, w;
			cin >> a >> b >> w;
			edges.push_back({w, a, b});
		}
		int s;
		cin >> s;
		vector<int> dis = bellman_ford(n, edges, s);

		for(auto i : dis)
		{
			cout<<i<<" ";
		}
	}

	return 0;
}

/*

no cycle
1
3 3 
1 2 3 
2 3 4
1 3 -10
1

cycle
1
3 3 
1 2 3 
2 3 4
3 1 -10
1

*/