#include<iostream>
#include<unordered_map>
#include<set>
#include<list>
#include<climits>

using namespace std;

template<typename T>
class graph
{
public:
	unordered_map<T, list<pair<T, int>> > g;

	void add_edge(T a, T b, int c, bool bi = true)
	{
		g[a].push_back(make_pair(b, c));
		if(bi)
		{
			g[b].push_back(make_pair(a, c));
		}
	}

	void dijkstra(T source)
	{
		unordered_map<T, int> dist;
		for(auto l : g)
		{
			dist[l.first] = INT_MAX;
		}
		dist[source] = 0;
		set<pair<int, T> > s;
		s.insert(make_pair(0, source));
		while(!s.empty())
		{
			auto f = *(s.begin());
			int node_cost = f.first;
            s.erase(s.begin());
            T node = f.second;
			for(auto l : g[node])
			{
				if(node_cost + l.second < dist[l.first])
				{
					T dest = l.first;
					auto d = s.find(make_pair(dist[dest], dest));
					if(d != s.end())
					{
						s.erase(d);
					}
					dist[dest] = node_cost + l.second;
					s.insert(make_pair(dist[dest], dest));
				}
			}
		}

		for(auto l : dist)
		{
			cout<<"Cost of "<<l.first<<" from "<<source<<" = "<<l.second<<endl;
		}
	}

    void print()
	{
		for(auto p : g)
		{
			T a = p.first;
			cout<< a <<"-> ";
			for(auto l : p.second)
			{
				cout<<l.first<<"("<<l.second <<")"<<", ";
			}
			cout<<endl;
		}
	}
};

int main()
{
	graph<int> g;
    g.add_edge(1, 2, 1);
    g.add_edge(1, 3, 4);
    g.add_edge(2, 3, 1);
    g.add_edge(3, 4, 2);
    g.add_edge(1, 4, 7);
    g.dijkstra(1);
    //g.print();
	return 0;
}