#include<iostream>
#include<vector>

using namespace std;

bool dfs_helper(vector<int> v[], int node, int par, int *visited, int color)
{
	visited[node] = color;
	for(auto edge : v[node])
	{
		if(visited[edge] == 0)
		{
			bool success = dfs_helper(v, edge, node, visited, 3-color);
			if(!success)	return false;
		}
		else
		{
			if(edge != par and visited[edge] == visited[node])
			{
				return false;
			}
		}
	}
	return true;

}

bool bipartite(vector<int> v[], int n)
{
	int visited[n] = {0};	//0 = not visited

	return dfs_helper(v, 0, -1, visited, 1);
}

int main()
{
	int n, m;
	cin >> n >> m;
	vector<int> v[n];
	while(m--)
	{
		int a, b;
		cin >> a >> b;
		v[a].push_back(b);
		v[b].push_back(a);
	}


	if(bipartite(v, n))
	{
		cout<<"Yes"<<endl;
	}
	else
	{
		cout<<"No"<<endl;
	}

	return 0;
}