#include<iostream>
#include<vector>

using namespace std;
#define M 1000
class graph
{
	int V;
public:

	graph(int V)
	{
		this->V = V;
	}

	vector<vector<int>> Floyd(vector<vector<int>> g)
	{
		for(int k = 0; k < V; k++)
		{
			for(int i = 0; i < V; i++)
			{
				for(int j = 0; j < V; j++)
				{
					g[i][j] = min(g[i][j], g[i][k] + g[k][j]);
				}
			}
		}
	}
};

int main()
{
	vector<vector<int>> m ={{0, M, -2, M},
							{4, 0, 3, M },
							{M, M, 0, 2},
							{M, -1, M, 0} 
						};

	graph g(4);
	m = g.Floyd(m);
	for(auto i : m)
	{
		for(auto j : i)
		{
			cout<<j<<" ";
		}
		cout<<endl;
	}

	return 0;
}

/*
0 -1 -2 0 
4 0 2 4 
5 1 0 2 
3 -1 1 0 
*/