#include<iostream>
#include<map>
#include<list>
#include<string>
#include<queue>
#include<climits>

using namespace std;

template<typename T>
class graph
{

public:
	map<T,list<T> > g;

	void add_edge(T a, T b, bool bi)
	{
		g[a].push_back(b);
		if(bi)
		{
			g[b].push_back(a);
		}
	}

    void BFS(T source)
    {
        map<T, bool> visited;
        for(auto l : g)
        {
            visited[l.first] = false;
        }

        visited[source] = true;
        queue<T> q;
        q.push(source);
        while(!q.empty())
        {
            T f = q.front();
            cout<<f<<" ";
            q.pop();
            for(auto l : g[f])
            {
                if(!visited[l]) 
                {
                    q.push(l);
                    visited[l] = true;
                }
            }
        }
    }

    void DFS_helper(T source, map<T, bool> &visited)
    {
    	cout<<source<<" ";
    	for(auto l : g[source])
    	{
    		if(!visited[l])
    		{
    			visited[l] = true;
    			DFS_helper(l, visited);
    		}
    	}
    }



    void DFS(T source)
    {
    	map<T, bool> visited;
    	for(auto l : g)
    	{
    		visited[l.first] = false;
    	}
    	visited[source] = true;

    	DFS_helper(source, visited);
    }
/*
	//With path
	void SSSP(T source, T goal)
        {
            map<T, int> dist;
            map<T, T> path;
            for(auto l : g)
            {
                dist[l.first] = INT_MAX;
            }
            path[source] = source;
            dist[source] = 0;
            queue<T> q;
            q.push(source);
            while(!q.empty())
            {
                T f = q.front();
                q.pop();
                for(auto l : g[f])
                {
                    if(dist[l] == INT_MAX)
                    {
                        dist[l] = dist[f] + 1;
                        path[l] = f;
                        q.push(l);
                    }
                }
            }

            for(auto l : dist)
            {
                cout<<l.first<<" "<<l.second<<endl;
            }

            T temp = goal;
            do
            {
                cout<<temp<<" <- ";
                temp = path[goal];
                goal = temp;
            }while(temp != source);
            cout<<source;
        }

*/
    void SSSP(T source)
    {
    	map<T, int> dist;
    	for(auto l : g)
    	{
    		dist[l.first] = INT_MAX;
       	}
       	dist[source] = 0;

    	queue<T> q;
    	q.push(source);
    	while(!q.empty())
    	{
    		T f = q.front();
    		q.pop();
    		for(auto l : g[f])
    		{
    			if(dist[l] == INT_MAX)
    			{
    				q.push(l);
    				dist[l] = dist[f] + 1;
    			}
    		}
    	}

    	for(auto l : g)
    	{
    		cout<<"Distace from "<<source<<" to "<<l.first<<" = "<<dist[l.first]<<endl;
    	}

    }

    void component_helper(T source, map<T, bool> &visited)      //DFS_HELPER
    {
    	for(auto l : g[source])
    	{
    		if(!visited[l])
    		{
    			visited[l] = true;
    			component_helper(l, visited);
    		}
    	}
    }

    int components()
    {
    	map<T, bool> visited;
    	for(auto l : g)
    	{
    		visited[l.first] = false;
    	}
    	int c = 0;
    	for(auto l : g)
    	{
    		if(visited[l.first] == false)
    		{
    			c++;
    			component_helper(l.first, visited);
    		}
    	}
    	return c;
    }

    void topological_helper(T source, list<T> &order, map<T, bool> &visited)
    {
    	visited[source] = true;
    	for(auto l : g[source])
    	{
    		if(!visited[l])
    		{
    			topological_helper(l, order, visited);
    		}
    	}
    	order.push_front(source);
    }

    void topological_sort_DFS()
    {
    	list<T> order;
    	map<T, bool> visited;
    	for(auto l : g)
    	{
    		visited[l.first] = false;
    	}
    	for(auto l : g)
    	{
    		if(!visited[l.first])
    		{
    			topological_helper(l.first, order, visited);
    		}
    	}

    	for(auto l : order)
    	{
    		cout<<l<<" ";
    	}

    }

    void topological_sort_BFS()
    {
    	map<T, int> indeg;
    	for(auto l : g)
    	{
    		indeg[l.first] = 0;
    	}
    	for(auto l : g)
    	{
    		for(auto m : l.second)
    		{
    			indeg[m]++;
    		}
    	}
    	queue<T> q;
    	for(auto l : indeg)
    	{
    		if(l.second == 0)	q.push(l.first);
    	}

    	while(!q.empty())
    	{
    		T f = q.front();
    		q.pop();
    		cout<<f<<" ";
    		for(auto l : g[f])
    		{
    			indeg[l]--;
    			if(indeg[l] == 0)	q.push(l);
    		}
    	}
    }


    	//Check if there is a cycle or not
    	//Not for tree as it is for undirected, TREE = DAG (Directed Acyclic Graph)
    bool is_cycle_BFS()		//For undirected graph, will ot work for directed graph
    {
    	map<T, bool> visited;
    	map<T, T> par;
    	T source;
    	for(auto l : g)
    	{
    		source = l.first;
    		visited[l.first] = false;
    		par[l.first] = l.first;
    	}

    	queue<T> q;
    	q.push(source);
    	visited[source] = true;
    	while(!q.empty())
    	{
    		T f = q.front();
    		q.pop();

    		for(auto l : g[f])
    		{
    			if(visited[l] == true and par[f] != l)	//Important
    			{
    				return false;
    			}
    			else if(visited[l] == false)
    			{
    				visited[l] = true;
    				par[l] = f;
    				q.push(l);
    			}
    		}
    	}
        return true;
    }

    bool cycle_helper(T nbr, map<T, bool> &visited, T par)
    {
        visited[nbr] = true;
        for(auto l : g[nbr])
        {
            if(visited[l] == false)
            {
                bool success = cycle_helper(l, visited, nbr);
                if(!success)
                {
                    return false;
                }
            }
            else if(l != par)
            {
                return false;
            }
        }
        return true;
    }
    	//Undirected graph
    bool is_cycle_DFS()
    {
        map<T, bool> visited;
        T source;
        for(auto l : g)
        {
            source = l.first;
            visited[l.first] = false;
        }
        return cycle_helper(source, visited, source);
    }

	void print()
	{
		for(auto p : g)
		{
			T a = p.first;
			cout<< a <<"-> ";
			for(auto l : p.second)
			{
				cout<<l<<" ";
			}
			cout<<endl;
		}
	}


};


int main()
{
    
	graph<int> g;
	/*
    g.add_edge(0, 1, true);
	//g.add_edge(0, 3, true);
	g.add_edge(1, 2, true);
    g.add_edge(2, 3, true);
    g.add_edge(3, 4, true);
    g.add_edge(4, 5, true);
    */

	//Topological sorting = DAG
	g.add_edge(0, 2, false);
	g.add_edge(1, 2, false);
	g.add_edge(1, 4, false);
    g.add_edge(4, 5, false);
    g.add_edge(2, 3, false);
    g.add_edge(2, 5, false);
    g.add_edge(3, 5, false);


/*
    cout<<"Print = "<<endl;
    g.print();
    cout<<endl;

    cout<<"BFS = ";
    g.BFS(0);
    cout<<endl<<endl;

    cout<<"DFS = ";
    g.DFS(0);
    cout<<endl<<endl;

    cout<<"SSSP = "<<endl;
    g.SSSP(0);
    cout<<endl;

    cout<<"No of Components = "<<g.components();

    cout<<endl<<endl;

    cout<<"Topological ordering DFS = ";
    g.topological_sort_DFS();
*/
    if(g.is_cycle_DFS())
    {
        cout<<"Tree"<<endl;
    }
    else
    {
        cout<<"Not a tree"<<endl;
    }
	return 0;
}