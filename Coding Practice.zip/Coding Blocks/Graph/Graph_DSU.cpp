#include<iostream>
#include<list>

using namespace std;

class graph
{
	int V;
	list<pair<int, int> > l;
public:
	graph(int V)
	{
		this->V = V;
	}

	void add_edge(int a, int b)
	{
		l.push_back(make_pair(a, b));
	}

	int find(int a, int *par)
	{
		if(par[a] == -1)
		{
			return a;
		}
		/*else
		{
			return find(par[a], par);
		}*/
		else		//Optimal	--Path compression
		{
			par[a] = find(par[a], par);
			return par[a];
		}
	}

	void union_set(int a, int b, int *par, int *rank)
	{
		int s1 = find(a, par);
		int s2 = find(b, par);
		/*
		if(s1 != s2)
		{
			par[b] = a;
		}*/
		if(s1 != s2)		//Optimal	--Union by rank
		{
			if(rank[s1] > rank[s2])
			{
				par[s2] = s1;
				rank[s1] += rank[s2];
			}
			else
			{
				par[s1] = s2;
				rank[s2] += rank[s1];
			}
		}
	}

	bool is_cycle()
	{
		int *par = new int [V];
		int *rank = new int [V];
		for(int i = 0; i < V; i++)
		{
			par[i] = -1;		//Each node = parent of itself
			rank[i] = 1;		//no of child
		}
		for(auto edge : l)
		{
			int a = edge.first;
			int b = edge.second;
			if(par[a] != par[b] or (par[a] == -1 and par[b] == -1))
			{
				union_set(a, b, par, rank);		//Creating sets **Does not work on the made graph
			}								//Makes its own sets and check through them
			else
			{
				return true;		//Contains cycle
			}
		}
        return false;
	}

};

int main()
{
	graph g(4);
	g.add_edge(0, 1);
	g.add_edge(1, 2);
	g.add_edge(2, 3);
	//g.add_edge(3, 0);

	if(g.is_cycle())
	{
		cout<<"Cycle found"<<endl;
	}
	else
	{
		cout<<"Cycle not found"<<endl;
	}
	return 0;
}