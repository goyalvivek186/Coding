#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

class DSU
{
	int V;
	int *par;
	int *rank;

public:
	DSU(int V)
	{
		this->V = V;
		par = new int [V];
		rank = new int [V];
		for(int i = 0; i < V; i++)
		{
			par[i] = -1;
			rank[i] = 1;
		}
	}

	int find(int a)
	{
		if(par[a] == -1)	return a;
		else
		{
			return par[a] = find(par[a]);
		}
	}

	void union_set(int a, int b)
	{
		int s1 = find(a);
		int s2 = find(b);
		if(s1 != s2)
		{
			if(rank[s1] > rank[s2])
			{
				par[s2] = s1;
				rank[s1] += rank[s2];
			}
			else
			{
				par[s1] = s2;
				rank[s2] += rank[s1];
			}
		}
	}
};

class graph
{
	int V;
	vector<vector<int>> l;

public:
	graph(int V)
	{
		this->V = V;
	}

	void add_edge(int w, int a, int b)		//weight edge edge
	{
		l.push_back({w, a, b});
	}

	void kruskal()
	{
		int cst = 0;
		DSU s(V);
		sort(l.begin(), l.end());
		for(auto edge : l)
		{
			int w = edge[0];
			int a = edge[1];
			int b = edge[2];
			
			int s1 = s.find(a);
			int s2 = s.find(b);
			if(s1 != s2)
			{
				cst += w;
				s.union_set(a, b);
			}
		}

		cout<<cst;
	}
};

int main()
{
/*
4 5
0 1 10
1 2 15
0 2 5
3 1 2
3 2 40
*/

	int n, m;
	cin >> n >> m;
	graph g(n);
	while(m--)
	{
		int a, b, w;
		cin >> a >> b >> w;
		g.add_edge(w, a, b);
	}
    g.kruskal();
	return 0;
}