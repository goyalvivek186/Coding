/*#include<iostream>

using namespace std;

int main()
{
	cout<<"Hello Vivek";
	return 0;
}
*/
#include<iostream>
using namespace std;


int main () {
	cout<<"Hello Coding Blocks!";
	return 0;
}