#include<iostream>
using namespace std;

bool staircase(int a[][100], int e, int m, int n)
{
	int i = 0, j = n-1;
	while(i >= 0 and i < m and j >= 0 and j < n)
	{
		if(a[i][j] == e)
		{
			return true;
		}
		else if (a[i][j] > e)
		{
			j--;
		}
		else if (a[i][j] < e)
		{
			i++;
		}
	}
	return false;
}



int main()
{
	int n, m, a[100][100], e, i, j;
	cin >> n >> m;
	for(i = 0; i < m; i++)
	{
		for(j = 0; j < n; j++)
		{
			cin >> a[i][j];
		}
	}
	cin >> e;

	if(staircase(a, e, m, n))
	{
		cout<<"1";
	}
	else
	{
		cout<<"0";
	}

	

	

	
	return 0;
}