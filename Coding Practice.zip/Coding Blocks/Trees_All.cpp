#include<iostream>
#include<queue>

using namespace std;

class node
{
public:
	int data;
	node *left;
	node *right;

	node(int d)
	{
		data = d;
		left = NULL;
		right = NULL;
	}

};

node* build()
{
	int x;
	cin >> x;
	if(x == -1)
	{
		return NULL;
	}
	node *root = new node(x);
	root->left = build();
	root->right = build();
	return root;
}

void preprint(node *root)
{
	if(root == NULL)
	{
		return;
	}
	cout<<root->data<<" ";
	preprint(root->left);
	preprint(root->right);
}

void postprint(node *root)
{
	if(root == NULL)
	{
		return;
	}
	preprint(root->left);
	preprint(root->right);
	cout<<root->data<<" ";
}

void inprint(node *root)
{
	if(root == NULL)
	{
		return;
	}
	preprint(root->left);
	cout<<root->data<<" ";
	preprint(root->right);
}

int height(node *root)
{
	if(root == NULL)
	{
		return 0;
	}
	int lh = height(root->left);
	int rh = height(root->right);
	return max(lh, rh) + 1;
}

void printknode(node *root, int k)
{
	if(root == NULL)
	{
		return;
	}

	if(k == 1)
	{
		cout<<root->data<<" ";
		return;
	}
	printknode(root->left, k-1);
	printknode(root->right, k-1);
}


//	order of n^2
void lineprint(node *root)
{
	if(root == NULL)
	{
		return;
	}
	int h = height(root);
	for(int i = 1; i <= h; i++)
	{
		printknode(root, i);
		cout<<endl;
	}
}

//	Order of n
void BFS(node *root)
{
	if(root == NULL)
	{
		return;
	}
	queue<node *> q;
	q.push(root);
	q.push(NULL);
	while(!q.empty())
	{
		node *t = q.front();
		
		if(t != NULL)
		{
			cout<<t->data<<", ";
			q.pop();
			if(t->left)
			{
				q.push(t->left);
			}
			if(t->right)
			{
				q.push(t->right);
			}
		}
		else
		{
			cout<<endl;
			q.pop();
            if(!q.empty())
			q.push(NULL);
		}
	}

}

//Total no of nodes

int count(node *root)
{
	if(root == NULL)
	{
		return 0;
	}
	int ll = count(root->left);
	int rl = count(root->right);

	return rl + ll + 1;
}

//Sum of all values of nodes
int sum(node *root)
{
	if(root == NULL)
	{
		return 0;
	}
	int x = root->data + sum(root->left) + sum(root->right);
	return x;
}

int diameter(node * root)
{
	if(root == NULL)
	{
		return 0;
	}
	int opt1 = height(root->left) + height(root->right);
	int opt2 = diameter(root->left);
	int opt3 = diameter(root->right);

	return max(opt1, max(opt2, opt3));
}

class dia
{
public:
	int h;
	int d;
};

dia diameter_fast(node *root)
{
	dia x;
	if(root == NULL)
	{
		x.h = 0;
		x.d = 0;
		return x;
	}
	dia l = diameter_fast(root-> left);
	dia r = diameter_fast(root-> right);
	x.h = max(l.h, r.h) + 1;
	x.d = max(l.h + r.h, max(l.d, r.d));	//diameter at a perticualr node = 
											//max (h1 + h2, d1, d2).
	return x;
}

	//Change the values of the nodes with the sum of its child,
	//DO not change the values of leaf nodes ans there are no
	//child so their sum will be 0 and the whole tree will change to 0
int replace_sum(node *root)
{
	if(root == NULL)
	{
		return 0;
	}

	if(root->left == NULL and root->right == NULL)	//For leaf nodes DO not  change the values
	{
		return root->data;
	}

	int x = root->data;
	int ls = replace_sum(root->left);
	int rs = replace_sum(root->right);
	root->data = ls + rs;
	return root->data + x;
}

node *build_balance_frm_arr(int *a, int s, int e)
{
	if(s>e)
	{
		return NULL;
	}
	int m = (s+e)/2;
	node *root = new node(a[m]);
	root->left = build_balance_frm_arr(a, 0, m-1);
	root->right = build_balance_frm_arr(a, m+1, e);
	return root;
}

		//Order if n^2
bool balance = true;
void isbalance(node *root)
{
	if(root == NULL)
	{
		return;
	}
	if(!balance)
	{
		return;
	}
	int lh = height(root->left);
	int rh = height(root->right);

	if(abs(lh - rh) > 1)
	{
		balance = false;
		return;
	}
	else
	{
		isbalance(root->left);
		isbalance(root->right);
	}
}

	// order of n
	//https://ide.codingblocks.com/s/22780
class bal
{
public:
	int h;
	bool b = true;
};

bal isbalance_fast(node *root)
{
	bal x;
	if(root == NULL)
	{
		x.h = 0;
		x.b = true;
		return x;
	}
	bal l = isbalance_fast(root->left);
	bal r = isbalance_fast(root->right);
	x.h = max(l.h, r.h) + 1;
	if(abs(l.h - r.h) > 1 or l.b == false or r.b == false)
	{
		x.b = false;
	}

	return x;
}

node *build_from_pre_in(int *pre, int *in, int s, int e)
{
	static int i = 0;
	if(s > e)
	{
		return NULL;
	}
	node *root = new node(pre[i]);
	int index;
	for(int x = s; x < e; x++)
	{
		if(in[x] == pre[i])
		{
			index = x;
			break;
		}
	}
	i++;
	root->left = build_from_pre_in(pre, in, s, index - 1);
	root->right = build_from_pre_in(pre, in, index + 1, e);

	return root;
}



void right(node *root, int level, int &max)
{
	if(root == NULL or level < max)
	{
		return ;
	}
	if(level > max)
	{
		cout<<root->data<<" ";
		max = level;
	}
	right(root->right, level + 1, max);
	right(root->left, level+1, max);
}


int main()
{
	//	Sample Input = 3 4 -1 6 -1 -1 5 1 -1 -1 -1
	//	Sample Input = 8 10 1 -1 -1 6 9 -1 -1 7 -1 -1 3 -1 14 13 -1 -1 -1
	//	Sample Input for balanced tree = 8 9 11 -1 -1 12 -1 -1 10 -1 -1
	
	/*int pre[] = {1, 2, 3, 4, 8, 5, 6, 7};
	int in[] = {3, 2, 8, 4, 1, 6, 7, 5};
	int n = sizeof pre/ sizeof(int);*/
	/*cout<<"Preorder = ";
	preprint(root);
	cout<<endl;
	cout<<"Inorder = ";
	inprint(root);
	cout<<endl;
	cout<<"Postorder = ";
	postprint(root);
    cout<<endl;
    lineprint(root);*/
    //BFS(root);
	/*if(balance)
    {
        cout<<"Balanced";
    }
    else
    {
        cout<<"Not Balanced";
    }*/

    /*bal ans = isbalance_fast(root);
    if(ans . b == true)
    {
    	cout<<"Balanced"<<endl;
    }
    else
    {
    	cout<<"Not Balanced"<<endl;
    }
    cout<<diameter(root)<<endl;
    dia x = diameter_fast(root);
    cout<<x.d;
	*/
	//node *root = build_from_pre_in(pre, in, 0, n-1);
	node *root = build();
	BFS(root);
	cout<<endl;
	int max = -1;
	right(root, 0, max);


	return 0;
}