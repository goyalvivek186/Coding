#include <iostream>
using namespace std;

class queue
{
    int s = 10;
    int f = -1, r = 0;
    int a[10];
    public:

        /*queue(int s)
        {
            size = s;
            a = new int[s];
        }*/

        void push(int d)
        {
            a[r] = d;
            r++;
        }

        void pop()
        {
            f++;
        }

        bool empty()
        {
            if(f+1 == r)
            {
                return true;
            }
            return false;
        }

        int front()
        {
            return a[f+1];
        }

        bool full()
        {
            return(r == s);
            
        }

        int size()
        {
            return(r-f-1);
        }

};
int main()
{
    queue q;
    int n;
    cout<<q.size()<<endl;
    cin >> n;
    while(n--)
    {
        int a;
        cin >> a;
        q.push(a);
    }
    while(!q.empty())
    {
        cout<<q.size()<<" "<<q.front()<<endl;
        q.pop();
    }
    return 0;
}
