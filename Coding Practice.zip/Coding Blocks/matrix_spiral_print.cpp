#include<iostream>


//   anticlock-wise
using namespace std;

void spiral(int a[][10], int m, int n)
{
	int rowstr = 0, rowend = m-1;
	int colstr = 0, colend = n-1;
	int i, j;
	while(rowstr <= rowend and colstr <= colend)
	{
		for(i = rowstr; i <= rowend; i++)
		{
			cout<<a[i][colstr]<<", ";
		}
		colstr++;

		for(i = colstr; i <= colend; i++)
		{
			cout<<a[rowend][i]<<", ";
		}
		rowend--;

		for(i = rowend; i >= rowstr; i--)
		{
			if(rowstr <= rowend and colstr <= colend)
			{
				cout<<a[i][colend]<<", ";
			}
		}
		colend--;

		for(i = colend; i >= colstr; i--)
		{
			if(rowstr <= rowend and colstr <= colend)
			{
				cout<<a[rowstr][i]<<", ";
			}
		}
		rowstr++;
		

	}
	cout<<"END";




}


int main()
{
	int a[10][10];
	int m, n;
	//cout<<"Enter the rows and columns\n";
	cin>>m>>n;
	//cout<<"Enter the values\n";
	for(int i= 0; i < m; i ++)
	{
		for(int j = 0; j < n; j++)
		{
			cin >> a[i][j];
		}
	}
	/*cout<<"Entered elements are =\n";

	for(int i= 0; i < m; i ++)
	{
		for(int j = 0; j < n; j++)
		{
			cout<< a[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<endl<<"Spiral print=\n";
	*/
	spiral(a, m, n);


	return 0;
}