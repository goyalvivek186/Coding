#include<iostream>
#include<stack>

using namespace std;

void placex(stack<int> &s, int x)
{
	if(s.empty() or s.top() <= x)
	{
		s.push(x);
        return;
	}
	int y = s.top();
	s.pop();
	placex(s, x);
	s.push(y);
}


void sort(stack<int> &s)
{
	if(s.empty())
	{
		return;
	}
	int x;
	x = s.top();
    s.pop();
	sort(s);
	placex(s, x);
}

int main()
{
	stack<int> s;
	int n;
	cin >> n;
	while(n--)
	{
		int a;
		cin >>a;
		s.push(a);
	}

	sort(s);

    while(!s.empty())
    {
        cout<<s.top()<<endl;
        s.pop();
    }

	return 0;
}