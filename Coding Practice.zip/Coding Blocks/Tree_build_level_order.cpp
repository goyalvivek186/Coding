#include<iostream>
#include<queue>
using namespace std;

class node
{
public:
	int data;
	node *right;
	node *left;

	node(int d)
	{
		data = d;
		left = NULL;
		right = NULL;
	}
};

node *build()
{
	int d;
	cin >> d;
	node *root;
	if(d != -1)
	{
		root = new node(d);
	}
	queue<node *> q;
	q.push(root);
	node *f;
	while(!q.empty())
	{
		f = q.front();
		q.pop();
		int d1, d2;
		cin >> d1 >> d2;
		if(d1 != -1)
		{
			f->left = new node(d1);
			q.push(f->left);
		}

		if(d2 != -1)
		{
			f->right = new node(d2);
			q.push(f->right);
		}
	}
	return root;
}
int main()
{
	node *root = build();
	return 0;
}