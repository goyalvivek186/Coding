#include<iostream>
#include<string.h>
using namespace std;


int main()
{
	char ch[1000];
	cin >> ch;
	cout<<ch[0];
	for(int i = 1; i < strlen(ch); i++)
	{
		if(ch[i] >= 'A' and ch[i] <='Z')
		{
			cout<<endl<<ch[i];
		}
		else
		{
			cout<<ch[i];
		}
	}
	


	
	return 0;
}