#include<iostream>
#include<vector>

#define ll long long
//#define n 1000000
using namespace std;

void build_sieve(int *prime, int n)
{
	for(ll i = 3; i < n; i++)
	{
		if(i % 2 == 0)	prime[i] = 0;
		else	prime[i] = 1;
	}

	for(ll i = 3; i < n; i++)
	{
		if(prime[i] == 1)
		{
			for(ll j = i*i; j < n; j += i)
			{
				prime[j] = 0;
			}
		}
	}
}

vector<pair<int, int>> factor(int n, int *prime)
{
	vector<pair<int, int>> f;
	f.clear();
	for(int i = 2; i*i <= n; i++)
	{   if(n == 0)  break;
		int cnt = 0;
		if(prime[i] == 1 and n%i == 0)
		{
			while(n%i == 0)
			{
				n /= i;
				cnt ++;
			}
			f.push_back(make_pair(i, cnt));
		}
	}
	if(n != 1)	f.push_back(make_pair(n, 1));
	return f;
}

int count_divisors(int n, int *prime)
{
    vector<pair<int, int>> f = factor(n, prime);
    int ans = 1;
    for(auto i : f)
    {
        ans *= (i.second + 1);
    }
    return ans;
}


int main()
{
	int prime[1000000] = {0};
	prime[0] = prime[1] = -1;
	prime[2] = 1;
	build_sieve(prime, 1000000);
   /* for(int i = 0; i < 25; i++)
    {
        cout<<i<<" "<<prime[i]<<endl;
    }
*/
	int n;
	cin >> n;
	/*vector<pair<int, int>> ans = factor(n, prime);
	for(auto i : ans)
	{
		cout<<i.first<<" "<<i.second<<endl;
	}*/
    cout<<count_divisors(n, prime);

	return 0;
}