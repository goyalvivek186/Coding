#include<iostream>
using namespace std;


int main()
{
	int t, n, c=0, i, j = 3;
	cin>>t;
	for(int k = 0; k < n; k++)
	{
		cin>>n;
	while (c < n)
	{
		for(i = 2; i < j; i++)
		{
			if(j % i ==0)
			{
				break;
			}
		}
		if(i == j)
		{
			c++;
		}
		if(c == n)
		{
			cout<<j;
		}

			j++;
	}}
	return 0;
}