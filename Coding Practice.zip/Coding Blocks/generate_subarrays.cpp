#include<iostream>
using namespace std;

void sub_arrays(int s, int a[])
{
	int i, j, k;
	cout<<"Sub-arrays =\n";
	for(i = 0; i < s; i++)
	{
		for(j = i; j  < s; j++)
		{
			for(k = i; k <= j; k++)
			{
				cout<<a[k]<<" ";
			}
			cout<<"\n";
		}
	}
}


int main()
{
	int s, a[20], i;
	cout<<"Enter the size of the array\n";
	cin >> s;

	cout<<"Enter teh elements\n";
	for(i = 0; i < s; i++)
	{
		cin >> a[i];
	}
	cout<<endl;
	sub_arrays(s, a);



	return 0;
}