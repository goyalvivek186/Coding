#include<iostream>
#include<string>
#include<algorithm>

using namespace std;
 
bool coupon(long long int n,long long int m,long long int x,long long int y,long long int mid)
{
	long long int t = (n - mid) * y;
	if((mid * x) <= m + t)
	{
		return true;
	}
	else
	{
		return false;
	}

}


int main()
{
	long long int n, m, x, y;
	cin >> n >> m >> x >> y;

	long long int s = 0, e = n;
	long long int mid, ans;

	while(s <= e)
	{
		mid = (s+e)/ 2;
		if(coupon(n, m, x, y, mid))
		{
			ans = mid;
			s = mid + 1;
		}
		else
		{
			e = mid - 1;
		}
	}
	cout<< ans;
	return 0;
}