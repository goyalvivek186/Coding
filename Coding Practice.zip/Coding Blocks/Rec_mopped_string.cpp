#include<iostream>

using namespace std;

void mopped(char *a, char *s, int i, int j)
{
	if(a[i] == '\0')
	{
		s[j] = '\0';
		cout<<s<<endl;
		return;
	}
    int y = a[i] - '0';
	char x = y +'A' - 1;
	s[j] = x;
	mopped(a, s, i+1, j+1);

    if(a[i+1] != '\0')
	{int dig = (a[i] - '0') * 10;
	dig += a[i+1] - '0';
	if(dig <= 26)
	{
	s[j] = dig + 'A' - 1;
	mopped(a, s, i+2, j+1);
    }
	}
    return; 
}

int main()
{
	char a[1000];
	cin >> a;
	char s[100];
	mopped(a, s, 0, 0);


	return 0;
}