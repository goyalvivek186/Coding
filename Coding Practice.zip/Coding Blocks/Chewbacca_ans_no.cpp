#include<iostream>
using namespace std;



int main()
{
	char ch[100];
	cin >> ch;
	for(int i = 0; ch [i] != '\0'; i++)
	{
		if(i == 0 and ch[i] == '9')
		{
			continue;
		}
		else if(ch[i] >='5')
		{
			ch[i] =(9 - (ch[i] - '0')) + '0';
		
		}
	}
	cout<<ch;

	


	
	return 0;
}