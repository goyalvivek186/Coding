#include <iostream>
#include <map>
#include <list>
#include <climits>
#include <queue>

using namespace std;
template<typename T>
class graph
{
    public:
        map<T, list<T>> g;

        void add_edge(T a, T b, bool bi)
        {
            g[a].push_back(b);
            if(bi)
            {
                g[b].push_back(a);
            }
        }

        void SSSP(T source, T goal)
        {
            map<T, int> dist;
            map<T, T> path;
            for(auto l : g)
            {
                dist[l.first] = INT_MAX;
            }
            path[source] = source;
            dist[source] = 0;
            queue<T> q;
            q.push(source);
            while(!q.empty())
            {
                T f = q.front();
                q.pop();
                for(auto l : g[f])
                {
                    if(dist[l] == INT_MAX)
                    {
                        dist[l] = dist[f] + 1;
                        path[l] = f;
                        q.push(l);
                    }
                }
            }

            for(auto l : dist)
            {
                cout<<l.first<<" "<<l.second<<endl;
            }

            T temp = goal;
            do
            {
                cout<<temp<<" <- ";
                temp = path[goal];
                goal = temp;
            }while(temp != source);
            cout<<source;
        }
        
};

int main() 
{
    graph<int> g;
    g.add_edge(0, 1, true);
	g.add_edge(0, 3, true);
	g.add_edge(1, 2, true);
    g.add_edge(2, 3, true);
    g.add_edge(3, 4, true);
    g.add_edge(4, 5, true);

    g.SSSP(0, 5);

    return 0;
}
