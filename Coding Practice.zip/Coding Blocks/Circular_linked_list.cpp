#include<iostream>

using namespace std;

class node
{
public:
	int data;
	node *next;
	node(int d)
	{
		data = d;
		next = NULL;
	}
};

void insertathead(node *&head, int d)
{
	if(head == NULL)
	{
		head = new node(d);
		head->next = head;
		return;
	}
	else
	{
		node *n = new node(d);
		n->next = head;
		node * t = head;
		while(t->next != head)
		{
			t = t->next;
		}
		t->next = n;
		head = n;
	}
}

void print(node *head)
{
	node *t = head;
	while(t->next != head)
	{
		cout<<t->data<<"-> ";
		t = t->next;
	}
	cout<<t->data;
	cout<<endl;
}

void del(node *&head, int d)
{
	if(head->data == d)
	{
		node *t = head;
		while(t->next != head)
		{
			t = t->next;
		}
		t->next = head->next;
		head = head->next;
		return;
	}

	node *t = head;
	while(t->next->data != d and t->next != head)
	{
		t = t->next;
	}
	t->next = t->next->next;
	return;
}

int main()
{
	node *head = NULL;

	int n;
	cin >> n;
	while(n--)
	{
		int a;
		cin >> a;
		insertathead(head, a);
	}
	print(head);
	int d;
	cin >> d;
	del(head, d);
	print(head);


	return 0;
}