#include<iostream>

using namespace std;

class node
{
public:
	int data;
	node *next;

	node(int d)
	{
		data = d;
		next = NULL;
	}
};

void push(node *&head, int d)
{
	if(head == NULL)
	{
		head = new node(d);
		return;
	}
	node *t = new node(d);
	node *n = head;
	while(n->next != NULL)
	{
		n = n->next;
	}
	n->next = t;
	
}

void pop(node *& head)
{
	if(head == NULL)
	{
		cout<<"Under Flow";
		return;
	}

    node *n = head;

 // if only 1 element is there

    if (n->next == NULL) {
        n = NULL;
        return;
    }

	while(n->next->next != NULL)
	{
		n = n->next;
	}
	n->next = NULL;

}

int size(node *head)
{
	int c = 0;
	while(head != NULL)
	{
		head = head->next;
		c++;
	}
	return c;
}

bool empty(node *head)
{
	return head == NULL;
}

int top(node *head)
{
	return head->data;
}

int main()
{
	node *q = NULL;

	int n;
	cin >> n;
	while(n--)
	{
		int a;
		cin >> a;
		push(q, a);

	}
	cout<<size(q)<<endl;
	cout<<top(q)<<endl;
	pop(q);
	//pop(q);
    cout<<size(q)<<endl;
	/*while(empty(q))
	{
		cout<<top(q)<<endl;
		pop(q);
	}*/
    pop(q);
    pop(q);
    pop(q);
    if(empty(q))
    {
        cout<<"Y"<<endl;
    }
    else
    {
        cout<<"N"<<endl;
    }



	return 0;
}