#include<iostream>
#include<string>
using namespace std;

template<typename T>
class node
{
public:
	string key;
	T value;
	node<T> *next;
	node(string key, T val)
	{
		this->key = key;
		value = val;
		next = NULL;
	}

	~node()
	{
		if(next != NULL)
		{
			delete next;
		}
	}
};

template<typename T>
class hashtable
{

	node<T> **table;
	int cs;
	int ts;
	int hashfun(string key)
	{
		int index = 0, p = 1;
		for(int i = 0; i < key.length(); i++)
		{
			index += (key[i]*p)%ts;
			index %= ts;
			p *= 27;
		}
		return index;
	}

	void rehashing()
	{
		node<T>** old_table = table;
		int old_size = ts;
		ts = ts*2 + 1;
		table = new node<T>*[ts];
		cs = 0;
		for(int i = 0; i < ts; i++)
		{
			table[i] = NULL;
		}

		for(int i = 0; i < old_size; i++)
		{
			node<T> *temp = old_table[i];
			while(temp != NULL)
			{
				insert(temp->key, temp->value);
				temp = temp->next;
			}
			delete old_table[i];		//Recursion, delete calls destructor
		}
		delete [] old_table;
	}

public:
	hashtable(int size = 7)
	{
		ts = size;
		cs = 0;
		table = new node<T>*[ts];
		for(int i = 0; i < ts; i++)
		{
			table[i] = NULL;
		}
	}

	void insert(string key, T val)
	{
		int index = hashfun(key);
			//Make a new LL to place on the head of separate chain
		node<T>*n = new node<T>(key, val);

			//Place the new LL(n) on the head
		n->next = table[index];
		table[index] = n;
		cs++;

		float load_factor = cs/(1.0 + ts);
		if(load_factor > 0.75)
		{
			rehashing();
		}
	}

	//In searching function, Return type = T* so that if the item is not found, we can retur NULL;

	T* search(string k)
	{
		int index = hashfun(k);
		node<T>* temp = table[index];
		while(temp != NULL)
		{
			if(temp->key == k)
			{
				return &temp->value;
			}
			temp = temp->next;
		}
		return NULL;
	}

	void print()
	{
		for(int i = 0; i < ts; i++)
		{
			node<T>* temp = table[i];
			cout<<"Index no "<<i<<"-> ";
			while(temp != NULL)
			{
				cout<<temp->key<<"("<<temp->value<<")  ->";
				temp = temp->next;
			}
			cout<<endl;
		}
	}

	void del(string k)
	{	int index = hashfun(k);
		node<T> *temp = table[index];
		//Present at first (head)
		if(temp->key == k)
		{
			table[index] = temp->next;
			return;
		}

		else
		{
			while(temp->next->key != k and temp != NULL)
			{
				temp = temp->next;
			}
			temp->next = temp->next->next;
		}	
	}
};