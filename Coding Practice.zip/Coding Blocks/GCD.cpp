#include<iostream>
#define ll long long

using namespace std;

int gcd(int a, int b)
{
	if(b == 0)
	{
		return a;
	}
	else
	{
		return gcd(b, a%b);
	}
}

int main()
{
	ll a, b, e;
	cin >> a >> b;
					//Not req ans it covers itself in 2nd step
	/*if(a < b)
	{
		swap(a, b);
	}*/
	cout<<gcd(a, b);

	
	return 0;
}