#include<iostream>
#include<string>
#include<algorithm>
#include<climits>

using namespace std;

bool compare(pair<string, int>p1, pair<string, int>p2)
{
	if(p1.second == p2.second)
	{
		return p1.first < p2.first;
	}
	return p1.second > p2.second;
}


int main() 
{
	int n, x;
    cin >> x;
	cin >> n;
    pair<string, int>p[n];
    for(int i = 0; i < n; i++)
    {
        int a;
        string s;
        cin >> s >> a;
        p[i].first = s;
        p[i].second = a;
    }

    sort(p, p+n, compare);

    for(int i = 0; i < n ; i++)
    {
        if(p[i].second >= x)
        cout<<p[i].first <<" " << p[i]. second <<endl;
    }
    return 0;    
}
