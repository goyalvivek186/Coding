#include<iostream>
#include<algorithm>

using namespace std;



int main()
{
	int mon[]={1, 2, 5, 10, 20, 50, 100, 500, 2000};
	int n = sizeof(mon)/ sizeof(int);
	int money, ub;
	cin >> money;
	while(money != 0)
	{
		ub = upper_bound(mon,mon + n, money) - mon - 1;
		cout<<mon[ub]<<" ";
		money -= mon[ub];

	}

	
	return 0;
}