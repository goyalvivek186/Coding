#include<iostream>
using namespace std;

void wave(int a[][5], int m, int n)
{
	int i, j, col = 0;

	for(i = 0; i < m; i++)
	{
		if(col % 2 == 0)
		{
			for(j = 0; j < n; j++)
			{
				cout<<a[j][i]<<" ";
			}
		}
		else
		{
			for(j = n-1; j >= 0; j--)
			{
				cout<<a[j][i]<<", ";
			}
		}
		col++;

	}
	cout<<"END";
}


int main()
{
	int a[5][5];
	int m, n;
	//cout<<"Enter the rows and columns\n";
	cin>>m>>n;
	//cout<<"Enter the values\n";
	for(int i= 0; i < m; i ++)
	{
		for(int j = 0; j < n; j++)
		{
			cin >> a[i][j];
		}
	}
	/*cout<<"Entered elements are =\n";

	for(int i= 0; i < m; i ++)
	{
		for(int j = 0; j < n; j++)
		{
			cout<< a[i][j]<<" ";
		}
		cout<<endl;
	}

	cout<<endl<<"Wave print =\n";*/
	wave(a, m, n);


	return 0;
}