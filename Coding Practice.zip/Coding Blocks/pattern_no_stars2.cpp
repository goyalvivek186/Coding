#include<iostream>
using namespace std;


int main()
{
	int i, j, n, t = 0, k;
	cin>>n;

	for(i = n; i > 0; i--)
	{
		for(j = 1; j <= i; j++)
		{
			cout<<j<<" ";
		}
		for(k = 1; k < t; k++)
		{
			cout<<"* ";
		}
		t = t + 2;
		cout<<endl;
	}



	return 0;
}