#include<iostream>
#include<string>
#include<algorithm>
#include<climits>

using namespace std;

long long fact(int a)
{
	long long sum = 0;
	for(int i = 1; i <= a; i++)
	{
		sum += i;
	}
	return sum;
}

void next(int a[], int n)
{
	long long m = INT_MIN, no = 0;
	long long x = fact(n);
	for(long long i = 0; i < x; i++)
	{
		no = 0;
		for(int j = 0; j < n; j++)
	{
		no = (no * 10) + a[j];
	}
		next_permutation(a, a+n);
		m = max(m, no);

	}
	cout<<m<<endl;
}

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n;
		cin >> n;
		int a[n];
		for(int i = 0; i < n; i++)
		{
			cin >>a[i];
		}
		next(a, n);
	}
	
	return 0;
}