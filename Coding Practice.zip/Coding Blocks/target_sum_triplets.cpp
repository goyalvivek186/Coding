#include<iostream>
#include<algorithm>
using namespace std;

void target(int a[1000], int s, int t)
{
	int i = 0, l = 1, r = s-1, n;
	for(i = 0; i < s; i++)
 {
 	l = i + 1;
 	n = a[i];
 	r = s - 1;


	while(l < r) 
	{
		if((n + a[l] + a[r]) == t)
		{
			cout<<n<<", "<<a[l]<<" and "<<a[r]<<endl;
			l++;
		}
		else if((n + a[l] + a[r]) < t)
		{
			l++;
		}
		else 
		{
			r--;
		}
		
	}
 }
}



int main()
{
	int a[1000], s, t;
	cin >> s;
	for(int i = 0; i < s; i++)
	{
		cin >> a[i];
	}
	cin >> t;
	sort(a, a+s);
	target(a, s, t);

	

	
	return 0;
}