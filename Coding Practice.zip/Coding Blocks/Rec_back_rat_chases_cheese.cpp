#include<iostream>
using namespace std;

void print(int a[][10], int x, int y)
{
	for(int i = 0; i < x; i++)
	{
		for(int j = 0; j < y; j++)
		{
			cout<<a[i][j]<<" ";
		}
		cout<<endl;
	}
}

bool solve(char ch[][10], int sol[][10], int x, int y, int m, int n)
{
	bool ans = false;
	if(x == m and y == n)
	{
        sol[x][y] = 1;
		print(sol, x, y);
		return true;
	}

	if(ch[x][y] == 'X')
	{
		return false;
	}

	if(x > m or y > n)
	{
		return false;
	}

	if(x < 0 or y < 0)
	{
		return false;
	}

	sol[x][y] = 1;
	bool right = solve(ch, sol, x, y + 1, m, n);
	ans = right;
    if(!right)
	{
		bool left = solve(ch, sol, x, y - 1, m, n);
		ans = left;
		if(!right and !left)
		{
			bool top = solve(ch, sol, x - 1, y, m, n);
			ans = top;
    		if(!right and !left and !top)
			{
				bool bottom = solve(ch, sol, x + 1, y, m, n);
				ans = bottom;
			}
    	}
	   	
		sol[x][y] = 0;
    }

	return ans;
}

int main()
{
	int m, n, sol[10][10] = {0};
	char maze[10][10];
	cin >> m >> n;
	for(int i = 0; i < m; i++)
	{
		for(int j = 0; j < n; j++)
		{
			cin >> maze[i][j];
		}
	}

	if(!solve(maze, sol, 0, 0, m-1, n-1))
    {
        cout<<"-1";
    }
	return 0;
}