#include<iostream>
using namespace std;

class node
{
public:
	int data;
	node *right;
	node *left;

	node(int d)
	{
		data = d;
		right = NULL;
		left = NULL;
	}
};

node *tree_from_arrays(int *pre, int *in, int s, int n)
{
	static int index = 0;
	if(s > n)
	{
		return NULL;
	}
	int p;
	for(int i = s; i <= n; i++)
	{
		if(pre[index] == in[i])
		{
			p = i;
			break;
		}
	}
	node *root = new node(pre[index]);
	++index;
	root->left = tree_from_arrays(pre, in, s, p-1);
	root->right = tree_from_arrays(pre, in, p+1, n);
	return root;
}

void print(node *root)
{
	if(root == NULL)
	{
		return ;
	}
	if(root->left)
	{
		cout<<root->left->data<<" => ";
	}
	else
	{
		cout<<"END => ";
	}
	cout<<root->data;
	if(root->right)
	{
		cout<<" <= " << root->right->data<<endl;
	}
	else
	{
		cout<<" <= END";
	}
	cout<<endl;
	print(root->left);
	print(root->right);
}

int main()
{
	int m;
	cin >> m;
	int pre[m];
	for(int i = 0; i < m; i++)
	{
		cin >> pre[i];
	}

	int n;
	cin >> n;
	int in[n];
	for(int i = 0; i < n; i++)
	{
		cin >> in[i];
	}

	node *root = tree_from_arrays(pre, in, 0, n-1);
	print(root);
	return 0;
}