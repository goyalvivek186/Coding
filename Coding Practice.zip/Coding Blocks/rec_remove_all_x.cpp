#include<iostream>
#include<cstring>

using namespace std;

void Xatend(char ch[], int n, int x)
{
	if(ch[n] == '\0' or n == x)
	{
		return;
	}
	if(ch[n] == 'x')
	{
		int i = n;
		while(ch[i] != '\0')
		{
			ch[i] = ch[i + 1];
			i++;
		}
		ch[i - 1] = 'x';
        Xatend(ch, n+1, x - 1);
	}
	Xatend(ch, n+1, x);
}

int main()
{
	char ch[1001];
	cin >> ch;
    int x = strlen(ch);
    while(ch[x] == 'x')
    {
        x--;
    }
	Xatend(ch, 0, x);
    cout<<ch;

	return 0;
}