#include <iostream>
#include <string>
#include <algorithm>
#include <climits>
#include <math.h>

using namespace std;

void prime(long long n, int x)
{
  /*
	-1 = Neither prime nor composite
	 0 = composite
	 1 = prime
	*/

  int a[n] = {0};
  a[0] = a[1] = -1;
  a[2] = 1;
  for (long long i = 3; i < n; i += 2)
  {
    a[i] = 1;
  }
  for (long long i = 3; i < n; i += 2)
  {
    if (a[i] == 1)
    {
      for (long long j = i * i; j < n; j += i)
      {
        a[j] = 0;
      }
    }
  }

  int c = 0;
  for (long long i = 2; i < n and c != x; i++)
  {
    if (a[i] == 1)
      c++;
    if (c == x)
    {
      cout << i;
      return ;
    }
  }
}

int main()
{
  long long n = 900000;
  int x;
  cin >> x;
  prime(n, x);
  return 0;
}