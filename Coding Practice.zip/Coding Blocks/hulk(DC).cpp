#include<iostream>
#include<string>
#include<algorithm>
#include<climits>
#include<math.h>

using namespace std;

bool  hulk(long long a, long long m)
{
	if(pow(2, m) < a)
	{
		return true;
	}
	return false;
}

int main()
{
	int t;
	cin >> t;
	
	while(t--)
	{
		long long a, m, e, ans;
		cin >> a;
		int s = 0, steps = 0;
		e = a;

		while(s <= e)
		{
			m = (s+e) / 2;
            if(pow(2, m) == a)
            {
                steps ++;
                ans += steps;
                break;
                
            }
			if(hulk(a, m))
			{
				ans = m;
				s = m+1;
			}
			else
			{
				e = m - 1;
			}
            steps ++;
            int ans2;
            
            if(a - pow(2,ans) > 1)
            s = 0, e = a - pow(2,ans);
         {   while(s <= e)
            {
                m = (s+e) / 2;
                if(hulk(ans, m))
                {
                    ans2 = m;
                    s = m+1;
                }
                else{
                    e = m-1;
                }
            }
            steps ++;
         }


		}
		//cout<<( (a - pow(2, ans)) + 1) << endl;
        cout<<steps<<endl;

	}

		
	return 0;
}