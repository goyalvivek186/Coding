#include<iostream>
using namespace std;

int last(int *a, int n, int t)
{
	if(n == 0)
	{
	return -1;
	}
	int i = last(a+1, n-1, t);
    if(i == -1)
    {
	if(a[0] == t)
	return 0;
    else
	return -1;
    }
	
	return i+1;
}

int main()
{
	int n;
	cin >> n;
	int a[n];
	for(int i = 0; i < n; i++)
	{
	cin >> a[i];
	}
	int t;
	cin >> t;
	cout<<last(a, n, t);




	return 0;
}