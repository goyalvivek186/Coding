//Pigeon Hole Princile

#include<iostream>

using namespace std;

/*int fact(int a)
{
	if(a == 0 or a == 1)
	{
		return 1;
	}
	return a*fact(a-1);
}*/
int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n, x, sum = 0;
		cin >> n;
		int a[n + 1] = {0};
		a[0]++;
		for(int i = 0; i < n; i++)
		{
			cin >> x;
			sum += x;
			sum %= n;
			sum = (sum + n) % n;
			a[sum]++;
		}
		int ans = 0;
		for(int i = 0; i < n; i++)
		{
			if(a[i] > 1)
			{
				ans += (a[i] * (a[i]-1))/2;
		}	}
		cout<<ans;
	}

	return 0;
}