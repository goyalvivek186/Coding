#include<iostream>

using namespace std;

pair<bool, int> check(char a[][101], int m, int n, int k, int s)
{
	pair<bool, int> ans = {false, 0};
	if(s < k)	return ans;

	for(int i = 0; i < m; i++)
	{
		for(int j = 0; j < n; j++)
		{
			if(j != 0)	s--;
			if(s < k)	return ans;

			if(a[i][j] == '.')
			{
				s -= 2;
				if(s < k)	return ans;
			}

			if(a[i][j] == '*')
			{
				s += 5;
			}

			if(a[i][j] == '#')	break;
		}
	}

	ans = {true, s};
	return ans;
}

int main()
{
	int m, n, k, s;
	cin >> m >> n >> k >> s;
	char a[101][101];
	for(int i = 0; i < m; i++)
	{
		for(int j = 0; j < n; j++)
		{
			cin >> a[i][j];
		}
	}
	pair<bool, int> ans = check(a, m, n, k, s);

	if(ans.first)
	{
		cout<<"Yes"<<endl;
		cout<<ans.second;
	}
	else
	{
		cout<<"No";
	}
	return 0;
}