#include<iostream>
using namespace std;

int main()
{
	int n;
	cin >> n;
	int m = (n/2)+1;
	for(int i = 1; i <= n; i++)
	{
		if(i < m)
		{
			for(int j = 1; j <= n; j++)
			{
				if(j == 1 or j == m)	cout<<"*";
				else if(i == 1 and j > m)	cout<<"*";
				else	cout<<" ";
			}
			cout<<endl;
		}
		if(i == m)
		{
			for(int j = 0; j < n; j++)
			{
				cout<<"*";
			}
			cout<<endl;
		}
		if(i > m)
		{
			for(int j = 1; j <= n; j++)
			{
				if(i == n and j <= m)
				{
					cout<<"*";
				}
				else if(j == m or j == n)
				{
					cout<<"*";
				}
				else
				{
					cout<<" ";
				}
			}
			cout<<endl;
		}
	}

	return 0;
}