#include<iostream>
//#include<string.h>
using namespace std;

int main()
{
	int i, j, k, n;
	cin>>n;
	int t = 1, x = n/2;

	for( i = 0; i < ((n+1)/2); i++)
	{
		if(i == 0)
		{
			for(j = 0; j < n; j++)
			{
				cout<<"*\t";
			}
		}
		else
		{
			for(j = x; j > 0; j--)
			{
				cout<<"*\t";
			}
			for(j = 0; j < t; j++)
			{
				cout<<"\t";
			}
			for(j = x; j > 0; j--)
			{
				cout<<"*\t";
			}
			t = t +2;
			x --;


		}
		
		cout<<"\n";
	}

	x = 2;
	t = n - 4;

	for( i = 0; i < (n/2); i++)
	{
		if(i == (n/2)-1)
		{
			for(j = 0; j < n; j++)
			{
				cout<<"*\t";
			}
			break;
		}
		else
		{
			for(j = x; j > 0; j--)
			{
				cout<<"*\t";
			}
			for(j = 0; j < t; j++)
			{
				cout<<"\t";
			}
			for(j = x; j > 0; j--)
			{
				cout<<"*\t";
			}
			t = t -2;
			x ++;
		}
		cout<<"\n";
	}
	return 0;
}