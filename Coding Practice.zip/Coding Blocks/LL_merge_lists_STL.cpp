// merge2SortedList.cpp
#include<iostream>
#include<list>
using namespace std;

list<int> MergeLists(list<int>&l1, list<int>&l2) {

	list<int>finalList;

	while ((!l1.empty()) && (!l2.empty())) {
		if (l1.front() < l2.front()) {
			finalList.push_back(l1.front());
			l1.pop_front();
		} else {
			finalList.push_back(l2.front());
			l2.pop_front();
		}
	}

	while (!l1.empty()) {
		finalList.push_back(l1.front());
		l1.pop_front();
	}

	while (!l2.empty()) {
		finalList.push_back(l2.front());
		l2.pop_front();
	}
	return finalList;
}

int main() {

	int t; cin >> t;
	while (t--) {
		int n; cin >> n;
		int x;
		list<int>list1, list2;
		for (int i = 0; i < n; i++) {
			cin >> x;
			list1.push_back(x);
		}
		cin >> n;
		for (int i = 0; i < n; i++) {
			cin >> x;
			list2.push_back(x);
		}

		list<int>finalList = MergeLists(list1, list2);
		for (auto it : finalList) {
			cout << it << " ";
		}
		cout << endl;
	}

	return 0;
}