#include<iostream>
using namespace std;


int main()
{
	int i, j, n, x, k;
	cin >> n;
	x = (n + 1) / 2;
	for(i = 1; i < x; i++)
	{
		for(j = 1; j <= n; j++)
		{
			if(i == 1 && j == 1)
			{
				cout<<"*";
				for(k = 2;k < x; k++)
				{
					cout<<" ";
				}
				for(k = x; k <= n; k++)
				{
					cout<<"*";
				}
				break;
			}
			else
			{
				if(j == 1 ||j == x)
				{
					cout<<"*";
				}
				else
				{
					cout<<" ";
				}
			}
		}
		cout<<"\n";
	}

	if(i == x)
	{
		for(i = 0; i < n; i++)
		{
			cout<<"*";
		}
		cout<<"\n";
	}
	for(i = x + 1; i <= n; i++)
	{
		for(j = 1; j <= n; j++)
		{
			if((i == n) && (j == 1))
			{
				for(k = 0; k < x; k++)
				{
					cout<<"*";
				}
				for(k = x + 1; k < n; k++)
				{
					cout<<" ";
				}
				cout<<"*";
				break;
			}
			else if(j == x || j == n)
			{
				cout<<"*";
			}
			else
			{
				cout<<" ";
			}
		}cout<<"\n";
	}
	return 0;
}