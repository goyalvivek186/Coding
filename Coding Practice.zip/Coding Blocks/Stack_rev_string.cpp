#include <iostream>
#include <stack>
#include <string>
using namespace std;
int main()
{
    string ch;
    getline(cin, ch);
  //  cout<<ch<<endl;
   // return 0;
    stack<char> s;
    for(char x : ch)
    {
        s.push(x);
    } 
    stack<char> s2;
    while(!s.empty())
    {
      while(!s.empty())
        {
            if(s.top() == ' ')  break;
            s2.push(s.top());
            s.pop();
        }
        while(!s2.empty())
        {
            cout<<s2.top();
            s2.pop();
        }
        if(!s.empty())
        s.pop();
        cout<<" ";
        /*cout<<s.top()<<endl;
        s.pop();*/
    }
}
