#include<iostream>
#include<string>
#include<algorithm>
#include<climits>

using namespace std;

bool paint(long long int a[],long long int n,long long int m,long long int k)
{
	long long int painter = 1;
	long long int time = 0;
	for(int i = 0; i < n; i++)
	{
		if(time + a[i] > m)
		{
			time = a[i];
			painter++;
			if(painter > k)
			{
				return false;
			}
		}
		else
		{
			time += a[i];
		}
	}
	return true;
}

int main()
{
	long long int k, n, t;
	cin >> n >> k >> t;
	long long int a[n], e = 0, s = INT_MIN;
	for(int i = 0; i < n; i++){
		cin >> a[i];
		e += a[i];
        s = max(s, a[i]);
	}

	// sort(a, a+n);
	long long int ans;

    if(k >= n){
        cout<<(s*t)%10000003<<endl;
        return 0;
    }

	while(s <= e)
	{
		long long int m = (s+e)/2;
		if(paint(a, n, m, k)){
			ans = m;
			e = m - 1;
		}
		else{
            s = m + 1;
		}
	}
	cout<<(ans*t)%10000003;
	


	return 0;
}