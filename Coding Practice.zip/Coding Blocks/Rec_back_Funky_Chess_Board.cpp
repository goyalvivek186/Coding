#include<iostream>
using namespace std;
#include<vector>
 
//-1 = can not visit
//1 = can visit
//0 = visited

//Moves = (r-2,c-1), (r-2,c+1), (r-1,c-2), (r-1,c+2), (r+1,c-2), (r+1,c+2), (r+2,c-1), or (r+2,c+1)

void visit(vector<vector<int>> board, int n, int i, int j)
{
	if(board[i][j] == 0)	return;
	if(i > n or j > n)		return;

	board[i][j] = 0;
	if(board[i-2][j-1] == 1)
	{
		visit(board, n, i-2, j-1);
	}
	if(board[i-2][j+1] == 1)
	{
		visit(board, n, i-2, j+1);
	}
	if(board[i-1][j+2] == 1)
	{
		visit(board, n, i-1, j+2);
	}
	if(board[i+1][j+2] == 1)
	{
		visit(board, n, i+1, j+2);
	}
	if(board[i+2][j+1] == 1)
	{
		visit(board, n, i+2, j+1);
	}
	if(board[i+2][j-1] == 1)
	{
		visit(board, n, i+2, j-1);
	}
	if(board[i+1][j-2] == 1)
	{
		visit(board, n, i+1, j-2);
	}
	if(board[i-1][j-2] == 1)
	{
		visit(board, n, i-1, j-2);
	}
}

int main()
{
	int n;
	cin >> n;
	vector<vector<int>> board(n, vector<int>(n, -1));
 	//int board[11][11] = {0};
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < n; j++)
		{
			cin >> board[i][j];
		}
	}
	visit(board, n, 0, 0);
	int cnt = 0;
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < n; j++)
		{
			if(board[i][j] == 1)	cnt++;
		}
	}
	cout<<cnt;

	return 0;
}