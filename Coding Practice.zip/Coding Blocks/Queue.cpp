#include<iostream>
#include<vector>

using namespace std;

class queue
{
	private:
		vector<int> v;

	public:
		void push(int d)
		{
			v.push_back(d);
		}

		bool empty()
		{
			return v.size() == 0;
		}

		void pop()
		{
			v.erase(v.begin());
		}

		int top()
		{
			return(v[0]);
		}
};

int main()
{
	queue q;
	int n;
	cin >> n;
	while(n--)
	{
		int a;
		cin >> a;
		q.push(a);
	}

	cout<<q.top()<<endl;
	q.pop();
	while(!q.empty())
	{
		cout<<q.top()<<endl;
		q.pop();
	}

	

	return 0;
}