#include<iostream>
#include<climits>
using namespace std;

int matrix_chain(int *a, int n)
{
	int dp[100][100] = {0};
	n--;
	for(int i = 1; i < n; i++)
	{
		int r = 0, c = i;
		while(c < n)
		{
			int val = INT_MAX;
			for(int k = r; k < c; k++)
			{
				val = min(val, dp[r][k] + dp[k+1][c] + (a[r] * a[k+1] * a[c+1]));
			}
            dp[r][c] = val;
           // cout<<val<<endl;
			c++;
			r++;
		}
	}
	return dp[0][n-1];
}

int main()
{
	int n;
	cin >> n;
	int a[100] = {0};
	for(int i = 0; i < n; i++)
	{
		cin >> a[i];
	}
	cout<<matrix_chain(a, n);

	return 0;
}