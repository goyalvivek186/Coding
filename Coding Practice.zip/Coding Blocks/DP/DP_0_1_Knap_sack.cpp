#include<iostream>
#include<cstring>
using namespace std;

int knap_sack_TD(int *p, int *it, int n, int w, int dp[][1000])
{
	if(w == 0 or n == 0)	return 0;

	if(dp[n][w] != -1)	return dp[n][w];

    int op1 = 0, op2 = 0;
    if(it[n-1] <= w)
	    op1 = p[n-1] + knap_sack_TD(p, it, n-1, w-it[n-1], dp);
	
    op2 = 0 + knap_sack_TD(p, it, n-1, w, dp);

	return dp[n][w] = max(op1, op2);
}

int main()
{
	int n, s;
	cin >> n >> s;
	int p[1000] = {0};
	int it[1000] = {0}; 
	for(int i = 0; i < n; i++)
	{
		cin >> it[i];
        
	}
   
	for(int i = 0; i < n; i++)
	{
		cin >> p[i];
	}
	int dp[1000][1000] = {0};
    memset(dp, -1, sizeof(dp));
	cout<<knap_sack_TD(p, it, n, s, dp);

    for(int i = 0; i < n; i++)
    /*{cout<<endl;
        for(int j = 0; j < n; j++)
        {
            cout<<dp[i][j]<<" ";
        }
    }*/

	return 0;
}