#include<iostream>
#include<climits>
using namespace std;

int min_steps(int *a, int n)
{
    if(a[0] == 0 or n == 0)   return INT_MAX;
    int dp[10000] = {0};
    dp[0] = 0; 
    for(int i = 1; i < n; i++)
    {
        dp[i] = INT_MAX;
        for(int j = 0; j < i; j++)
        {
            if(j + a[j] >= i and dp[j] != INT_MAX)
            {
                dp[i] = min(dp[i], dp[j]+1);
            }
        }
        //if(dp[i] == INT_MAX)    return dp[i];
        //dp[i] ++;
        //cout<<dp[i]<<" ";
    }
    for(int i = 0; i < n; i++)  cout<<dp[i]<<" ";
    cout<<endl;
    return dp[n-1];
}

int main()
{   
    int t;
    cin >> t;
    while(t--)
    {
        int n;
        cin >> n;
        int a[100000] = {0};
        for(int i = 0; i < n; i++)
        {
            cin >> a[i];
        }
        cout<<min_steps(a, n);
    }



    return 0;
}