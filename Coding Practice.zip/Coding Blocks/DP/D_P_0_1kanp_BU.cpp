#include<iostream>
#include<cstring>
using namespace std;

int value(int n, int s, int *wt, int *pr)
{
	int dp[100][100];
	memset(dp, -1, sizeof(dp));
	for(int i = 0; i < n+1; i++)	dp[0][i] = 0;
	for(int i = 0; i < s+1; i++)	dp[i][0] = 0;

	for(int i = 1; i < n; i++)		//items
	{
		for(int j = 1; j < n; j++)	//Weights
		{
			int inc = 0, exc = 0;
			if(wt[i-1] <= j)
			{
				inc = pr[i-1] + dp[i-1][j - wt[i-1]];
			}
			exc = dp[i-1][j];
			dp[i][j] = max(inc, exc);
		}
	}
	return dp[n+1][s+1];
}


int main()
{
	int n, s;
	cin >> n >> s;
	int its[10000] = {0};
	int pr[10000] = {0};
	for(int i = 0; i < n; i++)	cin >> its[i];
	for(int i = 0; i < n; i++)	cin >> pr[i];
	cout<<value(n, s, its, pr);



	return 0;
}