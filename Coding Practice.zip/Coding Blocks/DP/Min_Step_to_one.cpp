#include<iostream>
#include<climits>

using namespace std;


int min_one_TD(int n, int *dp)
{
	if(n == 1)
	{
		return 0;
	}
	if(dp[n] != 0)
	{
		return dp[n];
	}
	int op1 = INT_MAX, op2 = INT_MAX, op3;

	if(n % 2 == 0)	op1 = min_one_TD(n/2, dp);
	if(n % 3 == 0)	op2 = min_one_TD(n/3, dp);
	op3 = min_one_TD(n-1, dp);
	return dp[n] =	1 + min(op1, min(op2, op3)); 
}


int min_one_BU(int n)
{
	int a[1000] = {0};
    a[1] = 0;
	for(int i = 2; i <= n; i++)
	{
		int op1, op2, op3;
		if(i % 2 == 0 and (i / 2) >= 1)
		{
			op1 = a[i/2];
		}
		else
		{
			op1 = INT_MAX;
		}
		if(i % 3 == 0 and (i / 3 >= 1))
		{
			op2 = a[i/3];
		}
		else
		{
			op2 = INT_MAX;
		}
		op3 = a[i-1];

		a[i] = min(op1, min(op2, op3)) + 1;
	}
	return a[n];

}

int main()
{
	int n;
	cin >> n;
	int dp[100] = {0};
	cout<<min_one_BU(n)<<endl;
    cout<<min_one_TD(n, dp);
	
	return 0;
}