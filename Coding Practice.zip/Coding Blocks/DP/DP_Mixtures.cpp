#include<iostream>
#include<cstring>
#include<climits>
using namespace std;

int sum(int *a, int n, int s, int e)
{
	int sum = 0;
	for(int i = s; i <= e; i++)
	{
		sum += a[i];
        sum %= 100;
	}
	return sum;
}

int mix(int *a, int n, int dp[][100])
{
    n--;
	for(int i = 1; i <= n; i++)
	{
		int r = 0, c = i;
		while(c <= n)
		{
			int val = INT_MAX;
			for(int k = r; k < c; k++)
			{
				val = min(val, dp[r][k] + dp[k+1][c] + (sum(a, n, r, k) * sum(a, n, k+1, c)));
			}
			dp[r][c] = val;
			r++;
			c++;
		}
	}

	return dp[0][n];
}

int main()
{
	int n;
	cin >> n;
	int a[1000] = {0};
	for(int i = 0; i < n; i++)	cin >> a[i];

	int dp[100][100];
	memset(dp, 0, sizeof(dp));
	cout<<mix(a, n, dp);


	return 0;
}