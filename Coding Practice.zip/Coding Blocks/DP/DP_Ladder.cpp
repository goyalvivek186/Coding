#include<iostream>

using namespace std;

int ladder_TD(int n, int k, int *ways)
{
	if(n == 0)	return 1;		//On ground = only one way

	if(ways[n] != 0)	return ways[n];
    
    ways[n] = 0;
	for(int i = 1; i <= k; i++)
	{
		if(n-i >= 0)
		{
			ways[n] += ladder_TD(n-i, k, ways);
		}
	}

	return ways[n];
}

int ladder_BU(int n, int k)
{
	int ways[100] = {0};
	ways[0] = 1;
	for(int i = 1; i <= n; i++)
	{
		for(int j = 1; j <= k; j++)
		{
			if(i-j >= 0)
			{
				ways[i] += ways[i-j];
			}
		}
	}
    return ways[n];
}

int main()
{
	int n, k;
	cin >> n >> k;
	int *ways = new int[n + 1]{0};
	cout<<ladder_TD(n, k, ways)<<endl;
    cout<<ladder_BU(n, k);
	return 0;
}