#include<iostream>
#include<climits>
using namespace std;

int coin_change_BU(int amt, int *coin, int n)
{
	int *change = new int[amt+1]{0};
	for(int i = 1; i <= amt; i++)
	{
		change[i] = INT_MAX;
		for(int j = 0; j < n; j++)
		{
			if(i - coin[j] >= 0)	
			{
				change[i] = min(change[i], change[i-coin[j]]);
			}
		}
		change[i] += 1;		//Always add after selection of min else create wrong ans
	}
	return change[amt];

}

int coin_change_TD(int n, int amt, int *coin, int *change)
{
	if(amt == 0)
	{
		return 0;
	}
	else if(change[amt] != 0)	return change[amt];

	int ans = INT_MAX;
	for(int i = 0; i < n; i++)
	{
		if(amt - coin[i] >= 0)	ans = min(ans, coin_change_TD(n, amt - coin[i], coin, change));
	}
	change[amt] = ans + 1;
	return change[amt];
}


int main()
{
	int n;
	cin >> n;
	int *coin = new int[n];
	for(int i = 0; i < n; i++)
	{
		cin >> coin[i];
	}
	int amt;
	cin >> amt;

	cout<<coin_change_BU(amt, coin, n)<<endl;

	int *change = new int[amt]{0};
	cout<< coin_change_TD(n, amt, coin, change);

	return 0;
}