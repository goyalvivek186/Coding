#include<iostream>
using namespace std;

int value(int n, int s, int *wt, int *pr)
{
	int dp[10000] = {0};
	for(int i = 1; i <= s; i++)
	{
		for(int j = 0; j < n; j++)
		{
			if(wt[j] <= i)
			{
				dp[i] = max(dp[i], pr[j] + dp[i - wt[i]]);
			}
		}
	}
	return dp[s];
}

int main()
{
	int n, s;
	cin >> n >> s;
	int wt[10000] = {0}, pr[10000] = {0};
	for(int i = 0; i < n; i++)	cin >>wt[i];
	for(int i = 0; i < n; i++)	cin >>pr[i];

	cout<<value(n, s, wt, pr);




	return 0;
}