#include<iostream>
using namespace std;

int game(int *a, int s, int e)
{
	if(s > e)	return 0;

	int op1 = a[s] + game(a, s+1, e);
	int op2 = a[e] + game(a, s, e+1);
	return max(op1, op2);
} 

int main()
{
	int n;
	cin >> n;
	int a[100000] = {0};
	for(int i = 0; i < n; i++)
	{
		cin >> a[i];
	}
	return game(a, 0, n-1);


	return 0;
}