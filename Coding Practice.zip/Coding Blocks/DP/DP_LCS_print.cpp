#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
using namespace std;

int dp[100][100] = {0};
int LCS_BU(string s1, string s2)
{
	if(s1.length() == 0 or s2.length() == 0)	return 0;
	for(int i = 1; i <= s1.length(); i++)
	{
		for(int j = 1; j <= s2.length(); j++)
		{
			if(s1[i-1] == s2[j-1])
			{
				dp[i][j] = 1 + dp[i-1][j-1];
			}
			else
			{
				int op1 = dp[i][j-1];
				int op2 = dp[i-1][j];
				dp[i][j] = max(op1, op2);
			}
		}
	}
	return dp[s1.length()][s2.length()];
}


int main()
{
	string s1, s2;
	cin >> s1 >> s2;
	int n = LCS_BU(s1, s2);
	vector<char> v(n);
	v.clear();
	int i = s1.length(), j = s2.length();
	while(i > 0 and j > 0)
	{
		if(dp[i][j] == dp[i][j-1])	j--;
		else if(dp[i][j] == dp[i-1][j])	i--;
		else
		{
			v.push_back(s1[i-1]);
			i--;
			j--;
		}
	}
	reverse(v.begin(), v.end());
	for(char ch : v)
	{
		cout<<ch;
	}


	return 0;
}