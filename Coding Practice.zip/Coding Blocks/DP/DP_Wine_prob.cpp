#include<iostream>

using namespace std;

int wine_TD(int s, int e, int *p, int dp[][100], int y = 1)
{
	if(s > e)
	{
		return 0;
	}
	if(dp[s][e] != 0)	return dp[s][e];

	int op1 = p[s]*y + wine_TD(s+1, e, p, dp, y+1);
	int op2 = p[e]*y + wine_TD(s, e-1, p, dp, y+1);
	return dp[s][e] = max(op1, op2);
}

int main()
{
	int n;
	cin >> n;
	int p[100] = {0};
	for(int i = 0; i < n; i++)
	{
		cin >> p[i];
	}
	int dp[100][100] = {0};
	cout<<wine_TD(0, n-1, p, dp);

	return 0;
}