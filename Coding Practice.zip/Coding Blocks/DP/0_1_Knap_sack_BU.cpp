#include<iostream>
#include<climits>
using namespace std;

int main()
{	
	int n, w;
	cin >> n >> w;
	int p[10000] = {0};
	int s[10000] = {0};
	for(int i = 0; i < n; i++)	cin >> s[i];
	for(int i = 0; i < n; i++)	cin >> p[i];

	int dp[n+1][w+1];
	//memset(dp, -1, sizeof(dp)); 
	for(int i = 0; i <= n; i++)	dp[i][0] = 0;
	for(int i = 0; i <= w; i++)	dp[0][i] = 0;

	for(int i = 1; i <= n; i++)
	{
		//dp[i][j] = INT_MIN;
		for(int j = 1; j <= w; j++)
		{
			int op1, op2;
			op1 = op2 = 0;
			if(s[i-1] <= j)		//Include
			{
				op1 = p[i-1] + dp[i-1][j-s[i-1]];
			}

			op2 = 0 + dp[i-1][j];
			dp[i][j] = max(op1, op2);
		}
	}

	cout<<dp[n][w];
	return 0;
}