#include<iostream>
#include<climits>

using namespace std;

int rod_cut(int *price, int n, int rod)
{
	if(rod <= 0)	return 0;

	int max_price = INT_MIN;
	int curr_price = INT_MIN;
	for(int i = 0; i < rod; i++)
	{
		int cut = i+1;
		curr_price = price[i] + rod_cut(price, n, rod-cut);
		max_price = max(curr_price, max_price);
	}
	return max_price;
}

int main()
{
	int price[] = {1, 5, 8, 9, 10, 17, 17, 20};
	int n = sizeof(price) / sizeof(int);
	int rod = 8;
	cout<< rod_cut(price, n, rod);


	return 0;
}