#include<iostream>

using namespace std;

bool target_sum(int *a, int n, int t, int i, int s)
{
	if(s > t)	return false;
	if(i > n)	return false;
	if(s == t)	return true;
	if(target_sum(a, n, t, i+1, s))	return true;
	s += a[i];
	if(target_sum(a, n, t, i+1, s))	return true;

	return false;
}

int main()
{
	int n, t;
	cin >> n >> t;
	int a[10000] = {0};
	for(int i = 0; i < n; i++)
	{
		cin >> a[i];
	}
	if(target_sum(a, n, t, 0, 0))	cout<<"Yes";
	else	cout<<"No";
}