#include<iostream>
#include<climits>
using namespace std;

int main()
{
	int a[100];
	int n;
	cin >> n;
	for(int i = 0; i < n; i++)
	{
		cin >> a[i];
	}
	int dp[100] = {0};
	//dp[0] = 1;
    int m = INT_MIN;
	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < i; j++)
		{
			if(j < i and a[i] > a[j])
			{
				dp[i] = max(dp[i], dp[j]);
			}
		}
        dp[i] ++;
        //cout<<dp[i]<<" ";
		m = max(m, dp[i]);
	}
    cout<<m;


	return 0;
}