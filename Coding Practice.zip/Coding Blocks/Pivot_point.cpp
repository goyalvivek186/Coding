#include<iostream>
using namespace std;

int pivot(int a[], int n)
{
	int s = 0;
	int e = n, m, ans;

	while(s <= e)
	{
		m = (s + e)/2;
		if(a[m] > a[m+1] and a[m] > a[m-1])
		{
			return m;
		}
		else if(a[m - 1] > a[m])
		{
			return m-1;
		}
		else if(a[m] > a[s])
		{
			s = m + 1;
		}
		else
		{
			e = m - 1;
		}
		

	}
	
	return -1;
}



int main()
{
	int n;
	cin >> n;
	int a[n];
	for(int i = 0; i < n; i ++)
	{
		cin >> a[i];
	}
	
	cout<<pivot(a, n);

	
	

	
	return 0;
}