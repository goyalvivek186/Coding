#include<iostream>
#include<string.h>
using namespace std;

void pal(char ch[])
{
	int s = strlen(ch);
	int i = 0, j = s - 1, c = 0;
	while(j > s/2 and i  < s/2)
	{
		if(ch[i] != ch[j])
		{
			c++;
			break;
		}
		i++;
		j--;
	}
	if(c != 0)
	{
		cout<<"Not palindrome";
	}
	else
	{
		cout<<"Palindrome";
	}

}


int main()
{
	char ch[100];
	cout<<"Enter the string to check for palindrome\n";
	gets(ch);
	pal(ch);



	return 0;
}