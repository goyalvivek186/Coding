#include<iostream>
using namespace std;

int main()
{
	int a[20], s, c=0 ,p ,i=0;
	cin>>s;
	for(i = 0; i < s; i++)
	{
		cin>>a[i];
	}
	for(i = 0; i < s; i++)
	{
		if(a[i]>a[i+1] && a[i+1]<a[i+2])
		{
			p=i+1;
			break;
		}
	}
	for(i = 0; i < p; i++)
	{
		if(a[i] < a[i+1])
		{
			c++;
			break;
		}
	}
	for(i = p; i < s; i++)
	{
		if(a[i] > a[i+1])
		{
			c++;
			break;
		}
	}
	if(c == 0)
	{
		cout<<"true\n";
	}
	else
	{
		cout<<"false\n";
	}



	return 0;
}