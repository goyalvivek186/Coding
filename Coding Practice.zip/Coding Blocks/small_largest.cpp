#include<iostream>
#include<climits>
using namespace std;

void sm_lgr(int s, int a[20])
{
	int max = INT_MIN, min = INT_MAX;
	int sp, lp;
	for(int i = 0; i < s; i++)
	{
		if(a[i] > max)
		{
			max = a[i];
			lp = i + 1;
		}
		if(a[i] < min)
		{
			min = a[i];
			sp = i + 1;
		}
	}
	cout<<"The largest element = "<<max<<" with position "<<lp<<"\n\n";
	cout<<"The smallest element = "<<min<<" with position "<<sp;

}


int main()
{

	int s, a[20] = {0};
	cout<<"Enter the no of elementes if the array\n";
	cin>>s;
	for(int i = 0; i < s; i++)
	{
		cin>>a[i];
	}
	sm_lgr(s, a);


	return 0;
}