#include<iostream>
using namespace std;


int main() {

	int n,a,i=0,x;
	cin>>n;
	while(i<n)
	{
		cin>>a;
		int sum1=0, sum2=0;
		while(a!=0)
		{
			x=a%10;
			a=a/10;
			if (x%2==0)
			{
				sum1= sum1+x;
			}
			else 
			{
				sum2= sum2+x;
			}
		}
		if (sum1 % 4 == 0||sum2 % 3 == 0)
		{
			cout<<"Yes"<<"\n";
		}
		else 
		{
			cout<<"No"<<"\n";
		}


	}
	return 0;
}