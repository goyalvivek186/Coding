#include <iostream>

using namespace std;

void subset(int a[], int i, int sol[], int j, int t, int sum, int n)
{

    if(sum == t)
    {
        for(int k = 0; k <= j; k++)
        {
            cout<<sol[k]<<" ";
        }
        cout<<endl;
        return;
    }

    if(i == n)
    {
        return;
    }

    if(sum > t)
    {
        return;
    }

        subset(a, i+1, sol, j, t, sum, n);
        if(sum + a[i] <= t)
        {
            sol[j] = a[i];
            subset(a, i+1, sol, j+1, t, sum + a[i], n);
        }
        sol[i] = 0;
}
int main()
{
    int a[10] = {0}, n;
    int sol[10] = {0};
    cin >> n;
    for(int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    int t;
    cin >> t;
    subset(a, 0, sol, 0, t, 0, n);
    return 0;
}
