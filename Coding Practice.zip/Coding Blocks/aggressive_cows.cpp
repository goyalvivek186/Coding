#include<iostream>
#include<algorithm>
using namespace std;

bool cow(int a[],int n,int m,int c)
{
	int count = 1;
	int last = a[0];
	for(int i = 1; i < n; i++)
	{
		if((a[i] - last) >= m)
		{
			last = a[i];
			count++;
			if(count == c)
			{
				return true;
			}
		}
	}
	return false;
}

int main()
{
	int n, c, a[1000000] = {0}, m;
	cin >> n >> c;
	for(int i = 0; i < n; i++)
	{
		cin >> a[i];
	}

    sort(a,a+n);				//				IMPORTANT
	int s = 0, e = a[n - 1] - a[0];
	int p;
	while(s <= e)
	{
		m = (s + e) / 2;
		bool ans = cow(a, n, m, c);
		if(ans)
		{
			p = m;
			s = m+1;
		}
		else
		{
			e = m-1;
		}
	}
	cout<< p;
	

	
	return 0;
}