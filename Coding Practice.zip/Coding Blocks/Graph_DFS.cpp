#include<iostream>
#include<list>
#include<unordered_map>
#include<queue>

using namespace std;

template<typename T>
class graph
{
	unordered_map<T, list<T>> m;
public:
	void addedge(T a, T b)
	{
		m[a].push_back(b);
		m[b].push_back(a);
	}

	void DFS_helper(unordered_map<T, bool> &visited, T source)
	{
		cout<<source<<" ";
		visited[source] = true;
		for(auto it : m[source])
		{
			if(visited[it] == false)
			DFS_helper(visited, it);
		}
	}

	void DFS(T source)
	{
		unordered_map<T, bool> visited;
		for(auto it : m)
		{
			visited[it.first] = false;
		}
		visited[source] = true;
		DFS_helper(visited, source);
	}
};

int main()
{
	graph<int> g;
	g.addedge(0, 1);
	g.addedge(1, 2);
	g.addedge(2, 3);
	g.addedge(3, 0);
	g.addedge(3, 4);
	g.addedge(4, 5);

	g.DFS(0);

	return 0;
}