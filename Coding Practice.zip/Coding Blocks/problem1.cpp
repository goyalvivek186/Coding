#include<iostream>
#include<math.h
using namespace std;


int main() {
	int n;
	int x=1;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<=i;j++)
		{
			if (i<=x)
			{	cout<<x;
			}
			else
			{
				cout<<i;
				for(int k=1;k<i;k++)
				{
					cout<<"0";
				}
				cout<<i;
				break;
			}

		}
		cout<<"\n";

	} 
	return 0;
}