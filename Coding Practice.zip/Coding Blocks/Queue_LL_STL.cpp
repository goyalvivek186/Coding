#include<iostream>
#include<list>

using namespace std;

int main()
{
	list<int> l;
	int n;
	cin >> n;
	while(n--)
	{
		int a;
		cin >> a;
		l.push_back(a);
	}
	l.pop_front();
	for(auto it : l)
	{
		cout<<it<<endl;
	}

	return 0;
}