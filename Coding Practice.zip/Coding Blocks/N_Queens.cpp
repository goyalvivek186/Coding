#include<iostream>

using namespace std;

bool canplace(int *a, int n, int i, int j, int n)
{
	for(int x = 0; x < i; x++)
	{
	if(a[x][j] == 1)
	{
	return false;
	}
	}


	for(int x = i - 1, int y = j - 1; x >= 0 and y >= 0; x--, y--)
	{
	if(a[x][y] == 1)
	{
	return false;
	}
	}

	for(int x = i - 1, int y = j + 1; x >= 0 and y < n; x--, y++)
	{
	if(a[x][y] == 1)
	{
	return false;
	}
	}

}


bool queen(int *a, int n, int i, int j, int &c)
{
	if(i == n)
	{
		return true;
		c++;
	}
	if(i > n or j > n)
	{
	return false;
	}

for(int z = 0; z  <= n; z++)
{	
	if(canplace(a, n, i, j, n))
	{
	a[i][j] = 1;
	
	if(canplace(a, n, i + 1, j, n))

	}
	else
		return false;
	a[i][j] = 0;


}

}

int main()
{
	int n;
	cin >> n;
	int a[n][n];
	int c = 0;
	cout<<queen(a, n - 1, 0, 0, c);


	return 0;
}