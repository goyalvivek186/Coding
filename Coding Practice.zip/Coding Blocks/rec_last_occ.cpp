#include<iostream>
#include<string>
#include<algorithm>
#include<climits>
#include<math.h>

using namespace std;

int search(int *a, int n, int t)
{
	if(n == 0)
	{
		return -1;
	}

	if(a[n] == t)
	{
		return n;
	}

	return search(a, n-1, t);
}

int main() 
{
    int n;
    cin >> n;
    int a[n];
    for(int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    int t;
    cin >> t;
    cout<<search(a, n, t);
    return 0;
}