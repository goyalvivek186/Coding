#include<iostream>
#include<queue>
#include<climits>
using namespace std;

class node
{
	public:
		int data;
		node * left;
		node * right;

	node(int d)
	{
		data = d;
		right = NULL;
		left = NULL;
	}
};
/*
bool is_BST(node *root, int min = INT_MIN, int max = INT_MAX)
{
	if(root == NULL)
	{
		return true;
	}

	if(root->data > min and root->data < max and is_BST(root->left, min, root->data) and is_BST(root->right, root->data, max))
	{
		return true;
	}
	else
	{
		return false;
	}
}
*/

class check
{
public:
	bool isbst;
	int min, max;
};
/*
check is_BST(node *root, int min = INT_MIN, int max = INT_MAX)
{
	check c;
	if(root->left == NULL and root->right == NULL)
	{
		c.isbst = true;
		c.min = root->data;
		c.max = max;
	}
	check left = is_BST(root->left);
	check right = is_BST(root->right);

	if(root->data)
}
*/
void inorder(node *root)
{
	if(root == NULL)
	{
		return ;
	}
	inorder(root->left);
	cout<<root->data<<" ";
	inorder(root->right);
}

node *deleteBST(node *root, int d)
{
	if(root == NULL)
	{
		return NULL;
	}
	if(root->data < d)
	{
		root->right = deleteBST(root->right, d);
	}
	else if(root->data > d)
	{
		root->left = deleteBST(root->left, d);
	}
	else if(root->data == d)
	{
		//1. 0 Child
		if(root->right == NULL and root->left == NULL)
		{
			delete root;
			return NULL;
		}
		//2. 1 Child
		else if(root->left == NULL and root->right != NULL)
		{
			node *t = root->right;
			delete root;
			return t;
		}
		else if(root->right == NULL and root->left != NULL)
		{
			node *t = root->left;
			delete root;
			return t;
		}
		//3. 2 Child
		else if(root->left != NULL and root->right != NULL)
		{
			//Find potential substitution i.e. Max from left or Min from right subtree
			node *r = root->right;
			while(r->left != NULL)
			{
				r = r->left;
			}
			root->data = r->data;
			root->right = deleteBST(root->right, r->data);
			return root;
		}
	}
    return root;
}

bool search(node *root, int d)
{
	if(root == NULL)
	{
		return false;
	}
	if(root->data == d)
	{
		return true;
	}
	if(d >= root->data)
	{
		return search(root->right, d);
	}
	else
	{
		return search(root->left, d);
	}
}


void BFS(node *root)
{
	if(root == NULL)
	{
		return;
	}
	queue<node *> q;
	q.push(root);
	q.push(NULL);
	while(!q.empty())
	{
		node *t = q.front();
		
		if(t != NULL)
		{
			cout<<t->data<<", ";
			q.pop();
			if(t->left)
			{
				q.push(t->left);
			}
			if(t->right)
			{
				q.push(t->right);
			}
		}
		else
		{
			cout<<endl;
			q.pop();
            if(!q.empty())
			q.push(NULL);
		}
	}

}
node * BST(int d, node *root)
{
	if(root == NULL)
	{
		return new node(d);
	}
	
	if(d < root->data)
	{
		root->left = BST(d, root->left);
	}
	else
	{
		root->right = BST(d, root->right);
	}
	return root;
}

node * build()
{
	int d;
	cin >> d;
	node *root = NULL;
	while(d != -1)
	{
		root = BST(d, root);
		cin >> d;
	}
	return root;

}

//Input- 5 3 7 1 6 8 -1

int main()
{
	node * root = build();
	BFS(root);
	cout<<endl;
	/*if(search(root, 10))
	{
		cout<<"True";
	}
	else
	{
		cout<<"False";
	}*/
        //root = deleteBST(root, 5);
	//BFS(root);
    inorder(root);
    cout<<endl;
    if(is_BST(root))
    {
    	cout<<"Yes";
    }
    else
    {
    	cout<<"No";
    }
	return 0;
}