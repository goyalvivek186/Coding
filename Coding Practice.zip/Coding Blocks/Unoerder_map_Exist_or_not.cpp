#include<iostream>
#include<unordered_map>
using namespace std;

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n, x;
		cin >> n;
		unordered_map<int, int> um;
		for(int i = 0; i < n; i++)
		{
			cin >> x;
			um[x] = i;
		}
		int q;
		cin >> q;
		while(q--)
		{
			cin >> x;
			if(um.count(x))
			{
				cout<<"Yes"<<endl;
			}
			else
			{
				cout<<"No"<<endl;
			}
		}
	}
	return 0;
}