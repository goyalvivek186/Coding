#include<iostream>
using namespace std;



int main()
{
	int n, i, j, x, t, s;
	cin >> n;
	x = (n + 1) / 2;
	t = x - 1;	//3
	s = x - 6;	//-2
	for(i = 1; i <= x; i++)
	{
		for(j = 0; j < t * x; j++)
		{
			cout<<" ";
		}
		for(j = i; j > 0; j--)
		{
			cout<<j<<" ";
		}
		for(j = 0; j < s; j++)
		{
			cout<<" ";
		}
		for(j = 1; j <= i; j++)
		{
			if(i == 1)
				break;
			cout<<j<<" ";
		}


		t--;
		s += x;
		cout<<endl;
	}



	t = x;
	s -= 2*x;
	for(i = x-1; i>0; i--)
	{
		for(j = 0; j < t; j++)
		{
			cout<<" ";
		}
		for(j = i; j > 0; j--)
		{
			cout<<j<<" ";
		}
		for(j = 0; j < s; j++)
		{
			cout<<" ";
		}
		for(j = 1; j <= i; j++)
		{
			if(i == 1)
				break;
			cout<<j<<" ";
		}
		cout<<endl;
		t += x;
		s -= x;

	}




	return 0;
}