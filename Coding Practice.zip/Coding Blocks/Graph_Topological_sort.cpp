#include<iostream>
#include<unordered_map>
#include<list>
#include<queue>

using namespace std;

template<typename T>
class graph
{
	unordered_map<T, list<T> > m;
public:

	void add_edge(T a, T b)
	{
		m[a].push_back(b);
	}

	void DFS_helper(unordered_map<T, bool> &visited, list<T> &order, T source)
	{
		visited[source] = true;
		for(auto p : m[source])
		{
			if(!visited[p])
			{
				DFS_helper(visited, order, p);
			}
		}
		order.push_front(source);
	}

	void topological_DFS()
	{
		list<T> order;
		unordered_map<T, bool> visited;
		for(auto p : m)
		{
			visited[p.first] = false;
		}

		for(auto p : m)
		{
			if(!visited[p.first])
			{
				DFS_helper(visited, order, p.first);
			}
		}

		for(auto p : order)
		{
			cout<<p<<" ";
		}
	}

	void topological_BFS()
	{
		unordered_map<T, bool> visited;
		unordered_map<T, int> depend;
		for(auto p : m)
		{
			visited[p.first] = false;
			depend[p.first] = 0;
		}

		for(auto p : m)
		{
			for(auto l : p.second)
			{
				depend[l]++;
			}
		}

		queue<T> q;
		for(auto p : m)
		{
			if(depend[p.first] == 0)
			{
				q.push(p.first);
			}
		}

		while(!q.empty())
		{
			T a = q.front();
			q.pop();
			cout<<a<<" ";
			visited[a] = true;
			for(T p : m[a])
			{
				depend[p]--;
				if(depend[p] == 0 and !visited[p])
				{
					q.push(p);
				}
			}
		}
	}
};

int main()
{
	graph<int> g;
    g.add_edge(0, 2);
	g.add_edge(1, 2);
	g.add_edge(1, 4);
	g.add_edge(2, 3);
    g.add_edge(2, 5);
	g.add_edge(3, 5);

	g.topological_BFS();

	return 0;
}