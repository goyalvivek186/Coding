#include<iostream>

using namespace std;

int part(int *a, int s, int e)
{
	int p = a[e];
	int i = s, j = s;
	for(j = s; j < e; j++)
	{
		if(a[j] <= p)
		{
			swap(a[i], a[j]);
			i++;
		}
	}
	swap(a[i], a[e]);
    return i;

}

void quick(int *a, int s, int e)
{
	if(s>=e)
	{
		return;
	}
	int p = part(a, s, e);

	quick(a, s, p-1);
	quick(a, p+1, e);

}

int main()
{
	int n;
	cin >> n;
	int a[200005];
	for(int i = 0; i < n; i++)
	{
	cin >> a[i];
	}
	quick(a, 0, n-1);
    for(int i = 0; i < n; i++)
	{
	cout<<a[i]<<" ";
	}
	return 0;
}