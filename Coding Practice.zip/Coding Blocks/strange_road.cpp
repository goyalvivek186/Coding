Rohan’s city can be represented as an infinite cartesian coordinate system. The City has a strange 
road system. It consists of a single road connecting all the points in the plane. The road starts
 from (0,0) and form the following pattern:- (0,0) to (1,0), (1,0) to (1,1), (1,1) to (-1,1), (-1,1) 
to (-1,-1), (-1,-1) to (2,-1), (2-1) to (2,2) and so on. Rohan want to go from (0,0) to (X,Y). Can 
you find the number of turns required to go from (0,0) to (X,Y) following the above described road?


#include<iostream>
using namespace std;

void main()
{
	int a[]

}