#include<iostream>
#include<string>
#include<algorithm>
#include<climits>

using namespace std;


int main()
{
	int a, i, j;
	cin >> a;
	cin >> i;
	int ones = -1;
	int left = (ones << (i+1));
//	int right = (1 << i) - 1;
//	int mask = left | right;
	cout<< (left & a);
	

	
	return 0;
}