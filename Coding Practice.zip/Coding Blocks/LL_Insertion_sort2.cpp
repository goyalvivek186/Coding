#include<iostream>
#include<list>

using namespace std;

list<int> insertion(list<int> l)
{
	auto i = l.begin();
	i++;
	for(; i != l.end(); i++)
	{
		int x = *i;
		auto j = i;
		while(j != l.begin() and x > *j)
		{
			*j = *(j--);
		}
		*j = x;
	}
	return l;
}

int main()
{
	list<int> l, ans;
	int n;
	cin >> n;
	while(n--)
	{
		int a;
		cin >> a;
		l.push_back(a);
	}
	ans = insertion(l);
	for(auto it : ans)
	{
		cout<<it<<" ";
	}


	return 0;
}