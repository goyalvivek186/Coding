#include<iostream>
#include<string>
#include<algorithm>
#include<climits>
#include<math.h>

using namespace std;

void prime(int *a, long long n)
{
	a[0] = a[1] = -1;
	a[2] = 1;
	for(long long i = 3; i < n; i += 2)
	{
		a[i] = 1;
	}
	for(long long i = 3; i < n; i+=2)
	{
		if(a[i] == 1)
		{
			for(long long j = i*i; j < n; j += i)
			{
				a[j] = 0;
			}
		}
	}

}

int main()
{
	long long n = 1000005;
	int a[1000005] = {0};
	prime(a, n);

	int sum[1000005] = {0};
	
	for(long long i = 2; i <= n; i++)
	{
		sum[i] = sum[i-1] + a[i];
	}
	int t;
	cin >> t;
	while(t--)
	{
		int a, b;
		cin >> a >> b;

		cout<<sum[b] - sum[a-1]<<endl;

	}
	


	
	return 0;
}