#include <iostream>
using namespace std;

bool isPossible(int arr[],int n,int m,int min_pages){
    int studentUsed = 1;
    int pagesUsed = 0;

    for(int i=0;i<n;i++){
        if(pagesUsed + arr[i] > min_pages){
            studentUsed++;
            pagesUsed = arr[i];

            if(studentUsed > m){
                return false;
            }
        }
        else{
            pagesUsed += arr[i];
        }
    }
    return true;
}

int findPages(int arr[],int n,int m){
    int sum = 0;
    for(int i=0;i<n;i++){
        sum += arr[i];
    }

    int s = arr[n-1];
    int e = sum;

    int result;
    while(s <= e){
        int mid = (s + e)/2;
        if(isPossible(arr,n,m,mid)){
            result = mid;
            e = mid - 1;
        }
        else{
            s = mid + 1;
        }
    }
    return result;
}

int main() {
    int test;
    cin>>test;
    while(test--){
        int n,m;
        cin>>n>>m;
        int arr[1000];
        for(int i=0;i<n;i++){
            cin>>arr[i];
        }

        cout<<findPages(arr,n,m)<<endl;
    }
    return 0;
}