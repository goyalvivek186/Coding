#include<iostream>
#include<vector>
#include<string>

using namespace std;

template <typename t>
class stack
{
private:
	vector <t> v;

public:
	void push(t d)
	{
		v.push_back(d);
	}

	void pop()
	{
		v.pop_back();
	}

	bool empty()
	{
		return v.empty();
	}

	t top()
	{
		return v[v.size()-1];
	}

	int size()
	{
		return v.size();
	}

};

int main()
{
	stack<char> s;
	for(int i = 66; i < 72; i++)
	{
		s.push(i);
	}
	cout<<s.size()<<endl;
	cout<<s.top()<<endl;
	while(!s.empty())
	{
		cout<<s.top()<<endl;
		s.pop();
	}


	return 0;
}