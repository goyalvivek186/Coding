#include<iostream>
using namespace std;

class node
{
public:
	int data;
	node *right;
	node *left;
	node(int d)
	{
		data = d;
		right = NULL;
		left = NULL;
	}
};

node *delete_BST(node *root, int d)
{
	if(root == NULL)
	{
		return root;
	}

	if(root->data < d)
	{
		root->right = delete_BST(root->right, d);
		return root;
	}

	if(root->data > d)
	{
		root->left = delete_BST(root->left, d);
	}

	if(root->data == d)
	{
		//	0 Chile
		if(root->left == NULL and root->right == NULL)
		{
			delete root;
			return NULL;
		}

		//	1 Child
		if(root->left == NULL and root->right != NULL)
		{
			node *t = root->right;
			delete root;
			return t;
		}
		if(root->left != NULL and root->right == NULL)
		{
			node *t = root->left;
			delete root;
			return t;
		}

		//	2 Child
		if(root->left != NULL and root->right != NULL)
		{
			//	find replacement
			node *r = root->right;
			while(r->left != NULL)
			{
				r = r->left;
			}
			root->data = r->data;
			root->right = delete_BST(root->right, r->data);
		}
	}
}

void preorder(node *root)
{
	if(root == NULL)
	{
		return;
	}
	cout<<root->data<<" ";
	preorder(root->left);
	preorder(root->right);
}

node *insert_in_BST(node *root, int d)
{
	if(root == NULL)
	{
		return new node(d);
	}
	if(root->data > d)
	{
		root->left = insert_in_BST(root->left, d);
		return root;
	}
	else
	{
		root->right = insert_in_BST(root->right, d);
		return root;
	}
}

node *BST(int n)
{
	int d;
	node *root = NULL;
	while(n--)
	{
		cin >> d;
		root = insert_in_BST(root, d);
	}
	return root;
}

int main()
{
	int t;
	cin >> t;
	while(t--)
	{
		int n;
		cin >> n;
		node *root = BST(n);

		cin >> n;
		while(n--)
		{
			int x;
			cin >> x;
			root = delete_BST(root, x);
		}
		preorder(root);
		cout<<endl;
	}

	return 0;
}