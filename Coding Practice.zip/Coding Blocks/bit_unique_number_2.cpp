#include<iostream>
#include<string>
#include<algorithm>
#include<climits>

using namespace std;



int main()
{
	int n, ans = 0;
	cin >> n;
	int a[n];
	for(int i = 0; i < n; i++)
	{
		cin >> a[i];
		ans = (ans^a[i]);
	}

	int t = ans, p = -1;
	while(t != 0)
	{ 
		p++;
		if((t & 1 == 1))
			break;
		t = t >> 1;
	}

	int mask = (1 << p);
	int x = 0, y = 0;
	for(int i = 0; i < n; i++)
	{
		if((a[i] & mask) > 0)
		{
			x = (x^a[i]);
		}
	}
	y = (x ^ ans);
	cout<<min(x, y) << " " << max(x, y);

	return 0;
}