#include<iostream>
#include<string.h>
using namespace std;


int main()
{
	char c1[100], c2[100];
	int t;
	cin >> t;
	
	int s = strlen(c1), i, j;
	for(j = 0; j < t; j++)
	{
		cin >> c1;
		cin >> c2;

		for(i = 0; c1[i] != '\0' and c2[i] != '\0'; i++)
		{
			if(c1[i] == c2[i])
			{
				cout<<"0";
			}
			else
			{
				cout<<"1";
			}
		}
		cout<<endl;
	}
	


	
	return 0;
}