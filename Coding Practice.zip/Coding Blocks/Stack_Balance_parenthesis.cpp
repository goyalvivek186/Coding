#include<iostream>
#include<stack>
#include<cstring>

using namespace std;

int main()
{
	stack<char> s;
	string str;
	cin >> str;
	int c = 0;
	for(int i = 0; str[i] != '\0'; i++)
	{
		char ch;
		ch = str[i];
		if(s.empty() or ch == '(')
		{
			s.push(ch);
		}
		else if(ch == ')' and s.top() == '(')
		{
			s.pop();
		}
		else
		{
			c++;
		}
	}
	if(c == 0 and s.empty())
	{
		cout<<"Yes";
	}
	else
	{
		cout<<"No";
	}




	return 0;
}