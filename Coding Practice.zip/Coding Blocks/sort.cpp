#include<iostream>
#include<climits>
using namespace std;

void count_sort(int *a, int n)
{
	int max = INT_MIN;
	for(int i = 0; i < n; i++)
	{
		if(a[i] > max)
		{
			max = a[i];
		}
	}
	max++;
	int ans[max] = {0};
	for(int i = 0; i < n; i++)
	{
		ans[a[i]] += 1;
	}
	for(int i = 0; i < max; i++)
	{
		while(ans[i] != 0)
		{
			cout<<i<<endl;
			ans[i] -= 1;
		}
	}
}

int main()
{
	int n;
	cin >> n;
	int a[n];
	for(int i = 0; i < n; i++)
	{
	cin>> a[i];
	}
	count_sort(a, n);
	/*for(int i = 0; i < n; i++)
	{
	cout<< a[i]<<endl;
	}*/


	return 0;
}