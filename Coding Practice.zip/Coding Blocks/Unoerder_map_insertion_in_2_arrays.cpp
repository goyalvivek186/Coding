#include<iostream>
#include<vector>
#include<unordered_map>
using namespace std;

int main()
{

	vector<int> v1, v2;
	int n, x;
	unordered_map<int, int> m;
	for(int i = 0; i < n; i++)
	{
		cin >> x;
		v1.push_back(x);
	}
	for(int i = 0; i < n; i++)
	{
		cin >> x;
		v2.push_back(x);
	}

	for(int i = 0; i < n; i++)
	{
		if(m.count(v1[i]) == 0)
		{
			m[v1[i]] = 1;
		}
		else
		{
			m[v1[i]]++;
		}
	}
	v1.empty();
	for(int x : v2)
	{
		if(m.count(x) == 0)
		{
			continue;
		}
		else
		{
			if(m[x] > 0)
			{
				v2.push_back(x);
				m[x]--;
			}
		}
	}

	for(int x : v1)
	{
		cout<<x<<" ";
	}
	
	return 0;
}