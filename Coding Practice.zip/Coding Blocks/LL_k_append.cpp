#include<iostream>
#include<list>

using namespace std;

int main()
{
	list <int> l;
	int n, a;
	cin >> n;
	for(int i = 0; i < n; i++)
	{
		int a;
		cin >> a;
		l.push_back(a);
	}
	

	int k;
	cin >> k;
	while(k--)
	{
        int x = l.back();
        l.pop_back();
		l.push_front(x);
		
	}
	for(auto it = l.begin(); it != l.end(); it++)
	{
		cout<<*it<<" ";
	}
	return 0;
}