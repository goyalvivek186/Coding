#include<iostream>
#include<string>
#include<algorithm>
#include<climits>
#include<math.h>

using namespace std;



int main()
{
	int a[] = {1, 2, 3};
	int s = sizeof(a) / sizeof(a[0]);
	int n = pow(2, s);
	for(int i = 0; i < n; i++)
	{
		int x = i, p = 0;
		while(x > 0)
		{
			if((x & 1 ==1))
			{
				cout<<a[p]<<" ";
			}
			p++;
			x = x>>1;
		}
		cout<<endl;
	}
	
	return 0;
}