#include<iostream>
#include<unordered_set>
using namespace std;

int main()
{
	int n;
	cin >> n;
	int pre = 0;
	unordered_set<int> us;
	while(n--)
	{
		int a;
		cin >> a;
		pre += a;
		if(pre == 0 or us.find(pre) != us.end())
		{
			cout<<"Yes";
			return 0;
		}
		us.insert(pre);
	}
	cout<<"No";
	return 0;
}