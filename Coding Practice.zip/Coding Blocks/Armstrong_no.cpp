#include<iostream>
#include<math.h>
using namespace std;


int main()
{
	int n,m,a,i=0,ans= 0;
	cin>>n;
	m=n;
	while(m != 0)
	{
		a = m%10;
		m = m/10;
		i++;
	}
	m=n;
	while(m != 0)
	{
		a = m%10;
		m = m/10;
		ans = ans + pow(a,i);
	}
	if (n == ans)
	{
		cout<<"true\n";
	}
	else
	{
		cout<<"false\n";
	}
	

	return 0;
}