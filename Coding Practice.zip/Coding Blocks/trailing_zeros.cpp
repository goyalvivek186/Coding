#include<iostream>
using namespace std;

int count_zeros(long long int n)
{

	int i = 5, ans = 0;
	while(n / i > 0)
	{
		ans += n/i;
		i *= 5;

	}
	return ans;
}


int main()
{
	long long int n;
	cout<<"Enter the no.\n";
	cin>>n;

	cout<<"Ans = "<<count_zeros(n);




	return 0;
}