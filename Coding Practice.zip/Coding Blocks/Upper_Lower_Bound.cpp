#include<iostream>
#include<algorithm>

using namespace std;

int lower(int a[], int n, int b[], int x)
{
	int t = b[x];
	auto it = lower_bound(a, a+n, t);
	int index = it - a;
	if(a[index] == b[x])
	{
		return index;
	}
	else
	{
		return -1;
	}
}


int upper(int a[], int n, int b[], int x)
{
	int t = b[x];
	auto it = upper_bound(a, a+n, t);
	int index = it - a - 1;
	if(a[index] == b[x])
	{
		return index;
	}
	else
	{
		return -1;
	}
}

int bound(int a[], int n, int b[], int t)
{
	int x = 0;
	while(x < t)
	{
		cout<<lower(a, n, b, x)<<" "<<upper(a, n, b, x)<<endl;
		x++;
	}

	return 0;
}

int main()
{
	int n, a[100000], t, b[100000];
	cin >> n;
	for(int i = 0 ;i < n; i++)
	{
		cin >> a[i];
	}

	cin >> t;
	for(int i = 0; i < t; i++)
	{
		cin >> b[i];
	}
	bound(a, n, b, t);
	

	
	return 0;
}