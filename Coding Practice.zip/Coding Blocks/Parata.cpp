#include<iostream>
using namespace std;

bool cook(int c[], int p, int n, int m)
{
	int count = 0;
	int chef = 0;
	int time = 0;
	for(int i = 1; i <= n; i++)
	{
		if(time + (c[chef] * i) > m and chef <= n)
		{
			chef ++;
			if(count == p)
			{
				return true;
			}
		}
		else
		{
			time += c[chef] * i;
			count ++;
		}
	}
	return false;
}


void parata(int c[], int p, int n)
{
	int s = 0, e = 0;
    for(int i = 1; i <= p; i++)
	{
		s += c[0] * i;
	}
   
	for(int i = 1; i <= p; i++)
	{
		e += c[n-1] * i;
	}
	int ans, m;

	while(s <= e)
	{
		m = (s + e)/2;
		if(cook(c, p, n, m))
		{
			ans = m;
			e = m - 1;
		}
		else
		{
			s = m + 1;
		}

	}
	cout<<ans<<endl;

}

int main()
{
	int t;
	cin >> t;

	while(t --)
	{
		int p, n;
		cin >> p >> n;
		int c[n];
		for(int i = 0; i < n; i++)
		{
			cin >> c[i];
		}
		parata(c, p, n);
	}

	
	return 0;
}