#include<iostream>
using namespace std;

int main() {
	int i, j, n;
	cin>>n;
	for(i = 1; i<= n; i++)
	{
		for (j = i; j < n; j++)
		{
			cout<<"\t";
		}
		for (j = i; j <= (2*i)-1; j++ )
		{
			cout<<j<<"\t";
		}
		for(j = (i*2)-2; j >= i; j--)
		{
			cout<<j<<"\t";
		}
		cout<<"\n";
	}
	return 0;
}