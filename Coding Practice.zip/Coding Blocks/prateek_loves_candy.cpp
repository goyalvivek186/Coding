#include<iostream>

using namespace std;

void prime(int *a, long long n)
{
    a[2] = 1;
	for(long long i = 3; i < n; i += 2)
	{
		a[i] = 1;
	}
	for(long long i = 0; i < n; i++)
	{
		if(a[i] == 1)
			{
				for(long long j = i * i; j < n; j += i)
				{
					a[j] = 0;
				}
			}
	}
}

int main()
{
	long long n = 1000005;
	int a[n] = {0};
	prime(a, n);

	int t;
	cin >> t;

	while(t--)
	{
		int x, c = 0;
		cin >> x;
		for(long long i = 0; i < n; i++)
		{
			if(a[i] == 1)
			{
                //cout<<i<<endl;
				c++;
				if(c == x)
				{
                    cout<<i;
					break;
				}
			}
		}
		cout<<endl;
	}

	
	return 0;
}