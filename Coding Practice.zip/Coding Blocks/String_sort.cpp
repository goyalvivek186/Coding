#include<iostream>
#include<string.h>
#include<algorithm>

using namespace std;



int main()
{
	char ch[1000], str[26] = {0};
	cin >> ch;
	int s = strlen(ch);
	for(int i = 0; i < s; i++)
	{
		str[ch[i] - 'a'] ++; 
	}

	for(int i = 0; i < 26; i++)
	{
        while(str[i] != 0)
        {
		if(str[i] != 0)
		{
            char c = (i + 'a');
            cout<< c <<" ";
            str[i] --;
		}
        }
	}
	

	
	return 0;
}