#include<iostream>
#include<string>
#include<set>

using namespace std;

void per(char *s, int i, set<string> &a)
{
	if(s[i] == '\0')
	{
	string ch = s;
    a.insert(ch);
	return;
	}
    int j;
    for(j = i; s[j] != '\0'; j++)
	{   
        swap(s[i], s[j]);
	    per(s, i+1, a);
	    swap(s[i], s[j]);
    }
    
    return;
}

int main()
{
	char s[100];
    set<string> a;
	cin >> s;
	per(s, 0, a);
    for(auto x:a)
    cout<<x<<endl;

	return 0;
}